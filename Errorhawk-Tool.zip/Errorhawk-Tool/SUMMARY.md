# ErrorHawk - Feature Summary

## 🎯 Core Functionality

### Pattern-Based Error Detection
- ✅ Automatically loads error patterns from `input_keywords.txt`
- ✅ Simple text format: one pattern per line
- ✅ Support for regex patterns
- ✅ Case-insensitive matching by default
- ✅ Comments supported with `#` prefix
- ✅ No JSON knowledge required

### File Scanning
- ✅ Single file analysis
- ✅ Directory scanning (recursive by default)
- ✅ Support for multiple file extensions (.log, .txt, custom)
- ✅ Auto-detection of file vs directory paths
- ✅ Flexible argument handling (positional or explicit flags)
- ✅ Default to current directory if no path specified

## 📊 Reporting Features

### Dual Report Generation
- ✅ Text report (`analysis_summary.txt`) - Human-readable format
- ✅ HTML report (`analysis_report.html`) - Interactive with clickable links
- ✅ Both reports generated automatically
- ✅ Saved in unique timestamped folders

### Text Report Sections
1. **Analysis Metadata**
   - Date and time of analysis
   - Total files scanned
   - Total lines scanned
   - Files with errors count
   - Total errors found

2. **Error Summary by Type**
   - Breakdown of errors by category
   - Count of occurrences per type
   - Sorted by frequency (most common first)

3. **Files Containing Errors**
   - List of all files with errors
   - Full file paths

4. **Error Counts by File** ⭐ NEW
   - Breakdown showing which files have which errors
   - Count per error type per file
   - Total errors per file

5. **Detailed Error Listings**
   - File path
   - Line number
   - Full error content
   - Grouped by error type

### HTML Report Features ⭐ NEW

#### Professional Design
- Modern blue/purple gradient theme
- Responsive layout (works on any screen size)
- Clean, professional appearance
- Hover effects and transitions

#### Interactive Navigation
- Sticky navigation bar
- Quick jump to any section:
  - Summary Statistics
  - Error Types
  - Error Counts by File
  - Files with Errors
  - Detailed Listings

#### Clickable File Links 🔗
- **"🔗 Open Log File" buttons** on each error
- Uses `file://` protocol to open actual log files
- Proper URL encoding for spaces and special characters
- Works with Windows paths (backslashes converted)
- Opens files in default text editor
- Line numbers displayed for manual navigation

#### Visual Components
- Statistics displayed in colorful cards
- Badge indicators for error counts
- Color-coded sections
- Monospace font for error content
- Tree-style indentation for error breakdown
- Gradient backgrounds and borders

## ⚙️ Configuration Options

### Command-Line Arguments
- `path` - Positional argument (file or directory)
- `-f, --file` - Explicit file path
- `-d, --directory` - Explicit directory path
- `--no-recursive` - Disable recursive scanning
- `-e, --extensions` - Specify file extensions to scan
- `-o, --output` - Custom output filename
- `--no-detailed` - Suppress detailed console output
- `--max-lines` - Limit error lines displayed (default: 100)
- `--no-results-folder` - Use current directory instead of timestamped
- `--results-base-name` - Custom base name for results folder

### Pattern Configuration
- Edit `input_keywords.txt` for custom patterns
- Simple text format (not JSON!)
- Add/remove patterns without coding
- Supports comments and empty lines
- Regex patterns supported

## 🚀 Ease of Use

### Windows Batch File Support
- `analyze_logs.bat` - One-click execution
- No need to type Python commands
- Includes helpful usage examples in comments
- Validates Python installation
- Displays success/error messages

### Smart Defaults
- Scans current directory if no path given
- Auto-detects file vs directory
- Creates timestamped results folder automatically
- Loads patterns from `input_keywords.txt` automatically
- Exports both text and HTML reports by default

### User-Friendly Output
- Clear console messages
- Progress indicators during scanning
- Organized folder structure
- Professional HTML presentation

## 📦 Output Organization

### Automatic Timestamped Folders
- Format: `results_YYYYMMDD_HHMMSS/`
- Example: `results_20260123_143025/`
- Each analysis preserved independently
- Never overwrites previous results
- Collision handling with incremental suffixes (_1, _2, etc.)

### Folder Contents
```
results_20260123_143025/
  ├── analysis_summary.txt      # Text report
  └── analysis_report.html      # HTML report with links
```

## 🔍 Error Detection Categories

### Built-in Pattern Types
1. Access violation errors
2. Index out of bounds errors
3. Null reference errors
4. Memory allocation errors
5. Connection/network errors
6. File not found errors
7. Stack overflow errors
8. Timeout errors
9. Database errors
10. General exceptions

### Customizable
- Add your own patterns
- Modify existing patterns
- Comment out unwanted patterns
- No code changes needed

## 💻 Technical Features

### Performance
- Compiled regex patterns for speed
- Line-by-line reading (memory efficient)
- Efficient file globbing for directory scans
- Smart pattern matching (stops at first match per line)

### Compatibility
- Python 3.6+ required
- No external dependencies
- Uses only standard library
- Cross-platform compatible
- Windows batch file for easy Windows usage

### Error Handling
- Graceful handling of encoding errors
- File permission error handling
- Missing file/directory detection
- Invalid path handling
- Robust URL encoding for file paths

## 📈 Use Cases

### Daily Operations
- Monitor application logs for errors
- Scan server logs regularly
- Quick error triage
- Historical error tracking

### Development
- Post-deployment verification
- Bug investigation
- Error pattern analysis
- Log file debugging

### Analysis
- Error frequency analysis
- File-by-file error breakdown
- Temporal analysis (using timestamps)
- Pattern effectiveness testing

## 🎨 HTML Report Highlights

### Interactive Elements
- Clickable navigation menu
- Hover effects on file items
- Button-style links to open log files
- Expandable error details

### Information Hierarchy
1. Summary cards (high-level stats)
2. Error type breakdown (what errors occurred)
3. Error counts by file (which files have issues)
4. File list (all affected files)
5. Detailed listings (complete error information)

### Visual Feedback
- Color-coded severity (red badges for errors)
- Success indicators (green for clean files)
- Professional color scheme (purple/blue gradients)
- Clear section separators
- Monospace formatting for technical content

## 🔗 File:// Protocol Benefits

### Direct File Access
- Click to open log files instantly
- No need to manually navigate to files
- Works with any default text editor
- Supports Windows file paths
- Handles special characters and spaces

### Developer Workflow
1. Run analysis
2. Open HTML report in browser
3. Click on interesting error
4. Log file opens at correct location
5. Investigate and fix issue
6. Re-run analysis to verify

## ✨ Key Improvements Over Previous Versions

1. ✅ **Replaced JSON patterns with simple text file** - Much easier to edit!
2. ✅ **Added HTML report generation** - Visual, interactive reports
3. ✅ **Implemented clickable file links** - Direct access to log files
4. ✅ **Added error counts by file section** - Better file-level analysis
5. ✅ **Flexible path arguments** - No -d or -f flags required
6. ✅ **Auto-load patterns** - No --patterns argument needed
7. ✅ **Professional styling** - Modern, responsive design
8. ✅ **Batch file support** - Easy Windows execution
9. ✅ **Dual report generation** - Text + HTML automatically
10. ✅ **Better organization** - Timestamped folders by default

---

**Perfect for:** System administrators, developers, DevOps engineers, QA testers, anyone who needs to analyze log files efficiently!

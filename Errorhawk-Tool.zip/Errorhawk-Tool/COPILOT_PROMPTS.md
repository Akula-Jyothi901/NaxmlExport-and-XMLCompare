# ErrorHawk - AI Copilot Prompts & Specifications

**Last Updated:** February 3, 2026  
**Version:** 2.0 (JIRA-Ready Edition)  
**Purpose:** Complete prompt documentation for regenerating or extending ErrorHawk using AI assistants

---

## Table of Contents
1. [Project Overview](#project-overview)
2. [Initial Setup Prompts](#initial-setup-prompts)
3. [Core Features Implementation](#core-features-implementation)
4. [JIRA Enhancement Prompts](#jira-enhancement-prompts)
5. [HTML Report Generation](#html-report-generation)
6. [File Structure & Dependencies](#file-structure--dependencies)
7. [Extension Prompts](#extension-prompts)
8. [Testing & Validation](#testing--validation)

---

## Project Overview

### High-Level Description Prompt
```
Create an advanced log file analysis tool called "ErrorHawk" that:
- Scans log files for errors using multiple detection methods
- Categorizes errors by severity (CRITICAL/ERROR/WARNING)
- Generates comprehensive JIRA-ready reports
- Supports multiple output formats (HTML, Text, JSON, CSV, Markdown)
- Provides interactive HTML interface with clickable file links
- Organizes results in timestamped folders
- Offers flexible scanning options (single file, directory, recursive)

Technology Stack:
- Python 3.x for core logic
- HTML5/CSS3/JavaScript for interactive reports
- Regular expressions for pattern matching
- No external dependencies for core functionality
```

---

## Initial Setup Prompts

### 1. Project Structure Setup
```
Create a Python-based log analyzer with the following file structure:

error_hawk.py - Main application file with CLI interface
html_report_generator.py - Separate module for HTML report generation
input_keywords.txt - Configuration file with error patterns organized by severity
analyze_logs.bat - Windows batch file for easy execution

The tool should:
- Use argparse for command-line interface
- Support both Windows and Unix file paths
- Create timestamped result folders automatically
- Handle encoding errors gracefully (UTF-8 with 'ignore')
```

### 2. Keywords Configuration File
```
Create input_keywords.txt with the following structure:

# CRITICAL
Access Violation
Memory Error (Out of Memory)
Segmentation Fault
Stack Overflow
Fatal Error
Access denied
Permission denied
Unauthorized access

# ERROR
Null Reference / Null Pointer Exception
Index Out of Bounds
File Not Found
Database Error
Connection Error
Query Failed
Object reference not set
exception

# WARNING
Timeout (Operation Timeout)
Connection Timeout
Retry Attempts
Deprecated Function Usage

Each section starts with # followed by severity level
Patterns support regex and case-insensitive matching
```

---

## Core Features Implementation

### 3. Multiple Detection Modes
```
Implement three detection modes in error_hawk.py:

1. Keywords Mode (default):
   - Load patterns from input_keywords.txt
   - Support categorization by severity (CRITICAL/ERROR/WARNING)
   - Parse lines starting with # for category headers

2. General Mode:
   - Built-in heuristic patterns that don't require configuration file
   - Include patterns for:
     * Stack overflow, segmentation fault, memory errors (CRITICAL)
     * Error codes, exceptions, null pointers, HTTP 4xx/5xx (ERROR)
     * Warnings, timeouts, deprecated, performance issues (WARNING)

3. Both Mode:
   - Merge keyword patterns and general patterns
   - Remove duplicates
   - Maintain severity categorization

Add command-line argument: --detection-mode [keywords|general|both]
```

### 4. Core Log Analyzer Class
```
Create LogAnalyzer class with the following structure:

class LogAnalyzer:
    def __init__(self, patterns=None, extensions=None, case_sensitive=False, detection_mode='keywords'):
        - Store categorized patterns by severity
        - Compile regex patterns for performance
        - Initialize result storage (defaultdict)
        - Track files scanned, lines scanned, files with errors
    
    def scan_file(self, file_path):
        - Read file line by line with UTF-8 encoding (errors='ignore')
        - Call _check_line for each line
        - Handle exceptions gracefully
    
    def scan_directory(self, dir_path, recursive=True):
        - Use pathlib.glob for file discovery
        - Support multiple extensions
        - Print progress during scanning
    
    def _check_line(self, file_path, line_num, line):
        - Match against compiled patterns
        - Store first matching category only
        - Track file path, line number, content, pattern
    
    def print_results(self, detailed=True, max_lines_per_error=100):
        - Display summary statistics
        - Show error breakdown by type
        - List detailed errors with limits
    
    def export_to_text_report(self, output_file):
        - Generate formatted text report
        - Include metadata, summary, file breakdown, detailed listings
    
    def export_to_html_report(self, output_file):
        - Call generate_html_report from html_report_generator module
```

### 5. JIRA Helper Functions
```
Add these helper functions to error_hawk.py after get_general_error_patterns():

def get_severity_level(error_type_name):
    """Determine severity level based on error type name for JIRA categorization."""
    - Check against CRITICAL keywords: ACCESS VIOLATION, MEMORY ERROR, SEGMENTATION FAULT, 
      STACK OVERFLOW, FATAL ERROR, ACCESS DENIED, PERMISSION DENIED, UNAUTHORIZED ACCESS, 
      KERNEL PANIC, SYSTEM CRASH, CORE DUMP
    - Check against ERROR keywords: NULL REFERENCE, NULL POINTER, INDEX OUT OF BOUNDS, 
      FILE NOT FOUND, DATABASE ERROR, CONNECTION ERROR, QUERY FAILED, 
      OBJECT REFERENCE NOT SET, EXCEPTION, HTTP 4, HTTP 5, EXIT CODE
    - Default to WARNING for everything else
    - Return 'CRITICAL', 'ERROR', or 'WARNING'

def get_impact_assessment(severity):
    """Get impact assessment message for JIRA tickets."""
    - CRITICAL: "Immediate action required - System stability affected"
    - ERROR: "Requires investigation - Functionality impaired"
    - WARNING: "Monitor - Potential issue detected"
    - Default: "Review recommended"

def get_recommended_action(error_type_name):
    """Get recommended action based on error type for JIRA tickets."""
    - ACCESS VIOLATION: "Check memory allocation and pointer usage"
    - NULL REFERENCE/POINTER: "Verify object initialization before access"
    - FILE NOT FOUND: "Validate file path and permissions"
    - CONNECTION: "Check network connectivity and service availability"
    - TIMEOUT: "Review performance and increase timeout thresholds"
    - DATABASE: "Check database connectivity and query syntax"
    - PERMISSION/ACCESS DENIED: "Verify user permissions and access rights"
    - MEMORY: "Investigate memory leaks and optimize resource usage"
    - INDEX OUT OF BOUNDS: "Validate array bounds and collection sizes"
    - STACK OVERFLOW: "Review recursion depth and stack allocation"
    - HTTP 4/5: "Check API endpoints and server configuration"
    - QUERY: "Review SQL query syntax and database schema"
    - DEPRECATED: "Update code to use recommended alternatives"
    - PERFORMANCE/SLOW: "Optimize code performance and resource utilization"
    - Default: "Investigate error details and logs for root cause"

def get_detection_method(detection_mode='keywords'):
    """Get detection method description for JIRA tickets."""
    - keywords: "Keywords-based Detection"
    - general: "General Heuristic Detection"
    - both: "Combined Detection (Keywords + Heuristics)"
```

### 6. Command-Line Interface
```
Implement comprehensive CLI with argparse:

Arguments:
- path (positional, optional): File or directory path (default: current directory)
- -f, --file: Explicit file path
- -d, --directory: Explicit directory path
- --no-recursive: Disable recursive scanning
- -e, --extensions: File extensions to scan (default: .log .txt)
- --detection-mode: Choose keywords, general, or both (default: keywords)
- -o, --output: Custom output filename for text report
- --no-detailed: Disable detailed console output
- --max-lines: Max error lines per type in console (default: 100)
- --no-results-folder: Disable timestamped folder creation
- --results-base-name: Custom base name for results folder (default: results)

Behavior:
- Auto-detect if path is file or directory
- Create timestamped results folder by default (format: results_YYYYMMDD_HHMMSS)
- Generate both HTML and text reports automatically
- Support custom output paths
```

---

## JIRA Enhancement Prompts

### 7. JIRA-Ready Report Metadata
```
Enhance all downloadable report formats (Text, JSON, CSV, Markdown) with JIRA metadata.
DO NOT modify the HTML display - only the downloaded reports.

Required JIRA Metadata Components:

1. Summary Section:
   - Priority Recommendation (P1-P4 based on severity counts)
     * P1 if any CRITICAL errors exist
     * P2 if ERROR count > 10
     * P3 if ERROR > 0 or WARNING > 20
     * P4 otherwise
   - Analysis Date/Time
   - Detection Method (Keywords/General/Both)
   - Files Scanned count
   - Total Errors count

2. Severity Breakdown:
   - CRITICAL count with "Immediate action required" message
   - ERROR count with "Requires investigation" message
   - WARNING count with "Monitor" message

3. Top 3 Issues:
   - Extract top 3 error types by occurrence count
   - Format as numbered list with counts

4. Per-Error Metadata (in detailed listings):
   - Severity Level (CRITICAL/ERROR/WARNING)
   - Impact Assessment (based on severity)
   - Recommended Action (context-specific)
   - Detection Method
   - File path, line number, content

5. Filename Convention:
   - Use format: ErrorHawk_JIRA_Report_YYYY-MM-DD.[ext]
```

---

## HTML Report Generation

### 8. HTML Report Structure Prompt
```
Create html_report_generator.py with generate_html_report() function:

Structure:
- Modular functions for each section (_write_html_header, _write_html_styles, etc.)
- Responsive CSS with gradient backgrounds and modern design
- Interactive JavaScript features
- Download functionality for multiple formats

Required Sections:
1. Header: Title, timestamp, gradient background
2. Navigation: Sticky nav with smooth scrolling links
3. Summary Statistics: Grid of stat cards (files, lines, errors, etc.)
4. Error Types: Expandable error badges with preview
5. Errors by File: Tree structure with file links
6. Detailed Errors: Full listings with line numbers and clickable file links
7. Downloads: Buttons for Text, JSON, CSV, Markdown
8. Footer: Timestamp and attribution

Key Features:
- Use file:// URLs for clickable log file links
- Escape HTML special characters properly
- Generate JavaScript reportData object with all error information
- Include download functions in JavaScript
```

### 9. Interactive Features Prompt
```
Implement JavaScript interactive features in HTML report:

1. Error Type Preview Toggle:
   - Click badge to expand/collapse error preview
   - Extract error names from log content
   - Group and count similar errors
   - Display as preview list with counts
   - Add "View Detailed Errors" link that scrolls to detailed section

2. Smooth Scrolling:
   - Navigation links use smooth scrolling
   - Highlighted section on navigation click

3. Error Name Extraction:
   - Parse log content for specific error types
   - Handle: Access Violation, Index Out of Bound, Exceptions, etc.
   - Fall back to last 5 words if no specific pattern found

4. Hover Effects:
   - Transform on hover for cards and buttons
   - Color transitions
   - Shadow depth changes
```

### 10. Download Functions Prompt
```
Implement JavaScript download functions with JIRA metadata:

Helper Functions (add after triggerDownload):
- getSeverityLevel(errorType) - Returns CRITICAL/ERROR/WARNING
- getImpactAssessment(severity) - Returns impact message
- getRecommendedAction(errorType) - Returns context-specific action
- getDetectionMethod() - Returns detection method string
- categorizeErrors() - Counts errors by severity
- getPriorityRecommendation(critical, error, warning) - Returns P1-P4
- getTop3Issues() - Returns array of top 3 error types with counts

Download Functions:

1. downloadText():
   - Header with JIRA summary (priority, date, method, counts)
   - Severity breakdown with emoji and descriptions
   - Top 3 issues numbered list
   - Analysis metadata
   - Error summary by type with severity labels
   - Detailed listings with severity, impact, and recommended action per error
   - Use 80-character separators
   - Filename: ErrorHawk_JIRA_Report_YYYY-MM-DD.txt

2. downloadJSON():
   - Add jiraReadySummary object at top level with:
     * priorityRecommendation
     * analysisDate
     * detectionMethod
     * severityBreakdown (critical/error/warning objects with count and impact)
     * top3Issues array
   - Enhance each error in detailedErrors array with:
     * severity
     * impact
     * recommendedAction
   - Filename: ErrorHawk_JIRA_Report_YYYY-MM-DD.json

3. downloadCSV():
   - Header section with JIRA summary (multiple rows)
   - Severity breakdown section
   - Top 3 issues section
   - Blank row separator
   - Detailed errors with columns: Error #, Type, Severity, Impact, Action, File, Line, Content
   - Properly escape quotes in CSV values
   - Filename: ErrorHawk_JIRA_Report_YYYY-MM-DD.csv

4. downloadMarkdown():
   - # Header: ERRORHAWK JIRA-READY REPORT
   - ## JIRA SUMMARY with priority as H3
   - Table with analysis metrics
   - ### Severity Breakdown with emoji bullets
   - ### Top 3 Issues as numbered list
   - ## ANALYSIS METADATA table
   - ## ERROR SUMMARY BY TYPE table with Severity column
   - ## ERROR COUNTS BY FILE with H3 per file
   - ## DETAILED ERROR LISTINGS with severity info per error
   - Format code blocks for error content
   - Filename: ErrorHawk_JIRA_Report_YYYY-MM-DD.md

Note: DO NOT include downloadPDF() or downloadExcel() functions.
DO NOT include CDN links for html2pdf or xlsx libraries.
```

### 11. CSS Styling Prompt
```
Create comprehensive CSS in html_report_generator.py:

Design System:
- Primary gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%)
- Background: #f5f7fa
- Cards: white with box-shadow
- Borders: subtle with border-radius

Component Styles:
1. Header: Full-width gradient, white text, centered, large title
2. Navigation: Sticky, light background, horizontal links with hover effects
3. Stat Cards: Grid layout, gradient backgrounds, large numbers, responsive
4. Error Summary: Yellow warning background with left border
5. Error Type Badges: Red badges, clickable with hover scale effect
6. File Items: Light background with left colored border, tree structure
7. Error Boxes: White cards with shadow, hover lift effect
8. Download Buttons: Gradient buttons, icon + label, hover animation
9. Footer: Dark background, centered text

Responsive:
- Grid auto-fit with minmax
- Mobile breakpoint at 768px
- Single column on small screens
```

---

## File Structure & Dependencies

### 12. Project Organization
```
Required Files:
- error_hawk.py (main application, ~700 lines)
- html_report_generator.py (HTML generation, ~1000 lines)
- input_keywords.txt (error patterns configuration)
- analyze_logs.bat (Windows batch launcher)
- README.md (user documentation)
- QUICKSTART.md (quick start guide)
- COPILOT_PROMPTS.md (this file)

Generated Files:
- results_YYYYMMDD_HHMMSS/ (timestamped folders)
  - analysis_report.html (interactive HTML report)
  - analysis_summary.txt (plain text report)

Dependencies:
- Python 3.x standard library only:
  * os, re, argparse, pathlib, collections, datetime, html, urllib

No External Dependencies Required!
```

### 13. Batch File Template
```
Create analyze_logs.bat:

@echo off
echo ====================================
echo ErrorHawk - Log Analysis Tool
echo ====================================
echo.

REM Check if Python is available
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.x and try again
    pause
    exit /b 1
)

REM Default to current directory if no arguments
if "%~1"=="" (
    python error_hawk.py .
) else (
    python error_hawk.py %*
)

echo.
echo ====================================
echo Analysis Complete!
echo ====================================
pause
```

---

## Extension Prompts

### 14. Adding New Error Patterns
```
To add new error pattern categories:

1. Update input_keywords.txt:
   # NEW_CATEGORY
   Pattern 1
   Pattern 2

2. Update get_severity_level() in error_hawk.py:
   - Add category to appropriate severity level
   - Update keyword lists

3. Update get_recommended_action():
   - Add specific recommendations for new patterns

4. Update JavaScript getSeverityLevel() in html_report_generator.py:
   - Mirror Python severity logic
```

### 15. Adding New Output Formats
```
To add a new download format (e.g., XML):

1. Add JavaScript function in html_report_generator.py:
   function downloadXML() {
       const categories = categorizeErrors();
       const priority = getPriorityRecommendation(...);
       const top3 = getTop3Issues();
       
       // Build XML structure with JIRA metadata
       let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
       xml += '<errorhawk-report>\n';
       xml += '<jira-summary>...</jira-summary>\n';
       // ... add all error data
       xml += '</errorhawk-report>\n';
       
       triggerDownload(xml, `ErrorHawk_JIRA_Report_${...}.xml`, 'application/xml');
   }

2. Add button in _write_html_download_section():
   f.write('<a href="#" class="download-btn" onclick="downloadXML(); return false;">')
   f.write('<span class="icon">📄</span><span class="label">Download as XML</span></a>\n')
```

### 16. Custom Report Templates
```
To create custom report templates:

1. Create new function in html_report_generator.py:
   def generate_custom_report(analyzer, output_file, template_name):
       # Load template
       # Populate with analyzer data
       # Apply custom formatting
       # Save to output_file

2. Add CLI argument in error_hawk.py:
   parser.add_argument('--template', choices=['standard', 'compact', 'detailed'])

3. Call custom generator based on template choice
```

### 17. Database Integration
```
To add database storage for historical analysis:

1. Add optional dependency: sqlite3 or sqlalchemy

2. Create schema:
   - analysis_runs (id, timestamp, files_scanned, total_errors)
   - error_records (id, run_id, error_type, severity, file_path, line_num, content)
   - error_types (id, name, category, severity)

3. Add methods to LogAnalyzer:
   - save_to_database()
   - load_from_database()
   - compare_analyses()

4. Add CLI flags:
   --save-db: Store results in database
   --load-db: Load previous analysis
   --compare-runs: Compare multiple runs
```

### 18. Email Report Integration
```
To add email functionality:

1. Add dependency: smtplib (standard library)

2. Create email_sender.py module:
   def send_report_email(report_path, recipients, smtp_config):
       - Attach HTML report
       - Add summary in email body
       - Include download links for other formats

3. Add CLI arguments:
   --email-report: Send via email after analysis
   --email-to: Recipient addresses
   --smtp-server: SMTP server configuration

4. Add to main():
   if args.email_report:
       send_report_email(html_path, args.email_to, smtp_config)
```

---

## Testing & Validation

### 19. Test Data Creation
```
Create test log files for validation:

1. test_critical.log:
   - Include Access Violation errors
   - Include Memory Errors
   - Include Fatal Errors
   - Expected: CRITICAL category

2. test_errors.log:
   - Include Null Reference errors
   - Include File Not Found errors
   - Include Database errors
   - Expected: ERROR category

3. test_warnings.log:
   - Include Timeouts
   - Include Deprecated warnings
   - Expected: WARNING category

4. test_mixed.log:
   - Mix of all severity levels
   - Test correct categorization
   - Test JIRA priority recommendation

5. test_large.log:
   - 100,000+ lines
   - Test performance
   - Test memory efficiency
```

### 20. Validation Checklist
```
Before deployment, verify:

Core Functionality:
[ ] Scans single files correctly
[ ] Scans directories recursively
[ ] Detects all error patterns from input_keywords.txt
[ ] Categorizes errors by severity correctly
[ ] Handles large files (>1GB) without crashing
[ ] Handles non-UTF8 files gracefully
[ ] Creates timestamped folders correctly

Detection Modes:
[ ] Keywords mode works with input_keywords.txt
[ ] General mode works without configuration file
[ ] Both mode combines patterns correctly
[ ] Detection mode shown in reports

JIRA Features:
[ ] Severity levels assigned correctly
[ ] Impact assessments generated
[ ] Recommended actions provided
[ ] Priority recommendations accurate (P1-P4)
[ ] Top 3 issues identified correctly

Reports:
[ ] HTML report displays correctly in browsers
[ ] File links open log files in text editor
[ ] Error preview toggle works
[ ] Smooth scrolling navigation works
[ ] Text download includes JIRA metadata
[ ] JSON download includes jiraReadySummary
[ ] CSV download properly formatted with JIRA data
[ ] Markdown download renders correctly

Cross-Platform:
[ ] Works on Windows
[ ] Works on Linux
[ ] Works on macOS
[ ] Handles path separators correctly
[ ] File URLs work on all platforms
```

---

## Advanced Prompts

### 21. Performance Optimization
```
Optimize ErrorHawk for large-scale log analysis:

1. Implement streaming for large files:
   - Process files in chunks instead of loading entirely
   - Use generators for memory efficiency
   - Add progress bars for long operations

2. Add parallel processing:
   - Use multiprocessing for scanning multiple files
   - Implement worker pool for pattern matching
   - Aggregate results from parallel workers

3. Add caching:
   - Cache compiled regex patterns
   - Cache file metadata
   - Store intermediate results

4. Profile and optimize:
   - Use cProfile to identify bottlenecks
   - Optimize hot paths
   - Consider Cython for critical sections
```

### 22. Advanced Filtering
```
Add advanced filtering capabilities:

1. Time-based filtering:
   - Parse timestamps from log lines
   - Filter errors by date range
   - Show error trends over time

2. Severity filtering:
   - Scan for specific severity only
   - Exclude certain severity levels
   - Customize severity thresholds

3. Pattern exclusions:
   - Allow exclude patterns in config
   - Support negation in pattern matching
   - Filter out known non-issues

4. Context capture:
   - Capture N lines before/after error
   - Show full stack traces
   - Include surrounding context in reports
```

### 23. Integration Prompts
```
Integrate ErrorHawk with external systems:

1. JIRA REST API Integration:
   - Auto-create JIRA tickets from analysis
   - Map severity to JIRA priority
   - Include full analysis as attachment
   - Update existing tickets

2. Slack/Teams Notifications:
   - Send summary to channels
   - Alert on critical errors
   - Include download links

3. CI/CD Pipeline Integration:
   - Return exit codes based on severity
   - Fail builds on critical errors
   - Generate pipeline artifacts

4. Monitoring System Integration:
   - Send metrics to Prometheus
   - Create Grafana dashboards
   - Set up alerts for error thresholds
```

---

## Regeneration Instructions

### Complete Regeneration Process

If you need to regenerate ErrorHawk from scratch:

1. **Start with Core Structure:**
   ```
   Use prompt #1 (Project Structure Setup) to create basic file structure
   ```

2. **Implement Detection Modes:**
   ```
   Use prompt #3 (Multiple Detection Modes) to add keywords/general/both modes
   ```

3. **Build Core Analyzer:**
   ```
   Use prompt #4 (Core Log Analyzer Class) to implement main logic
   ```

4. **Add JIRA Helpers:**
   ```
   Use prompt #5 (JIRA Helper Functions) to add severity/impact/action functions
   ```

5. **Create HTML Generator:**
   ```
   Use prompt #8 (HTML Report Structure) for html_report_generator.py
   Use prompt #9 (Interactive Features) for JavaScript
   Use prompt #11 (CSS Styling) for comprehensive styles
   ```

6. **Implement Downloads:**
   ```
   Use prompt #10 (Download Functions) to add JIRA-ready downloads
   Remove PDF and Excel as per specifications
   ```

7. **Add CLI:**
   ```
   Use prompt #6 (Command-Line Interface) for argparse setup
   ```

8. **Test & Validate:**
   ```
   Use prompt #19 (Test Data Creation) to create test files
   Use prompt #20 (Validation Checklist) to verify all features
   ```

---

## Common Issues & Solutions

### Issue 1: File Encoding Errors
```
Problem: UnicodeDecodeError when reading log files

Solution:
- Use open(file, 'r', encoding='utf-8', errors='ignore')
- This handles non-UTF8 characters gracefully
```

### Issue 2: File Links Not Working
```
Problem: file:// URLs don't open log files

Solution:
- Use urllib.parse.quote() for URL encoding
- Convert backslashes to forward slashes
- Ensure proper file:// prefix (file:/// on Windows)
```

### Issue 3: Large Memory Usage
```
Problem: Memory issues with large log files

Solution:
- Use generators instead of loading full file
- Process line by line
- Limit detailed error display with max_lines parameter
```

### Issue 4: Regex Performance
```
Problem: Slow pattern matching

Solution:
- Compile patterns once during initialization
- Store compiled patterns in dictionary
- Use non-capturing groups in regex
```

---

## Version History

### v2.0 (February 3, 2026) - JIRA-Ready Edition
- Added JIRA metadata to all downloadable reports
- Implemented severity categorization (CRITICAL/ERROR/WARNING)
- Added impact assessments and recommended actions
- Removed PDF and Excel downloads (simplified to 4 formats)
- Enhanced with priority recommendations (P1-P4)
- Added top 3 issues identification

### v1.0 (January 28, 2026) - Initial Release
- Core log analysis functionality
- Multiple detection modes
- HTML interactive reports
- 6 download formats
- Timestamped result folders

---

## Contributing Guidelines

When extending ErrorHawk:

1. **Maintain JIRA Integration:**
   - All new features should support JIRA-ready output
   - Add metadata to all download formats
   - Maintain consistent severity categorization

2. **Follow Code Structure:**
   - Keep error_hawk.py for core logic
   - Use html_report_generator.py for all HTML/reporting
   - Use modular functions with clear separation

3. **Document Changes:**
   - Update this COPILOT_PROMPTS.md with new prompts
   - Update README.md with user-facing changes
   - Add examples for new features

4. **Test Thoroughly:**
   - Test all detection modes
   - Verify all download formats
   - Test on multiple platforms

---

## Quick Reference Commands

### Generate Project from Scratch:
```bash
# 1. Create directory structure
mkdir ErrorHawk && cd ErrorHawk

# 2. Create files using prompts 1-11 in order
# Use AI assistant with each prompt section

# 3. Test basic functionality
python error_hawk.py test_logs/

# 4. Validate all features
python error_hawk.py --detection-mode both Logs/ --no-recursive
```

### Regenerate Specific Component:
```bash
# HTML Generator only: Use prompts 8, 9, 10, 11
# JIRA Features only: Use prompts 5, 7, 10
# Detection Modes only: Use prompt 3
# CLI Interface only: Use prompt 6
```

---

## Contact & Support

For questions or issues with regeneration:
- Review the specific prompt section
- Check Common Issues & Solutions
- Validate against the Validation Checklist
- Ensure all dependencies are correct

---

**END OF COPILOT PROMPTS DOCUMENTATION**

*This file contains complete instructions for regenerating ErrorHawk v2.0 using AI assistants like GitHub Copilot, ChatGPT, or similar tools.*

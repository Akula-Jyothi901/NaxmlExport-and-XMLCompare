# ErrorHawk

A powerful Python-based error detection system that scans log files for error patterns and generates comprehensive reports with clickable hyperlinks.

## ✨ Features

- 🔍 **Pattern Matching**: Automatically loads error patterns from `input_keywords.txt` (simple text format - one pattern per line)
- 📁 **Smart Scanning**: Recursively scan directories or analyze single files
- 🎯 **Flexible Arguments**: Auto-detects file vs directory paths without explicit flags
- ⚙️ **Customizable**: Add/remove patterns easily without JSON knowledge
- 📊 **Dual Reports**: Generates both text and HTML reports automatically
- 🔗 **Interactive HTML**: Clickable `file://` links to open log files directly in your editor
- 🎨 **Professional Styling**: Modern gradient design with responsive layout
- 📦 **Timestamped Results**: Each analysis saved in unique timestamped folders
- 🚀 **Batch File Support**: Easy Windows execution without typing Python commands
- 📈 **Error Breakdown**: See error counts broken down by file and type

## 🚀 Quick Start

### Option 1: Using the Batch File (Recommended for Windows)
```cmd
analyze_logs.bat
```

### Option 2: Using Python Directly
```bash
python error_hawk.py Logs
```

## 📋 Requirements

- Python 3.6 or higher
- No external dependencies required (uses only standard library)

## 📖 Usage Examples

### Scan current directory (simplest!)
```bash
python error_hawk.py
```
or
```cmd
analyze_logs.bat
```

### Scan a specific directory
```bash
python error_hawk.py C:\Path\To\Logs
```

### Scan a single log file
```bash
python error_hawk.py app.log
```

### Scan without creating timestamped folder
```bash
python error_hawk.py Logs --no-results-folder
```

### Custom results folder name
```bash
python error_hawk.py Logs --results-base-name "daily_scan"
```

### Scan specific file extensions
```bash
python error_hawk.py Logs -e .log .txt .err
```

## 📁 Output Structure

Every analysis creates a timestamped results folder:

```
results_20260123_143025/
  ├── analysis_summary.txt      # Human-readable text report
  └── analysis_report.html      # Interactive HTML report with clickable links
```

## 📄 Report Contents

### Text Report (`analysis_summary.txt`)
- Analysis metadata (date, files scanned, lines scanned)
- Error summary by type
- Files containing errors
- Error counts broken down by file
- Detailed error listings with file paths and line numbers

### HTML Report (`analysis_report.html`)
- **Professional Design**: Modern blue/purple gradient theme
- **Navigation**: Sticky nav with links to all sections
- **Summary Cards**: Visual statistics display
- **Error Counts by File**: New section showing errors per file
- **Clickable Links**: Click "🔗 Open Log File" buttons to open actual log files
- **Responsive Layout**: Works on any screen size

## 🎯 Error Pattern Configuration

Edit `input_keywords.txt` to customize error patterns:

```text
# Access violation errors
access violation
access denied
permission denied

# Index errors
index out of bounds?
index out of range

# Memory errors
out of memory
memory allocation failed

# Add your own patterns here!
custom error message
```

**Features:**
- One pattern per line (simple!)
- Lines starting with `#` are comments
- Empty lines are ignored
- Regex patterns supported
- Case-insensitive by default

## 🔧 Command-Line Options

```
usage: log_analyzer.py [-h] [-f FILE] [-d DIRECTORY] [--no-recursive]
                       [-e EXTENSIONS [EXTENSIONS ...]] [-o OUTPUT]
                       [--no-detailed] [--max-lines MAX_LINES]
                       [--no-results-folder]
                       [--results-base-name RESULTS_BASE_NAME]
                       [path]

positional arguments:
  path                  Path to log file or directory (default: current directory)

optional arguments:
  -h, --help            Show help message
  -f, --file FILE       Path to a single log file
  -d, --directory DIR   Path to a directory containing log files
  --no-recursive        Disable recursive directory scanning
  -e, --extensions      File extensions to scan (default: .log .txt)
  -o, --output          Export to custom filename
  --no-detailed         Disable detailed error listings in console
  --max-lines N         Max error lines per type (default: 100)
  --no-results-folder   Use current directory instead of timestamped folder
  --results-base-name   Custom base name for results folder (default: results)
```

## 📊 HTML Report Features

### Clickable File Links
- Each error includes a "🔗 Open Log File" button
- Clicking opens the actual log file using `file://` protocol
- Works with Windows paths and handles spaces/special characters
- Line numbers displayed prominently for easy navigation

### Navigation
- Quick jump to any section
- Summary Statistics
- Error Types
- Error Counts by File
- Files with Errors
- Detailed Listings

### Visual Design
- Modern gradient header (blue/purple)
- Color-coded badges for error counts
- Hover effects for better interactivity
- Monospace font for error content
- Responsive grid layout

## 🛠️ Files in This Repository

- `log_analyzer.py` - Main Python script
- `analyze_logs.bat` - Windows batch file for easy execution
- `update_analyzer.bat` - Utility to update to latest version
- `input_keywords.txt` - Error patterns configuration
- `README.md` - This file
- `QUICKSTART.md` - Quick reference guide
- `WORKFLOW.md` - Detailed workflow diagrams
- `SUMMARY.md` - Feature summary

## 💡 Tips

1. **Pattern Testing**: Start with broad patterns, refine as needed
2. **Results Management**: Archive old results folders periodically
3. **Batch Processing**: Use the batch file for daily scans
4. **Custom Naming**: Use `--results-base-name` for organized archives
5. **HTML Reports**: Open in any modern browser for best experience
6. **File Links**: Ensure your system associates `.log` files with a text editor

## 🐛 Troubleshooting

### File links don't work
- Ensure your browser/OS supports `file://` protocol
- Check that log files exist at the specified paths
- Try a different browser (Firefox, Chrome, Edge all support it)

### Patterns not matching
- Check `input_keywords.txt` syntax
- Verify patterns are on separate lines
- Remove any extra whitespace
- Test with simpler patterns first

### No errors detected
- Verify log files contain the expected error messages
- Check if patterns are too specific
- Try case-insensitive matching (default behavior)

## 📝 License

This tool is provided as-is for log analysis purposes.

## 🤝 Contributing

Feel free to suggest improvements or report issues!

---

**Made with ❤️ for efficient log analysis**

#!/usr/bin/env python3
"""
HTML Report Generator for ErrorHawk
Generates professional HTML reports with interactive features
"""

import os
import urllib.parse
from html import escape as html_escape
from datetime import datetime
from collections import defaultdict


def path_to_file_url(file_path):
    """Convert a file path to a proper file:// URL."""
    # Convert backslashes to forward slashes
    file_path = file_path.replace('\\', '/')
    # Ensure it starts with file:///
    if not file_path.startswith('/'):
        file_path = '/' + file_path
    # URL encode the path to handle spaces and special characters
    return 'file://' + urllib.parse.quote(file_path)


def escape_html(text):
    """Escape HTML special characters."""
    return html_escape(text)


def generate_html_report(analyzer, output_file):
    """
    Export results to a professional HTML report file with clickable hyperlinks to source log files.
    
    Args:
        analyzer: LogAnalyzer instance with scan results
        output_file: Path to the output HTML file
    """
    try:        # Ensure parent directory exists
        os.makedirs(os.path.dirname(output_file) or '.', exist_ok=True)
        
        # Build error counts per file for the report
        file_error_counts = defaultdict(lambda: defaultdict(int))
        for error_type, errors in analyzer.results.items():
            for error in errors:
                file_path = error['file']
                file_error_counts[file_path][error_type] += 1
        
        with open(output_file, 'w', encoding='utf-8') as f:
            _write_html_header(f)
            _write_html_styles(f)
            _write_html_body_start(f)
            _write_html_header_section(f)
            _write_html_navigation(f)
            _write_html_content_start(f)
            _write_html_summary_section(f, analyzer)
            
            if not analyzer.results:
                f.write('            <div class="no-errors">✓ NO ERRORS FOUND - All log files are clean!</div>\n')
            else:
                _write_html_error_types_section(f, analyzer)
                _write_html_detailed_errors_section(f, analyzer)
            
            _write_html_download_section(f)
            _write_html_content_end(f)
            _write_html_footer(f)
            _write_html_javascript(f, analyzer, file_error_counts)
            _write_html_body_end(f)
        
        print(f"\n✓ HTML report saved to: {output_file}")
    except Exception as e:
        print(f"\n✗ Error generating HTML report: {e}")


def _write_html_header(f):
    """Write HTML document header."""
    f.write('<!DOCTYPE html>\n')
    f.write('<html lang="en">\n')
    f.write('<head>\n')
    f.write('    <meta charset="UTF-8">\n')
    f.write('    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n')
    f.write('    <title>ErrorHawk Analysis Report</title>\n')


def _write_html_styles(f):
    """Write CSS styles for the HTML report."""
    f.write('    <style>\n')
    f.write('        * { margin: 0; padding: 0; box-sizing: border-box; }\n')

    f.write('        body { font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background: #f5f7fa; padding: 20px; }\n')
    f.write('        .container { max-width: 1400px; margin: 0 auto; background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 8px; }\n')

    f.write('        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 8px 8px 0 0; }\n')
    f.write('        .header h1 { font-size: 2.5em; margin-bottom: 10px; }\n')

    f.write('        .header .subtitle { font-size: 1.1em; opacity: 0.9; }\n')
    f.write('        .nav { background: #f8f9fa; padding: 15px 30px; border-bottom: 2px solid #e9ecef; position: sticky; top: 0; z-index: 100; }\n')

    f.write('        .nav a { color: #667eea; text-decoration: none; margin-right: 25px; font-weight: 500; transition: color 0.3s; }\n')
    f.write('        .nav a:hover { color: #764ba2; text-decoration: underline; }\n')

    f.write('        .content { padding: 30px; }\n')
    f.write('        .section { margin-bottom: 40px; }\n')

    f.write('        .section h2 { color: #667eea; font-size: 1.8em; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 3px solid #667eea; }\n')
    f.write('        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }\n')

    f.write('        .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }\n')

    f.write('        .stat-card .label { font-size: 0.9em; opacity: 0.9; margin-bottom: 5px; }\n')

    f.write('        .stat-card .value { font-size: 2em; font-weight: bold; }\n')

    f.write('        .error-summary { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 15px 0; border-radius: 4px; }\n')

    f.write('        .error-type { display: flex; justify-content: space-between; padding: 10px; background: #f8f9fa; margin: 5px 0; border-radius: 4px; }\n')

    f.write('        .error-type:hover { background: #e9ecef; }\n')

    f.write('        .error-type-badge { cursor: pointer; transition: all 0.3s; }\n')

    f.write('        .error-type-badge:hover { transform: scale(1.05); }\n')

    f.write('        .error-preview-list { margin-top: 10px; padding: 10px; background: #fff; border-radius: 4px; display: none; }\n')

    f.write('        .error-preview-item { padding: 10px 15px; margin: 5px 0; background: #f8f9fa; border-left: 3px solid #dc3545; border-radius: 3px; font-size: 0.95em; display: flex; justify-content: space-between; align-items: center; }\n')

    f.write('        .error-preview-item:hover { background: #e9ecef; }\n')

    f.write('        .error-preview-item .error-name { color: #dc3545; font-weight: bold; }\n')

    f.write('        .error-preview-item .error-count { background: #dc3545; color: white; padding: 3px 10px; border-radius: 12px; font-size: 0.85em; }\n')

    f.write('        .toggle-icon { display: inline-block; margin-left: 5px; transition: transform 0.3s; }\n')

    f.write('        .toggle-icon.expanded { transform: rotate(180deg); }\n')

    f.write('        .view-details-link { margin-top: 10px; margin-bottom: 15px; text-align: right; padding: 10px 0; }\n')

    f.write('        .view-details-link a { color: #667eea; text-decoration: none; font-weight: 600; font-size: 0.95em; transition: all 0.3s; display: inline-flex; align-items: center; gap: 5px; }\n')

    f.write('        .view-details-link a:hover { color: #764ba2; transform: translateX(5px); }\n')

    f.write('        .file-item { background: #f8f9fa; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 4px solid #667eea; }\n')

    f.write('        .file-item:hover { background: #e9ecef; }\n')

    f.write('        .file-link { color: #667eea; text-decoration: none; font-weight: 500; }\n')

    f.write('        .file-link:hover { text-decoration: underline; }\n')

    f.write('        .error-box { background: #fff; border: 1px solid #dee2e6; border-radius: 4px; padding: 20px; margin: 15px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }\n')

    f.write('        .error-box:hover { box-shadow: 0 4px 8px rgba(0,0,0,0.1); }\n')

    f.write('        .error-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #e9ecef; }\n')

    f.write('        .error-number { background: #667eea; color: white; padding: 5px 12px; border-radius: 20px; font-size: 0.9em; font-weight: bold; }\n')

    f.write('        .open-btn { background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; transition: background 0.3s; }\n')

    f.write('        .open-btn:hover { background: #218838; }\n')

    f.write('        .error-details { margin: 10px 0; }\n')

    f.write('        .error-field { display: flex; margin: 8px 0; }\n')

    f.write('        .error-field .label { font-weight: bold; color: #667eea; min-width: 100px; }\n')

    f.write('        .error-field .value { color: #495057; flex: 1; }\n')

    f.write('        .error-content { background: #f8f9fa; padding: 15px; border-radius: 4px; font-family: "Courier New", monospace; font-size: 0.9em; word-break: break-all; }\n')

    f.write('        .no-errors { text-align: center; padding: 60px; color: #28a745; font-size: 1.5em; }\n')

    f.write('        .footer { text-align: center; padding: 20px; color: #6c757d; font-size: 0.9em; border-top: 1px solid #e9ecef; }\n')

    f.write('        .badge { display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 0.85em; font-weight: 500; }\n')

    f.write('        .badge-danger { background: #dc3545; color: white; }\n')

    f.write('        .tree-item { margin-left: 20px; margin-top: 5px; color: #6c757d; }\n')

    f.write('        .download-section-content { padding: 20px 0; }\n')

    f.write('        .download-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; max-width: 1200px; margin: 20px auto; }\n')

    f.write('        .download-btn { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 20px; border-radius: 8px; text-align: center; text-decoration: none; font-weight: 600; transition: all 0.3s; box-shadow: 0 2px 5px rgba(0,0,0,0.2); cursor: pointer; border: none; display: block; }\n')

    f.write('        .download-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.3); }\n')

    f.write('        .download-btn .icon { font-size: 1.5em; display: block; margin-bottom: 5px; }\n')

    f.write('        .download-btn .label { font-size: 0.9em; }\n')

    f.write('        .coming-soon { opacity: 0.6; cursor: not-allowed; }\n')

    f.write('        .coming-soon:hover { transform: none; }\n')

    f.write('    </style>\n')

    f.write('</head>\n')


def _write_html_body_start(f):
    """Write HTML body opening tag and container."""
    f.write('<body>\n')

    f.write('    <div class="container">\n')


def _write_html_header_section(f):
    """Write the header section with title and timestamp."""
    f.write('        <div class="header">\n')
    f.write('            <h1>📊 ErrorHawk Analysis Report</h1>\n')
    f.write(f'            <div class="subtitle">Generated on {datetime.now().strftime("%B %d, %Y at %H:%M:%S")}</div>\n')
    f.write('        </div>\n')


def _write_html_download_section(f):
    """Write the download buttons section."""
    f.write('            <div id="downloads" class="section">\n')

    f.write('                <h2>📥 Download Report</h2>\n')

    f.write('                <div class="download-section-content">\n')
    f.write('                    <p style="text-align: center; margin-bottom: 25px; color: #666; font-size: 1.1em;">Export this analysis report in multiple formats for sharing and archiving</p>\n')

    f.write('                    <div class="download-grid">\n')

    f.write('                        <a href="#" class="download-btn" onclick="downloadText(); return false;"><span class="icon">📝</span><span class="label">Download as Text</span></a>\n')

    f.write('                        <a href="#" class="download-btn" onclick="downloadJSON(); return false;"><span class="icon">💾</span><span class="label">Download as JSON</span></a>\n')

    f.write('                        <a href="#" class="download-btn" onclick="downloadCSV(); return false;"><span class="icon">📋</span><span class="label">Download as CSV</span></a>\n')

    f.write('                        <a href="#" class="download-btn" onclick="downloadMarkdown(); return false;"><span class="icon">📑</span><span class="label">Download as Markdown</span></a>\n')

    f.write('                    </div>\n')

    f.write('                </div>\n')

    f.write('            </div>\n')


def _write_html_navigation(f):
    """Write the navigation menu."""
    f.write('        <div class="nav">\n')

    f.write('            <a href="#summary">Summary</a>\n')

    f.write('            <a href="#error-types">Error Types</a>\n')

    f.write('            <a href="#detailed">Detailed Errors</a>\n')

    f.write('            <a href="#downloads">Downloads</a>\n')

    f.write('        </div>\n')


def _write_html_content_start(f):
    """Write content section opening tag."""
    f.write('        <div class="content">\n')


def _write_html_summary_section(f, analyzer):
    """Write the summary statistics section."""
    f.write('            <div id="summary" class="section">\n')

    f.write('                <h2>Summary Statistics</h2>\n')

    f.write('                <div class="stats-grid">\n')

    f.write(f'                    <div class="stat-card"><div class="label">Files Scanned</div><div class="value">{analyzer.total_files_scanned:,}</div></div>\n')

    f.write(f'                    <div class="stat-card"><div class="label">Lines Scanned</div><div class="value">{analyzer.total_lines_scanned:,}</div></div>\n')

    f.write(f'                    <div class="stat-card"><div class="label">Files with Errors</div><div class="value">{len(analyzer.files_with_errors):,}</div></div>\n')

    f.write(f'                    <div class="stat-card"><div class="label">Total Errors</div><div class="value">{sum(analyzer.error_counts.values()):,}</div></div>\n')

    f.write('                </div>\n')

    f.write('            </div>\n')


def _write_html_error_types_section(f, analyzer):
    """Write the error summary by type section with clickable badges."""
    f.write('            <div id="error-types" class="section">\n')
    f.write('                <h2>Error Summary by Type</h2>\n')
    f.write('                <div class="error-summary">\n')
    for error_type in sorted(analyzer.error_counts.keys(), key=lambda x: analyzer.error_counts[x], reverse=True):
        count = analyzer.error_counts[error_type]
        error_name = error_type.upper().replace('_', ' ')
        # Make error type clickable with toggle functionality
        f.write(f'                    <div class="error-type">\n')
        f.write(f'                        <span><strong>{escape_html(error_name)}</strong></span>\n')
        f.write(f'                        <span class="badge badge-danger error-type-badge" onclick="toggleErrorPreview(\'{error_type}\')" style="cursor: pointer;">\n')
        f.write(f'                            <span class="toggle-icon" id="toggle-{error_type}">▼</span> {count:,} occurrence(s)\n')
        f.write(f'                        </span>\n')
        f.write(f'                    </div>\n')
        f.write(f'                    <div id="preview-{error_type}" class="error-preview-list"></div>\n')
        f.write(f'                    <div id="view-details-{error_type}" class="view-details-link" style="display: none;">\n')
        f.write(f'                        <a href="#detailed" onclick="scrollToDetailedErrors(\'{error_type}\'); return false;">View Detailed Errors →</a>\n')
        f.write(f'                    </div>\n')

    f.write('                </div>\n')
    f.write('            </div>\n')


def _write_html_error_by_file_section(f, file_error_counts):
    """Write the error counts by file section."""
    f.write('            <div id="error-counts-by-file" class="section">\n')

    f.write('                <h2>Error Counts by File</h2>\n')
    for idx, file_path in enumerate(sorted(file_error_counts.keys()), start=1):
        error_counts = file_error_counts[file_path]
        total_errors = sum(error_counts.values())
        filename = file_path.split('\\')[-1] if '\\' in file_path else file_path.split('/')[-1]
        file_url = path_to_file_url(file_path)
        
        f.write('                <div class="file-item">\n')
        f.write(f'                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">\n')
        f.write(f'                        <strong>{idx}. <a href="{file_url}" class="file-link" title="{escape_html(file_path)}">{escape_html(filename)}</a></strong>\n')
        f.write(f'                        <span class="badge badge-danger">{total_errors} error(s)</span>\n')
        f.write('                    </div>\n')
        f.write(f'                    <div style="font-size: 0.9em; color: #6c757d; margin-bottom: 10px;">{escape_html(file_path)}</div>\n')
        for error_type in sorted(error_counts.keys(), key=lambda x: error_counts[x], reverse=True):
            count = error_counts[error_type]
            error_name = error_type.upper().replace('_', ' ')
            f.write(f'                    <div class="tree-item">├─ {escape_html(error_name)}: {count} occurrence(s)</div>\n')
        f.write('                </div>\n')

    f.write('            </div>\n')


def _write_html_detailed_errors_section(f, analyzer):
    """Write the detailed error listings section."""
    f.write('            <div id="detailed" class="section">\n')

    f.write('                <h2>Detailed Error Listings</h2>\n')
    
    for error_type in sorted(analyzer.results.keys()):
        errors = analyzer.results[error_type]
        error_name = error_type.upper().replace('_', ' ')
        
        f.write(f'                <h3 style="color: #764ba2; margin-top: 30px;">[{escape_html(error_name)}] - {len(errors):,} occurrence(s)</h3>\n')
        
        for idx, error in enumerate(errors, start=1):
            file_path = error['file']
            line_num = error['line_num']
            content = error['content']
            filename = file_path.split('\\')[-1] if '\\' in file_path else file_path.split('/')[-1]
            file_url = path_to_file_url(file_path)
            
            f.write('                <div class="error-box">\n')
            f.write('                    <div class="error-header">\n')
            f.write(f'                        <span class="error-number">Error #{idx}</span>\n')
            f.write(f'                        <a href="{file_url}" class="open-btn" title="Open {escape_html(file_path)}">🔗 Open Log File</a>\n')
            f.write('                    </div>\n')
            f.write('                    <div class="error-details">\n')
            f.write(f'                        <div class="error-field"><span class="label">File:</span><span class="value">{escape_html(filename)}</span></div>\n')
            f.write(f'                        <div class="error-field"><span class="label">Path:</span><span class="value">{escape_html(file_path)}</span></div>\n')
            f.write(f'                        <div class="error-field"><span class="label">Line:</span><span class="value">{line_num}</span></div>\n')
            f.write('                    </div>\n')
            f.write(f'                    <div class="error-content">{escape_html(content)}</div>\n')
            f.write('                </div>\n')
    
    f.write('            </div>\n')


def _write_html_content_end(f):
    """Write content section closing tag."""
    f.write('        </div>\n')


def _write_html_footer(f):
    """Write the footer section."""
    f.write('        <div class="footer">\n')
    f.write(f'            Generated by ErrorHawk on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}<br>\n')
    f.write('            Click on file links to open log files directly in your default text editor\n')
    f.write('        </div>\n')


def _write_html_javascript(f, analyzer, file_error_counts):
    """Write all JavaScript code for interactive features and download functionality."""
    f.write('    </div>\n')

    f.write('    <script>\n')
    
    # Write reportData object
    _write_javascript_report_data(f, analyzer, file_error_counts)
    
    # Write download helper functions
    _write_javascript_download_functions(f)
    
    # Write interactive error preview functions
    _write_javascript_error_preview_functions(f)
    
    f.write('    </script>\n')


def _write_javascript_report_data(f, analyzer, file_error_counts):
    """Write the reportData JavaScript object."""
    f.write('        // Store report data as JavaScript object\n')

    f.write('        const reportData = {\n')

    f.write(f'            analysisDate: "{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}",\n')

    f.write(f'            totalFiles: {analyzer.total_files_scanned},\n')

    f.write(f'            totalLines: {analyzer.total_lines_scanned},\n')

    f.write(f'            filesWithErrors: {len(analyzer.files_with_errors)},\n')

    f.write(f'            totalErrors: {sum(analyzer.error_counts.values())},\n')
    
    # Serialize error counts by type
    f.write('            errorsByType: [\n')
    for error_type in sorted(analyzer.error_counts.keys(), key=lambda x: analyzer.error_counts[x], reverse=True):
        count = analyzer.error_counts[error_type]
        error_name = error_type.upper().replace('_', ' ')
        f.write('                {\n')
        f.write(f'                    type: "{error_name}",\n')
        f.write(f'                    count: {count}\n')
        f.write('                },\n')

    f.write('            ],\n')
    
    # Serialize errors by file
    f.write('            errorsByFile: [\n')
    for idx, file_path in enumerate(sorted(file_error_counts.keys()), start=1):
        error_counts_dict = file_error_counts[file_path]
        total = sum(error_counts_dict.values())
        filename = file_path.split('\\')[-1] if '\\' in file_path else file_path.split('/')[-1]
        f.write('                {\n')
        f.write(f'                    index: {idx},\n')
        f.write(f'                    filename: {repr(filename)},\n')
        f.write(f'                    path: {repr(file_path)},\n')
        f.write(f'                    totalErrors: {total},\n')
        f.write('                    errorBreakdown: [\n')
        for error_type in sorted(error_counts_dict.keys(), key=lambda x: error_counts_dict[x], reverse=True):
            count = error_counts_dict[error_type]
            error_name = error_type.upper().replace('_', ' ')
            f.write('                        {\n')
            f.write(f'                            type: "{error_name}",\n')
            f.write(f'                            count: {count}\n')
            f.write('                        },\n')
        f.write('                    ]\n')
        f.write('                },\n')

    f.write('            ],\n')
    
    # Serialize detailed errors
    f.write('            detailedErrors: [\n')
    global_idx = 1
    for error_type in sorted(analyzer.results.keys()):
        errors = analyzer.results[error_type]
        error_name = error_type.upper().replace('_', ' ')
        for error in errors:
            f.write('                {\n')
            f.write(f'                    errorNumber: {global_idx},\n')
            f.write(f'                    type: "{error_name}",\n')
            f.write(f'                    file: {repr(error["file"])},\n')
            f.write(f'                    line: {error["line_num"]},\n')
            f.write(f'                    content: {repr(error["content"])}\n')
            f.write('                },\n')
            global_idx += 1
    f.write('            ]\n')

    f.write('        };\n\n')


def _write_javascript_download_functions(f):
    """Write JavaScript download helper functions."""
    # Helper function
    f.write('        // Helper function to trigger download\n')
    f.write('        function triggerDownload(content, filename, mimeType) {\n')
    f.write('            const blob = new Blob([content], { type: mimeType });\n')
    f.write('            const url = URL.createObjectURL(blob);\n')
    f.write('            const a = document.createElement("a");\n')
    f.write('            a.href = url;\n')
    f.write('            a.download = filename;\n')
    f.write('            document.body.appendChild(a);\n')
    f.write('            a.click();\n')
    f.write('            document.body.removeChild(a);\n')
    f.write('            URL.revokeObjectURL(url);\n')
    f.write('        }\n\n')
      # JIRA Helper Functions
    f.write('        // JIRA Helper Functions\n')
    f.write('        function getSeverityLevel(errorType) {\n')
    f.write('            const errorTypeUpper = errorType.toUpperCase();\n')
    f.write('            \n')
    f.write('            // Check if the error type itself is CRITICAL or ERROR (from log analyzer categories)\n')
    f.write('            if (errorTypeUpper === "CRITICAL") return "CRITICAL";\n')
    f.write('            if (errorTypeUpper === "ERROR") return "ERROR";\n')
    f.write('            \n')
    f.write('            // Check for specific error keywords in the error type\n')
    f.write('            const critical = ["ACCESS VIOLATION", "MEMORY ERROR", "SEGMENTATION FAULT", "STACK OVERFLOW", "FATAL ERROR", "ACCESS DENIED", "PERMISSION DENIED", "UNAUTHORIZED ACCESS", "KERNEL PANIC", "SYSTEM CRASH", "CORE DUMP"];\n')
    f.write('            const errors = ["NULL REFERENCE", "NULL POINTER", "INDEX OUT OF BOUNDS", "FILE NOT FOUND", "DATABASE ERROR", "CONNECTION ERROR", "QUERY FAILED", "OBJECT REFERENCE NOT SET", "EXCEPTION", "HTTP 4", "HTTP 5", "EXIT CODE"];\n')
    f.write('            if (critical.some(k => errorTypeUpper.includes(k))) return "CRITICAL";\n')
    f.write('            if (errors.some(k => errorTypeUpper.includes(k))) return "ERROR";\n')
    f.write('            return "WARNING";\n')
    f.write('        }\n\n')
    
    f.write('        function getImpactAssessment(severity) {\n')
    f.write('            const impacts = {\n')
    f.write('                "CRITICAL": "Immediate action required - System stability affected",\n')
    f.write('                "ERROR": "Requires investigation - Functionality impaired",\n')
    f.write('                "WARNING": "Monitor - Potential issue detected"\n')
    f.write('            };\n')
    f.write('            return impacts[severity] || "Review recommended";\n')
    f.write('        }\n\n')
    
    f.write('        function getRecommendedAction(errorType) {\n')
    f.write('            const errorTypeUpper = errorType.toUpperCase();\n')
    f.write('            if (errorTypeUpper.includes("ACCESS VIOLATION")) return "Check memory allocation and pointer usage";\n')
    f.write('            if (errorTypeUpper.includes("NULL REFERENCE") || errorTypeUpper.includes("NULL POINTER")) return "Verify object initialization before access";\n')
    f.write('            if (errorTypeUpper.includes("FILE NOT FOUND")) return "Validate file path and permissions";\n')
    f.write('            if (errorTypeUpper.includes("CONNECTION")) return "Check network connectivity and service availability";\n')
    f.write('            if (errorTypeUpper.includes("TIMEOUT")) return "Review performance and increase timeout thresholds";\n')
    f.write('            if (errorTypeUpper.includes("DATABASE")) return "Check database connectivity and query syntax";\n')
    f.write('            if (errorTypeUpper.includes("PERMISSION") || errorTypeUpper.includes("ACCESS DENIED")) return "Verify user permissions and access rights";\n')
    f.write('            if (errorTypeUpper.includes("MEMORY")) return "Investigate memory leaks and optimize resource usage";\n')
    f.write('            if (errorTypeUpper.includes("INDEX OUT OF BOUNDS")) return "Validate array bounds and collection sizes";\n')
    f.write('            if (errorTypeUpper.includes("STACK OVERFLOW")) return "Review recursion depth and stack allocation";\n')
    f.write('            if (errorTypeUpper.includes("HTTP 4") || errorTypeUpper.includes("HTTP 5")) return "Check API endpoints and server configuration";\n')
    f.write('            if (errorTypeUpper.includes("QUERY")) return "Review SQL query syntax and database schema";\n')
    f.write('            if (errorTypeUpper.includes("DEPRECATED")) return "Update code to use recommended alternatives";\n')
    f.write('            if (errorTypeUpper.includes("PERFORMANCE") || errorTypeUpper.includes("SLOW")) return "Optimize code performance and resource utilization";\n')
    f.write('            return "Investigate error details and logs for root cause";\n')
    f.write('        }\n\n')
    
    f.write('        function getDetectionMethod() {\n')
    f.write('            return reportData.detectionMode || "Keywords-based Detection";\n')
    f.write('        }\n\n')
    
    f.write('        function categorizeErrors() {\n')
    f.write('            const categories = { critical: 0, error: 0, warning: 0 };\n')
    f.write('            reportData.errorsByType.forEach(item => {\n')
    f.write('                const severity = getSeverityLevel(item.type);\n')
    f.write('                if (severity === "CRITICAL") categories.critical += item.count;\n')
    f.write('                else if (severity === "ERROR") categories.error += item.count;\n')
    f.write('                else categories.warning += item.count;\n')
    f.write('            });\n')
    f.write('            return categories;\n')
    f.write('        }\n\n')
    
    # JSON download
    f.write('        function downloadJSON() {\n')
    f.write('            const categories = categorizeErrors();\n')
    f.write('            \n')
    f.write('            const enhancedData = {\n')
    f.write('                logSummary: {\n')
    f.write('                    analysisDate: reportData.analysisDate,\n')
    f.write('                    detectionMethod: getDetectionMethod(),\n')
    f.write('                    severityBreakdown: {\n')
    f.write('                        critical: { count: categories.critical, impact: "Immediate action required - System stability affected" },\n')
    f.write('                        error: { count: categories.error, impact: "Requires investigation - Functionality impaired" },\n')
    f.write('                        warning: { count: categories.warning, impact: "Monitor - Potential issue detected" }\n')
    f.write('                    }\n')
    f.write('                },\n')
    f.write('                ...reportData,\n')
    f.write('                detailedErrors: reportData.detailedErrors.map(err => ({\n')
    f.write('                    ...err,\n')
    f.write('                    severity: getSeverityLevel(err.type),\n')
    f.write('                    impact: getImpactAssessment(getSeverityLevel(err.type)),\n')
    f.write('                    recommendedAction: getRecommendedAction(err.type)\n')
    f.write('                }))\n')
    f.write('            };\n')
    f.write('            const jsonData = JSON.stringify(enhancedData, null, 2);\n')
    f.write('            triggerDownload(jsonData, `ErrorHawk_Report_${new Date().toISOString().slice(0,10)}.json`, "application/json");\n')
    f.write('        }\n\n')
    
    # CSV download
    f.write('        function downloadCSV() {\n')
    f.write('            const categories = categorizeErrors();\n')
    f.write('            \n')
    f.write('            let csv = "ERRORHAWK ANALYSIS REPORT\\n\\n";\n')
    f.write('            csv += "LOG SUMMARY\\n";\n')
    f.write('            csv += `Analysis Date,${reportData.analysisDate}\\n`;\n')
    f.write('            csv += `Detection Method,${getDetectionMethod()}\\n`;\n')
    f.write('            csv += `Files Scanned,${reportData.totalFiles}\\n`;\n')
    f.write('            csv += `Total Errors,${reportData.totalErrors}\\n\\n`;\n')
    f.write('            csv += "SEVERITY BREAKDOWN\\n";\n')
    f.write('            csv += `CRITICAL,${categories.critical},Immediate action required\\n`;\n')
    f.write('            csv += `ERROR,${categories.error},Requires investigation\\n`;\n')
    f.write('            csv += `WARNING,${categories.warning},Monitor\\n\\n`;\n')
    f.write('            csv += "\\n\\nDETAILED ERRORS\\n";\n')
    f.write('            csv += "Error #,Error Type,Severity,Impact,Recommended Action,File,Line Number,Content\\n";\n')
    f.write('            reportData.detailedErrors.forEach(err => {\n')
    f.write('                const severity = getSeverityLevel(err.type);\n')
    f.write('                const impact = getImpactAssessment(severity);\n')
    f.write('                const action = getRecommendedAction(err.type);\n')
    f.write('                const escapedContent = `"${err.content.replace(/"/g, \'""\')}"`;\n')
    f.write('                const escapedFile = `"${err.file.replace(/"/g, \'""\')}"`;\n')
    f.write('                const escapedAction = `"${action.replace(/"/g, \'""\')}"`;\n')
    f.write('                csv += `${err.errorNumber},"${err.type}",${severity},"${impact}",${escapedAction},${escapedFile},${err.line},${escapedContent}\\n`;\n')
    f.write('            });\n')
    f.write('            triggerDownload(csv, `ErrorHawk_Report_${new Date().toISOString().slice(0,10)}.csv`, "text/csv");\n')
    f.write('        }\n\n')
    
    # Markdown download
    f.write('        function downloadMarkdown() {\n')
    f.write('            const categories = categorizeErrors();\n')
    f.write('            \n')
    f.write('            let md = `# 🎯 ERRORHAWK ANALYSIS REPORT\\n\\n`;\n')
    f.write('            md += `## LOG SUMMARY\\n\\n`;\n')
    f.write('            md += `| Metric | Value |\\n|--------|-------|\\n`;\n')
    f.write('            md += `| Analysis Date/Time | ${reportData.analysisDate} |\\n`;\n')
    f.write('            md += `| Detection Method | ${getDetectionMethod()} |\\n`;\n')
    f.write('            md += `| Total Files Scanned | ${reportData.totalFiles.toLocaleString()} |\\n`;\n')
    f.write('            md += `| Total Errors Found | ${reportData.totalErrors.toLocaleString()} |\\n\\n`;\n')
    f.write('            md += `### Severity Breakdown\\n\\n`;\n')
    f.write('            md += `- 🔴 **CRITICAL**: ${categories.critical} errors - Immediate action required\\n`;\n')
    f.write('            md += `- 🟠 **ERROR**: ${categories.error} errors - Requires investigation\\n`;\n')
    f.write('            md += `- 🟡 **WARNING**: ${categories.warning} issues - Monitor\\n\\n`;\n')
    f.write('            md += `\\n---\\n\\n## ANALYSIS METADATA\\n\\n`;\n')
    f.write('            md += `| Metric | Value |\\n|--------|-------|\\n`;\n')
    f.write('            md += `| Total Lines Scanned | ${reportData.totalLines.toLocaleString()} |\\n`;\n')
    f.write('            md += `| Files with Errors | ${reportData.filesWithErrors.toLocaleString()} |\\n\\n`;\n')
    f.write('            md += `## ERROR SUMMARY BY TYPE\\n\\n| Error Type | Occurrences | Severity |\\n|------------|-------------|----------|\\n`;\n')
    f.write('            reportData.errorsByType.forEach(item => {\n')
    f.write('                const severity = getSeverityLevel(item.type);\n')
    f.write('                md += `| ${item.type} | ${item.count.toLocaleString()} | ${severity} |\\n`;\n')
    f.write('            });\n')
    f.write('            md += `\\n## DETAILED ERROR LISTINGS\\n\\n`;\n')
    f.write('            let currentType = "";\n')
    f.write('            reportData.detailedErrors.forEach(err => {\n')
    f.write('                if (err.type !== currentType) {\n')
    f.write('                    currentType = err.type;\n')
    f.write('                    const typeCount = reportData.detailedErrors.filter(e => e.type === currentType).length;\n')
    f.write('                    const severity = getSeverityLevel(currentType);\n')
    f.write('                    md += `\\n### [${currentType}] - ${typeCount.toLocaleString()} occurrence(s) - Severity: ${severity}\\n\\n`;\n')
    f.write('                }\n')
    f.write('                const severity = getSeverityLevel(err.type);\n')
    f.write('                const impact = getImpactAssessment(severity);\n')
    f.write('                const action = getRecommendedAction(err.type);\n')
    f.write('                md += `**Error #${err.errorNumber}**\\n\\n`;\n')
    f.write('                md += `- **Severity**: ${severity}\\n`;\n')
    f.write('                md += `- **Impact**: ${impact}\\n`;\n')
    f.write('                md += `- **Recommended Action**: ${action}\\n`;\n')
    f.write('                md += `- **File**: \`${err.file}\`\\n`;\n')
    f.write('                md += `- **Line**: ${err.line}\\n`;\n')
    f.write('                md += `- **Content**:\\n  \`\`\`\\n  ${err.content}\\n  \`\`\`\\n\\n`;\n')
    f.write('            });\n')
    f.write('            md += `---\\n\\n**END OF REPORT**\\n`;\n')
    f.write('            triggerDownload(md, `ErrorHawk_Report_${new Date().toISOString().slice(0,10)}.md`, "text/markdown");\n')
    f.write('        }\n\n')
    
    # Text download
    f.write('        function downloadText() {\n')
    f.write('            const categories = categorizeErrors();\n')
    f.write('            \n')
    f.write('            let txt = "=" + "=".repeat(79) + "\\n";\n')
    f.write('            txt += "  ERRORHAWK ANALYSIS REPORT\\n";\n')
    f.write('            txt += "=" + "=".repeat(79) + "\\n\\n";\n')
    f.write('            txt += "LOG SUMMARY\\n";\n')
    f.write('            txt += "-".repeat(80) + "\\n";\n')
    f.write('            txt += `Analysis Date/Time: ${reportData.analysisDate}\\n`;\n')
    f.write('            txt += `Detection Method: ${getDetectionMethod()}\\n`;\n')
    f.write('            txt += `Files Scanned: ${reportData.totalFiles.toLocaleString()}\\n`;\n')
    f.write('            txt += `Total Errors Found: ${reportData.totalErrors.toLocaleString()}\\n\\n`;\n')
    f.write('            txt += "SEVERITY BREAKDOWN:\\n";\n')
    f.write('            txt += `  🔴 CRITICAL: ${categories.critical} errors - Immediate action required\\n`;\n')
    f.write('            txt += `  🟠 ERROR: ${categories.error} errors - Requires investigation\\n`;\n')
    f.write('            txt += `  🟡 WARNING: ${categories.warning} issues - Monitor\\n\\n`;\n')
    f.write('            txt += "\\n" + "=".repeat(80) + "\\n\\n";\n')
    f.write('            txt += "ANALYSIS METADATA\\n";\n')
    f.write('            txt += "-".repeat(80) + "\\n";\n')
    f.write('            txt += `Total Lines Scanned: ${reportData.totalLines.toLocaleString()}\\n`;\n')
    f.write('            txt += `Files with Errors: ${reportData.filesWithErrors.toLocaleString()}\\n\\n`;\n')
    f.write('            txt += "ERROR SUMMARY BY TYPE\\n";\n')
    f.write('            txt += "-".repeat(80) + "\\n";\n')
    f.write('            reportData.errorsByType.forEach(item => {\n')
    f.write('                const severity = getSeverityLevel(item.type);\n')
    f.write('                txt += `${item.type}: ${item.count.toLocaleString()} occurrence(s) [${severity}]\\n`;\n')
    f.write('            });\n')
    f.write('            txt += "\\n" + "=".repeat(80) + "\\n\\n";\n')
    f.write('            txt += "DETAILED ERROR LISTINGS\\n";\n')
    f.write('            txt += "-".repeat(80) + "\\n\\n";\n')
    f.write('            let currentType = "";\n')
    f.write('            reportData.detailedErrors.forEach(err => {\n')
    f.write('                if (err.type !== currentType) {\n')
    f.write('                    currentType = err.type;\n')
    f.write('                    const typeCount = reportData.detailedErrors.filter(e => e.type === currentType).length;\n')
    f.write('                    const severity = getSeverityLevel(currentType);\n')
    f.write('                    txt += `\\n[${currentType}] - ${typeCount.toLocaleString()} occurrence(s) - Severity: ${severity}\\n`;\n')
    f.write('                    txt += "-".repeat(80) + "\\n";\n')
    f.write('                }\n')
    f.write('                const severity = getSeverityLevel(err.type);\n')
    f.write('                const impact = getImpactAssessment(severity);\n')
    f.write('                const action = getRecommendedAction(err.type);\n')
    f.write('                txt += `\\nError #${err.errorNumber}\\n`;\n')
    f.write('                txt += `  Severity: ${severity}\\n`;\n')
    f.write('                txt += `  Impact: ${impact}\\n`;\n')
    f.write('                txt += `  Recommended Action: ${action}\\n`;\n')
    f.write('                txt += `  File: ${err.file}\\n`;\n')
    f.write('                txt += `  Line: ${err.line}\\n`;\n')
    f.write('                txt += `  Content: ${err.content}\\n`;\n')
    f.write('            });\n')
    f.write('            txt += "\\n" + "=".repeat(80) + "\\n";\n')
    f.write('            txt += "END OF REPORT\\n";\n')
    f.write('            txt += "=".repeat(80) + "\\n";\n')
    f.write('            triggerDownload(txt, `ErrorHawk_Report_${new Date().toISOString().slice(0,10)}.txt`, "text/plain");\n')
    f.write('        }\n\n')


def _write_javascript_error_preview_functions(f):
    """Write JavaScript functions for interactive error preview."""
    # Extract error name function
    f.write('        // Extract error name from log content\n')

    f.write('        function extractErrorName(content) {\n')

    f.write('            const lowerContent = content.toLowerCase();\n')

    f.write('            if (lowerContent.includes(\'access violation\')) return \'Access Violation\';\n')

    f.write('            if (lowerContent.includes(\'index out of bound\')) return \'Index Out of Bound\';\n')

    f.write('            if (lowerContent.includes(\'exception\')) {\n')

    f.write('                if (lowerContent.includes(\'nullreferenceexception\')) return \'Null Reference Exception\';\n')

    f.write('                if (lowerContent.includes(\'argumentexception\')) return \'Argument Exception\';\n')

    f.write('                if (lowerContent.includes(\'invalidoperationexception\')) return \'Invalid Operation Exception\';\n')

    f.write('                return \'Exception\';\n')

    f.write('            }\n')

    f.write('            if (lowerContent.includes(\'error\')) return \'Error\';\n')

    f.write('            if (lowerContent.includes(\'failed\')) return \'Failed\';\n')

    f.write('            if (lowerContent.includes(\'timeout\')) return \'Timeout\';\n')

    f.write('            if (lowerContent.includes(\'connection\')) return \'Connection Issue\';\n')

    f.write('            if (lowerContent.includes(\'null\')) return \'Null Reference\';\n')

    f.write('            const words = content.split(/\\\\s+/);\n')

    f.write('            const lastWords = words.slice(-5).join(\' \');\n')

    f.write('            return lastWords.length > 50 ? lastWords.substring(0, 50) + \'...\' : lastWords;\n')

    f.write('        }\n\n')
    
    # Toggle error preview function
    f.write('        // Toggle error preview when clicking on error type badge\n')

    f.write('        function toggleErrorPreview(errorType) {\n')

    f.write('            const previewDiv = document.getElementById(`preview-${errorType}`);\n')

    f.write('            const viewDetailsDiv = document.getElementById(`view-details-${errorType}`);\n')

    f.write('            const toggleIcon = document.getElementById(`toggle-${errorType}`);\n')

    f.write('            if (previewDiv.style.display === \'none\' || previewDiv.style.display === \'\') {\n')

    f.write('                // Convert errorType to match the format in reportData (uppercase with spaces)\n')

    f.write('                const formattedErrorType = errorType.toUpperCase().replace(/_/g, \' \');\n')

    f.write('                const errors = reportData.detailedErrors.filter(err => err.type === formattedErrorType);\n')

    f.write('                const errorGroups = {};\n')

    f.write('                errors.forEach(err => {\n')

    f.write('                    const errorName = extractErrorName(err.content);\n')

    f.write('                    if (!errorGroups[errorName]) errorGroups[errorName] = 0;\n')

    f.write('                    errorGroups[errorName]++;\n')

    f.write('                });\n')

    f.write('                const sortedErrors = Object.entries(errorGroups).sort((a, b) => b[1] - a[1]);\n')

    f.write('                let html = \'\';\n')

    f.write('                sortedErrors.forEach(([errorName, count]) => {\n')

    f.write('                    html += `<div class="error-preview-item"><span class="error-name">⚠️ ${errorName}</span><span class="error-count">${count}</span></div>`;\n')

    f.write('                });\n')

    f.write('                previewDiv.innerHTML = html;\n')

    f.write('                previewDiv.style.display = \'block\';\n')

    f.write('                if (viewDetailsDiv) viewDetailsDiv.style.display = \'block\';\n')

    f.write('                toggleIcon.classList.add(\'expanded\');\n')

    f.write('            } else {\n')

    f.write('                previewDiv.style.display = \'none\';\n')

    f.write('                if (viewDetailsDiv) viewDetailsDiv.style.display = \'none\';\n')

    f.write('                toggleIcon.classList.remove(\'expanded\');\n')

    f.write('            }\n')

    f.write('        }\n\n')
    
    # Scroll to detailed errors function
    f.write('        // Scroll to detailed errors section\n')

    f.write('        function scrollToDetailedErrors(errorType) {\n')

    f.write('            const detailedSection = document.getElementById(\'detailed\');\n')

    f.write('            if (detailedSection) {\n')

    f.write('                detailedSection.scrollIntoView({ behavior: \'smooth\', block: \'start\' });\n')

    f.write('                // Highlight the section briefly\n')

    f.write('                detailedSection.style.background = \'#fff3cd\';\n')

    f.write('                setTimeout(() => {\n')

    f.write('                    detailedSection.style.background = \'\';\n')

    f.write('                }, 2000);\n')

    f.write('            }\n')

    f.write('        }\n')


def _write_html_body_end(f):
    """Write HTML body and document closing tags."""
    f.write('</body>\n')
    f.write('</html>\n')

# ErrorHawk - Quick Start Guide

## Try it now with your existing logs!

### **Option 1: Using the Batch File (Recommended for Windows)**

### 1. Scan all WB logs
```cmd
analyze_logs.bat -d "Logs/Log_results_WB/"
```

### 2. Scan all Ikea logs
```cmd
analyze_logs.bat -d "Logs/Logs_results_Ikea/"
```

### 3. Scan all logs in both directories
```cmd
analyze_logs.bat -d "Logs/"
```

### **Option 2: Using Python Directly**

### 1. Scan all WB logs
```bash
python error_hawk.py -d "Logs/Log_results_WB/"
```

### 2. Scan all Ikea logs
```bash
python error_hawk.py -d "Logs/Logs_results_Ikea/"
```

### 3. Scan all logs and create custom report name
```bash
python error_hawk.py -d "Logs/" -o custom_report.txt
```

**Note:** Output files will be automatically saved in a timestamped folder like `results_20260122_143025/`

### 4. Scan a specific service log
```bash
python error_hawk.py -f "Logs/Log_results_WB/POSSRV_SERVICE-20250915.log"
```

### 5. Get summary only (no detailed output)
```bash
python error_hawk.py -d "Logs/" --no-detailed
```

### 6. Custom results folder name
```bash
python error_hawk.py -d "Logs/" --results-base-name "my_analysis"
```
**Creates:** `my_analysis_20260122_143025/analysis_summary.txt`

### 7. Disable automatic results folder (use current directory)
```bash
python error_hawk.py -d "Logs/" --no-results-folder
```

### 8. View help
```bash
python error_hawk.py --help
```
**or**
```cmd
analyze_logs.bat --help
```

## What you'll get:

✓ **Automatic timestamped results folder** (e.g., `results_20260122_143025/`)  
✓ **Human-readable text report** (`analysis_summary.txt`)  
✓ **Automatically loads patterns from `input_keywords.txt`** (no --patterns argument needed)  
✓ Total files and lines scanned  
✓ Number of errors found by type  
✓ List of files containing errors  
✓ Detailed error listings with line numbers

## Results Folder Structure:

Every time you run the script, a new folder is created with comprehensive reports:
```
results_20260122_143025/
  ├── analysis_summary.txt     (Detailed text report)
  └── analysis_report.html     (Interactive HTML report with hyperlinks)

results_20260122_150530/
  ├── analysis_summary.txt     (Detailed text report)
  └── analysis_report.html     (Interactive HTML report with hyperlinks)
```

## Example Text Report Content:

```
====================================================================================================
LOG ANALYSIS REPORT
====================================================================================================

ANALYSIS METADATA
----------------------------------------------------------------------------------------------------
Analysis Date/Time    : 2025-01-22 14:30:25
Total Files Scanned   : 15
Total Lines Scanned   : 4,748
Files with Errors     : 2
Total Errors Found    : 7

ERROR SUMMARY BY TYPE
----------------------------------------------------------------------------------------------------
  GENERAL EXCEPTION                         :      5 occurrence(s)
  INDEX OUT OF BOUNDS                       :      1 occurrence(s)
  TIMEOUT ERROR                             :      1 occurrence(s)

FILES CONTAINING ERRORS
----------------------------------------------------------------------------------------------------
    1. C:\...\DASHBOARDS-20250915.log
    2. C:\...\POSSRV_SERVICE-20250915.log

====================================================================================================
DETAILED ERROR LISTINGS
====================================================================================================
...
```

## Next steps:

- Customize error patterns by editing `input_keywords.txt` (one pattern per line)
- Add comments with `#` to organize your patterns
- Use the batch file for quick daily scans
- Archive results folders by date for historical tracking
- Share text reports with your team

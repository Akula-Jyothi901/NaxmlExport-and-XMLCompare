# 🚀 Quick Reference Guide - ErrorHawk

## Installation

No installation needed! Just Python 3.6+

## Basic Commands

### 1️⃣ Scan a Single File
```powershell
python error_hawk.py -f "path\to\file.log"
```

### 2️⃣ Scan a Directory
```powershell
python error_hawk.py -d "Logs\"
```

### 3️⃣ Scan with Export (Creates Timestamped Folder)
```powershell
python error_hawk.py -d "Logs\" -o report.json --csv report.csv
```
**Output:** `results_YYYYMMDD_HHMMSS\report.json` and `report.csv`

## Common Use Cases

### Daily Log Analysis
```powershell
# Analyzes and creates daily_YYYYMMDD_HHMMSS\ folder
python error_hawk.py -d "C:\Logs\Production\" -o daily_report.json --results-base-name "daily"
```

### Compare Two Time Periods
```powershell
# Before
python error_hawk.py -d "Logs\" -o report.json --results-base-name "before"

# After
python error_hawk.py -d "Logs\" -o report.json --results-base-name "after"
```

### Quick Summary (No Details)
```powershell
python error_hawk.py -d "Logs\" --no-detailed
```

### Analyze Your WB Logs
```powershell
python error_hawk.py -d "Logs\Log_results_WB\" -o wb_analysis.json --csv wb_analysis.csv
```

### Analyze Your Ikea Logs
```powershell
python error_hawk.py -d "Logs\Logs_results_Ikea\" -o ikea_analysis.json --csv ikea_analysis.csv
```

### Analyze All Logs Together
```powershell
python error_hawk.py -d "Logs\" -o full_analysis.json --csv full_analysis.csv --results-base-name "complete"
```

## Command-Line Options Quick Reference

| Option | Description | Example |
|--------|-------------|---------|
| `-f FILE` | Scan single file | `-f "app.log"` |
| `-d DIR` | Scan directory | `-d "Logs\"` |
| `--no-recursive` | Don't scan subdirectories | `--no-recursive` |
| `-e .EXT` | Custom file extensions | `-e .log .txt .err` |
| `-o FILE` | Export to JSON | `-o report.json` |
| `--csv FILE` | Export to CSV | `--csv report.csv` |
| `--no-detailed` | Summary only | `--no-detailed` |
| `--max-lines N` | Limit output lines | `--max-lines 50` |
| `--results-base-name NAME` | Custom folder name | `--results-base-name "daily"` |
| `--no-results-folder` | Use current directory | `--no-results-folder` |
| `--patterns FILE` | Custom error patterns | `--patterns custom.json` |
| `--case-sensitive` | Case-sensitive matching | `--case-sensitive` |

## Output Structure

### With Timestamped Folders (Default)
```
Log Analyzer Tool\
├── results_20260122_145655\
│   ├── report.json
│   └── report.csv
├── daily_20260122_150130\
│   └── daily_report.json
└── ...
```

### Without Timestamped Folders
```powershell
python error_hawk.py -d "Logs\" -o report.json --no-results-folder
```
Creates: `report.json` in current directory

## Error Patterns Detected

✅ Access Violations  
✅ Index Out of Bounds  
✅ Null References  
✅ Memory Errors  
✅ Connection Failures  
✅ File Not Found  
✅ Stack Overflow  
✅ Timeout Errors  
✅ Database Errors  
✅ General Exceptions  

## Tips & Tricks

### 💡 Tip 1: Archive Old Results
```powershell
# Move old results to archive
New-Item -ItemType Directory -Path "Archive" -Force
Move-Item -Path "results_*" -Destination "Archive\"
```

### 💡 Tip 2: Schedule Daily Analysis
Create a scheduled task in Windows Task Scheduler:
```powershell
cd "C:\Path\To\errorhawk-tool"
python error_hawk.py -d "C:\Logs\" -o daily.json --results-base-name "daily"
```

### 💡 Tip 3: Compare Results
```powershell
# Export from multiple runs, then compare JSON files
python error_hawk.py -d "Logs\" -o baseline.json --results-base-name "baseline"
# Wait for changes...
python error_hawk.py -d "Logs\" -o current.json --results-base-name "current"
```

### 💡 Tip 4: Filter by File Type
```powershell
# Only scan .log files
python error_hawk.py -d "Logs\" -e .log -o report.json

# Scan multiple types
python error_hawk.py -d "Logs\" -e .log .txt .err -o report.json
```

### 💡 Tip 5: Custom Error Patterns
Edit `error_patterns.json`:
```json
{
  "my_custom_error": [
    "CustomError:",
    "MyApp failed",
    "regex.*pattern"
  ]
}
```
Then use:
```powershell
python error_hawk.py -d "Logs\" --patterns error_patterns.json -o report.json
```

## Troubleshooting

### ❓ No files found?
- Check the directory path is correct
- Verify file extensions (default: .log, .txt)
- Use `-e .log .txt .err` to specify extensions

### ❓ Permission denied?
- Run PowerShell as Administrator
- Check file/folder permissions

### ❓ Want to see detailed errors?
- Remove `--no-detailed` flag
- Use `--max-lines 500` to see more errors

### ❓ Results folder not created?
- Make sure you use `-o` or `--csv` option
- Check you didn't use `--no-results-folder`

## Performance

- **Fast scanning**: ~1000 lines/second
- **Memory efficient**: Reads files line-by-line
- **Scalable**: Can handle thousands of files

## File Formats

### JSON Output
```json
{
  "analysis_date": "2026-01-22T14:56:55",
  "total_files_scanned": 15,
  "total_lines_scanned": 4748,
  "files_with_errors": ["file1.log", "file2.log"],
  "error_counts": {
    "general_exception": 5,
    "timeout_error": 1
  },
  "detailed_results": { ... }
}
```

### CSV Output
```csv
Error Type,File,Line Number,Content
general_exception,app.log,123,Error: Connection failed
timeout_error,app.log,456,Operation timed out
```

## Integration Examples

### PowerShell Script
```powershell
# daily_scan.ps1
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
python error_hawk.py -d "C:\Logs" -o "report.json" --results-base-name "scan_$timestamp"

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Scan completed successfully" -ForegroundColor Green
} else {
    Write-Host "❌ Scan failed" -ForegroundColor Red
}
```

### Batch File
```batch
@echo off
cd /d "%~dp0"
python error_hawk.py -d "Logs\" -o report.json --csv report.csv
if %ERRORLEVEL% EQU 0 (
    echo Scan completed successfully
) else (
    echo Scan failed
)
pause
```

## Getting Help

```powershell
python error_hawk.py --help
```

## Version Information

**Current Version:** 2.0  
**Release Date:** January 22, 2026  
**Python Required:** 3.6+  
**Platform:** Windows, Linux, macOS  

## What's New in 2.0

🎉 **Automatic Timestamped Results Folders**
- Every run creates a unique folder
- No more overwriting previous results
- Easy historical tracking

🎉 **Custom Folder Naming**
- Use `--results-base-name` for meaningful names
- Great for scheduled tasks and automation

🎉 **Better Organization**
- All reports from one run kept together
- Sortable by timestamp
- Archive-friendly

---

**Need more help?** Check:
- `README.md` - Full documentation
- `FEATURES.md` - Complete feature list
- `QUICKSTART.md` - Quick start examples
- `WORKFLOW.md` - How it works

**Ready to analyze logs?** Just run:
```powershell
python error_hawk.py -d "Logs\" -o report.json --csv report.csv
```

🎉 **Happy Log Analyzing!** 🎉

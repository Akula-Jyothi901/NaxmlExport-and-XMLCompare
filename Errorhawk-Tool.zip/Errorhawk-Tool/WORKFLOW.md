# Workflow Diagram: Automatic Timestamped Folders

## Before Enhancement (Old Behavior)

```
┌─────────────────────────────────────────────┐
│  User runs: python error_hawk.py -o      │
│             report.json                     │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────┐
│  Script scans logs                          │
│  Finds errors                               │
│  Generates report                           │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────┐
│  Output: report.json (current directory)    │
│  ⚠️  WARNING: Overwrites previous report!   │
└─────────────────────────────────────────────┘
```

## After Enhancement (New Behavior)

```
┌─────────────────────────────────────────────┐
│  User runs: python error_hawk.py Logs    │
│  (or analyze_logs.bat)                      │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────┐
│  Script creates timestamped folder:         │
│  results_20260123_145655/                   │
│  ✅ Unique name based on current time       │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────┐
│  Script loads patterns from                 │
│  input_keywords.txt automatically           │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────┐
│  Script scans logs                          │
│  Finds errors                               │
│  Generates reports                          │
└────────────────┬────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────┐
│  Output:                                    │
│  results_20260123_145655/                   │
│    ├── analysis_summary.txt                 │
│    └── analysis_report.html (with links!)   │
│  ✅ Previous reports preserved!             │
└─────────────────────────────────────────────┘
```

## Feature Flow

```
                    START
                      │
                      ▼
        ┌─────────────────────────┐
        │ Parse command-line args │
        └────────────┬────────────┘
                     │
                     ▼
        ┌─────────────────────────┐
        │ Load patterns from      │
        │ input_keywords.txt      │
        │ (automatic)             │
        └────────────┬────────────┘
                     │
                     ▼
        ┌─────────────────────────┐
        │ Check if                │
        │ --no-results-folder     │
        │ is set?                 │
        └────┬────────────────┬───┘
             │ Yes            │ No
             │                │
             ▼                ▼
    ┌────────────┐   ┌─────────────────┐
    │Use current │   │Create timestamped│
    │directory   │   │folder with       │
    │            │   │base_name         │
    └─────┬──────┘   └────┬────────────┘
          │               │
          │               ▼
          │        ┌──────────────────────┐
          │        │ Check if folder      │
          │        │ already exists?      │
          │        └────┬────────────┬────┘
          │             │ No         │ Yes
          │             │            │
          │             │            ▼
          │             │      ┌──────────────┐
          │             │      │Add increment  │
          │             │      │suffix (_1,_2)│
          │             │      └──────┬───────┘
          │             │             │
          │             └─────────────┘
          │                   │
          ▼                   ▼
    ┌─────────────────────────────────┐
    │ Scan log files                  │
    │ Detect errors                   │
    │ Print results to console        │
    └───────────────┬─────────────────┘
                    │
                    ▼
         ┌──────────────────────┐
         │ Auto-export both:    │
         │ 1. Text report (.txt)│
         │ 2. HTML report (.html)│
         │ to results folder    │
         └──────────┬───────────┘
                    │
                    ▼
                   END
```

## Decision Tree

```
                Export requested?
                      │
        ┌─────────────┴─────────────┐
        │                           │
       NO                          YES
        │                           │
        ▼                           ▼
   No folder               --no-results-folder?
   created                         │
                     ┌──────────────┴──────────────┐
                     │                             │
                    YES                           NO
                     │                             │
                     ▼                             ▼
              Use current dir           Get --results-base-name
                                               (default: "results")
                                                    │
                                                    ▼
                                         Generate timestamp
                                         (YYYYMMDD_HHMMSS)
                                                    │
                                                    ▼
                                         Create folder:
                                         {base_name}_{timestamp}/
                                                    │
                                                    ▼
                                         Check if exists?
                                                    │
                                    ┌───────────────┴────────────┐
                                    │                            │
                                   NO                          YES
                                    │                            │
                                    ▼                            ▼
                              Use folder               Add suffix _1, _2...
                                                        until unique
```

## Multiple Runs Timeline

```
Time: 14:56:55 → Run 1
    ┌────────────────────────────────────┐
    │ results_20260122_145655/           │
    │   ├── analysis_summary.txt         │
    │   └── analysis_report.html         │
    └────────────────────────────────────┘

Time: 14:58:28 → Run 2 (different logs)
    ┌────────────────────────────────────┐
    │ results_20260122_145828/           │
    │   ├── analysis_summary.txt         │
    │   └── analysis_report.html         │
    └────────────────────────────────────┘

Time: 15:01:30 → Run 3 (same directory again)
    ┌────────────────────────────────────┐
    │ results_20260122_150130/           │
    │   ├── analysis_summary.txt         │
    │   └── analysis_report.html         │
    └────────────────────────────────────┘

Result: All three runs preserved independently! ✅
```

## Collision Handling

```
Scenario: Folder already exists (rare but possible)

Attempt 1: results_20260122_145655/
           ▼
         ❌ Exists!
           ▼
Attempt 2: results_20260122_145655_1/
           ▼
         ❌ Exists!
           ▼
Attempt 3: results_20260122_145655_2/
           ▼
         ✅ Success! Use this one.
```

## Export Path Construction

```
Input Command:
python error_hawk.py Logs --results-base-name "daily"

Step-by-step:
1. base_name = "daily"                  ← From --results-base-name
2. timestamp = "20260122_150130"        ← Current datetime
3. folder = "daily_20260122_150130"     ← Combine
4. Create folder ✅
5. auto_text = "analysis_summary.txt"   ← Auto-generated
6. auto_html = "analysis_report.html"   ← Auto-generated
7. full_path_txt = "daily_20260122_150130/analysis_summary.txt" ← Join
8. full_path_html = "daily_20260122_150130/analysis_report.html" ← Join
9. Write both files ✅

Final Result:
📁 daily_20260122_150130/
   ├── 📄 analysis_summary.txt
   └── 🌐 analysis_report.html (with clickable file links!)
```

---

## Visual Summary

### Old Way ❌
```
run 1 → report.json (overwritten)
run 2 → report.json (overwritten)
run 3 → report.json (only this survives)
```

### New Way ✅
```
run 1 → results_20260122_145655/
          ├── analysis_summary.txt ✓
          └── analysis_report.html ✓
run 2 → results_20260122_145828/
          ├── analysis_summary.txt ✓
          └── analysis_report.html ✓
run 3 → results_20260122_150130/
          ├── analysis_summary.txt ✓
          └── analysis_report.html ✓
        (all preserved!)
```

---

**Key Advantages:**
- Every analysis is preserved with its execution timestamp!
- Patterns automatically loaded from `input_keywords.txt`
- Both text and HTML reports generated automatically
- HTML report includes clickable `file://` links to open log files directly
- Professional styling with CSS (modern blue/purple gradient theme)
- Interactive navigation and error counts by file section

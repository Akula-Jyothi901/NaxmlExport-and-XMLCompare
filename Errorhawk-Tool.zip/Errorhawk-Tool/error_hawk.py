#!/usr/bin/env python3
"""
ErrorHawk
Advanced error detection system for log file analysis.
Supports both single file and directory scanning with multiple detection modes.
"""

import os
import re
import argparse
from pathlib import Path
from collections import defaultdict
from datetime import datetime
from html_report_generator import generate_html_report


def load_keywords_from_file(keywords_file):
    """
    Load error keywords/patterns from a text file with categories.
    Lines starting with # followed by a category name (e.g., # CRITICAL) define categories.
    Subsequent lines are patterns for that category.
    Returns a dictionary: {category: [patterns]}
    """
    categorized_patterns = {}
    current_category = 'UNCATEGORIZED'
    
    try:
        with open(keywords_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                # Check if line defines a new category
                if line.startswith('#'):
                    # Extract category name (e.g., "# CRITICAL" -> "CRITICAL")
                    category_match = re.match(r'^#\s*([A-Z][A-Z\s]+)$', line, re.IGNORECASE)
                    if category_match:
                        current_category = category_match.group(1).strip().upper()
                        if current_category not in categorized_patterns:
                            categorized_patterns[current_category] = []
                    continue
                
                # Add pattern to current category
                if current_category not in categorized_patterns:
                    categorized_patterns[current_category] = []
                categorized_patterns[current_category].append(line)
                
    except Exception as e:
        print(f"Error loading keywords: {e}")
    
    return categorized_patterns


def get_general_error_patterns():
    """
    Returns heuristic-based error detection patterns organized by severity.
    These patterns detect common error formats without requiring a keyword file.
    """
    return {
        'CRITICAL': [
            r'(?:stack\s+overflow|stackoverflow)',
            r'(?:segmentation\s+fault|segfault)',
            r'(?:out\s+of\s+memory|oom|memory\s+error)',
            r'(?:fatal\s+error|\[fatal\])',
            r'(?:core\s+dump(?:ed)?)',
            r'(?:access\s+violation)',
            r'(?:kernel\s+panic)',
            r'(?:system\s+crash)',
        ],
        'ERROR': [
            r'\b(?:error|err)\s*[:=]\s*\d+',  # Error codes like "error: 404"
            r'\[error\]',
            r'\berror\b.*exception',
            r'exception\s+(?:in|at|occurred)',
            r'(?:null\s+(?:reference|pointer)|nullpointer|nullreference)',
            r'(?:index\s+out\s+of\s+(?:bounds|range))',
            r'(?:file\s+not\s+found|filenotfound)',
            r'(?:connection\s+(?:refused|failed|error))',
            r'(?:database\s+error|db\s+error)',
            r'(?:query\s+failed)',
            r'(?:permission\s+denied)',
            r'(?:access\s+denied)',
            r'(?:http\s+[45]\d{2})',  # HTTP 4xx and 5xx errors
            r'(?:exit\s+code\s+[1-9]\d*)',  # Non-zero exit codes
            r'(?:failed\s+to\s+(?:load|open|read|write|connect))',
            r'(?:unable\s+to\s+(?:load|open|read|write|connect))',
            r'(?:could\s+not\s+(?:load|open|read|write|connect))',
        ],
        'WARNING': [
            r'\[warn(?:ing)?\]',
            r'\bwarning\b',
            r'(?:timeout|timed\s+out)',
            r'(?:retry(?:ing)?|retrying)',
            r'(?:deprecated)',
            r'(?:slow\s+(?:query|request|operation))',
            r'(?:performance\s+(?:issue|warning|degradation))',
            r'(?:disk\s+space\s+(?:low|warning))',
            r'(?:memory\s+usage\s+(?:high|warning))',
        ]
    }


def get_severity_level(error_type_name):
    """Determine severity level based on error type name for JIRA categorization."""
    error_type_upper = error_type_name.upper()
    
    critical_keywords = ['ACCESS VIOLATION', 'MEMORY ERROR', 'SEGMENTATION FAULT', 'STACK OVERFLOW', 
                        'FATAL ERROR', 'ACCESS DENIED', 'PERMISSION DENIED', 'UNAUTHORIZED ACCESS',
                        'KERNEL PANIC', 'SYSTEM CRASH', 'CORE DUMP']
    error_keywords = ['NULL REFERENCE', 'NULL POINTER', 'INDEX OUT OF BOUNDS', 'FILE NOT FOUND',
                     'DATABASE ERROR', 'CONNECTION ERROR', 'QUERY FAILED', 'OBJECT REFERENCE NOT SET', 
                     'EXCEPTION', 'HTTP 4', 'HTTP 5', 'EXIT CODE']
    
    if any(keyword in error_type_upper for keyword in critical_keywords):
        return 'CRITICAL'
    elif any(keyword in error_type_upper for keyword in error_keywords):
        return 'ERROR'
    else:
        return 'WARNING'


def get_impact_assessment(severity):
    """Get impact assessment message for JIRA tickets."""
    impacts = {
        'CRITICAL': 'Immediate action required - System stability affected',
        'ERROR': 'Requires investigation - Functionality impaired',
        'WARNING': 'Monitor - Potential issue detected'
    }
    return impacts.get(severity, 'Review recommended')


def get_recommended_action(error_type_name):
    """Get recommended action based on error type for JIRA tickets."""
    error_type_upper = error_type_name.upper()
    
    if 'ACCESS VIOLATION' in error_type_upper:
        return 'Check memory allocation and pointer usage'
    elif 'NULL REFERENCE' in error_type_upper or 'NULL POINTER' in error_type_upper:
        return 'Verify object initialization before access'
    elif 'FILE NOT FOUND' in error_type_upper:
        return 'Validate file path and permissions'
    elif 'CONNECTION' in error_type_upper:
        return 'Check network connectivity and service availability'
    elif 'TIMEOUT' in error_type_upper:
        return 'Review performance and increase timeout thresholds'
    elif 'DATABASE' in error_type_upper:
        return 'Check database connectivity and query syntax'
    elif 'PERMISSION' in error_type_upper or 'ACCESS DENIED' in error_type_upper:
        return 'Verify user permissions and access rights'
    elif 'MEMORY' in error_type_upper:
        return 'Investigate memory leaks and optimize resource usage'
    elif 'INDEX OUT OF BOUNDS' in error_type_upper:
        return 'Validate array bounds and collection sizes'
    elif 'STACK OVERFLOW' in error_type_upper:
        return 'Review recursion depth and stack allocation'
    elif 'HTTP 4' in error_type_upper or 'HTTP 5' in error_type_upper:
        return 'Check API endpoints and server configuration'
    elif 'QUERY' in error_type_upper:
        return 'Review SQL query syntax and database schema'
    elif 'DEPRECATED' in error_type_upper:
        return 'Update code to use recommended alternatives'
    elif 'PERFORMANCE' in error_type_upper or 'SLOW' in error_type_upper:
        return 'Optimize code performance and resource utilization'
    else:
        return 'Investigate error details and logs for root cause'


def get_detection_method(detection_mode='keywords'):
    """Get detection method description for JIRA tickets."""
    methods = {
        'keywords': 'Keywords-based Detection',
        'general': 'General Heuristic Detection',
        'both': 'Combined Detection (Keywords + Heuristics)'
    }
    return methods.get(detection_mode, 'Keywords-based Detection')


class LogAnalyzer:
    """
    A tool to analyze log files for error patterns.
    Supports multiple detection modes: keyword-based, general heuristics, or both.
    """
    def __init__(self, patterns=None, extensions=None, case_sensitive=False, detection_mode='keywords'):
        """
        Initialize the LogAnalyzer.
        
        Args:
            patterns: Dict of categorized patterns (if None, loads based on detection_mode)
            extensions: List of file extensions to scan (default: ['.log', '.txt'])
            case_sensitive: Whether pattern matching is case-sensitive (default: False)
            detection_mode: 'keywords', 'general', or 'both' (default: 'keywords')
        """
        self.extensions = extensions or ['.log', '.txt']
        self.case_sensitive = case_sensitive
        self.detection_mode = detection_mode
        
        # Load patterns based on detection mode
        if patterns is None:
            if detection_mode == 'keywords':
                patterns = load_keywords_from_file('input_keywords.txt')
            elif detection_mode == 'general':
                patterns = get_general_error_patterns()
            elif detection_mode == 'both':
                # Combine both keyword-based and general patterns
                keyword_patterns = load_keywords_from_file('input_keywords.txt')
                general_patterns = get_general_error_patterns()
                patterns = self._merge_patterns(keyword_patterns, general_patterns)
            else:
                raise ValueError(f"Invalid detection_mode: {detection_mode}. Use 'keywords', 'general', or 'both'")
        
        self.categorized_patterns = patterns
        
        # Compile patterns for better performance, organized by category
        flags = 0 if case_sensitive else re.IGNORECASE
        self.compiled_patterns = {}
        for category, pattern_list in self.categorized_patterns.items():
            self.compiled_patterns[category] = [
                (re.compile(pat, flags), pat) for pat in pattern_list
            ]
        
        # Storage for results - now organized by category
        self.results = defaultdict(list)
        self.error_counts = defaultdict(int)
        self.files_with_errors = set()
        self.total_lines_scanned = 0
        self.total_files_scanned = 0
    
    def _merge_patterns(self, keyword_patterns, general_patterns):
        """
        Merge keyword-based and general patterns, avoiding duplicates.
        
        Args:
            keyword_patterns: Dict of patterns from keyword file
            general_patterns: Dict of heuristic patterns
            
        Returns:
            Merged dictionary of patterns
        """
        merged = defaultdict(list)
        
        # Add all keyword patterns
        for category, patterns in keyword_patterns.items():
            merged[category].extend(patterns)
        
        # Add general patterns, avoiding duplicates
        for category, patterns in general_patterns.items():
            for pattern in patterns:
                if pattern not in merged[category]:
                    merged[category].append(pattern)
        
        return dict(merged)
    
    def scan_file(self, file_path):
        """
        Scan a single log file for error patterns.
        
        Args:
            file_path: Path to the log file
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            print(f"Warning: File not found: {file_path}")
            return
        
        if not file_path.is_file():
            print(f"Warning: Not a file: {file_path}")
            return
        
        self.total_files_scanned += 1
        print(f"Scanning: {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, start=1):
                    self.total_lines_scanned += 1
                    self._check_line(file_path, line_num, line)
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
    
    def scan_directory(self, dir_path, recursive=True):
        """
        Scan a directory for log files.
        
        Args:
            dir_path: Path to the directory
            recursive: Whether to scan subdirectories (default: True)
        """
        dir_path = Path(dir_path)
        
        if not dir_path.exists():
            print(f"Error: Directory not found: {dir_path}")
            return
        
        if not dir_path.is_dir():
            print(f"Error: Not a directory: {dir_path}")
            return
        
        print(f"Scanning directory: {dir_path}")
        print(f"Looking for files with extensions: {', '.join(self.extensions)}")
        print(f"Recursive scan: {recursive}\n")
          # Find all matching files
        pattern = '**/*' if recursive else '*'
        files_found = []
        
        for ext in self.extensions:
            files_found.extend(dir_path.glob(f"{pattern}{ext}"))
        
        if not files_found:
            print(f"No log files found in {dir_path}")
            return
        
        print(f"Found {len(files_found)} log file(s) to scan.\n")
        for file_path in sorted(files_found):
            self.scan_file(file_path)
    
    def _check_line(self, file_path, line_num, line):
        """
        Check a single line against all error patterns.
        
        Args:
            file_path: Path to the file being scanned
            line_num: Line number in the file
            line: The line content
        """
        line_stripped = line.strip()
        matched = False
        
        # Check each category's patterns
        for category, pattern_list in self.compiled_patterns.items():
            for compiled_pattern, original_pattern in pattern_list:
                if compiled_pattern.search(line_stripped):
                    self.results[category].append({
                        'file': str(file_path),
                        'line_num': line_num,
                        'content': line_stripped,
                        'pattern': original_pattern
                    })
                    self.error_counts[category] += 1
                    self.files_with_errors.add(str(file_path))
                    matched = True
                    break  # Only count first match per category
            
            if matched:
                break  # Only assign to first matching category
                self.files_with_errors.add(str(file_path))
                break
    
    def print_results(self, detailed=True, max_lines_per_error=100):
        """
        Print the analysis results.
        
        Args:
            detailed: Whether to print detailed error lines (default: True)
            max_lines_per_error: Maximum error lines to display per error type
        """
        print("\n" + "=" * 80)
        print("LOG ANALYSIS RESULTS")
        print("=" * 80)
        print(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Total Files Scanned: {self.total_files_scanned}")
        print(f"Total Lines Scanned: {self.total_lines_scanned:,}")
        print(f"Files with Errors: {len(self.files_with_errors)}")
        print(f"Total Errors Found: {sum(self.error_counts.values()):,}")
        print("=" * 80)
        
        if not self.results:
            print("\n✓ No errors found in the scanned log files!")
            return
        
        # Summary by error type
        print("\nERROR SUMMARY BY TYPE:")
        print("-" * 80)
        for error_type in sorted(self.error_counts.keys(), key=lambda x: self.error_counts[x], reverse=True):
            count = self.error_counts[error_type]
            print(f"  {error_type.upper().replace('_', ' ')}: {count:,} occurrence(s)")
        
        # Detailed error listings
        if detailed:
            print("\nDETAILED ERROR LISTINGS:")
            print("=" * 80)
            
            for error_type in sorted(self.results.keys()):
                errors = self.results[error_type]
                print(f"\n[{error_type.upper().replace('_', ' ')}] - {len(errors)} occurrence(s)")
                print("-" * 80)
                
                displayed = 0
                for error in errors:
                    if displayed >= max_lines_per_error:
                        remaining = len(errors) - displayed
                        print(f"  ... and {remaining} more occurrence(s) (limit reached)")
                        break
                    
                    print(f"  File: {error['file']}")
                    print(f"  Line: {error['line_num']}")
                    print(f"  Content: {error['content'][:200]}...")
                    print()
                    displayed += 1
        
        print("=" * 80)
    
    def export_to_text_report(self, output_file):
        """
        Export results to a human-readable text report file.
        
        Args:
            output_file: Path to the output text file
        """
        try:
            # Ensure parent directory exists
            os.makedirs(os.path.dirname(output_file) or '.', exist_ok=True)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                # Header
                f.write("=" * 100 + "\n")
                f.write("LOG ANALYSIS REPORT\n")
                f.write("=" * 100 + "\n\n")
                
                # Analysis Metadata
                f.write("ANALYSIS METADATA\n")
                f.write("-" * 100 + "\n")
                f.write(f"Analysis Date/Time    : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Total Files Scanned   : {self.total_files_scanned:,}\n")
                f.write(f"Total Lines Scanned   : {self.total_lines_scanned:,}\n")
                f.write(f"Files with Errors     : {len(self.files_with_errors):,}\n")
                f.write(f"Total Errors Found    : {sum(self.error_counts.values()):,}\n")
                f.write("\n")
                
                if not self.results:
                    f.write("=" * 100 + "\n")
                    f.write("✓ NO ERRORS FOUND - All log files are clean!\n")
                    f.write("=" * 100 + "\n")
                else:
                    # Error Summary by Type
                    f.write("ERROR SUMMARY BY TYPE\n")
                    f.write("-" * 100 + "\n")                    
                    for error_type in sorted(self.error_counts.keys(), key=lambda x: self.error_counts[x], reverse=True):
                        count = self.error_counts[error_type]
                        error_name = error_type.upper().replace('_', ' ')
                        f.write(f"  {error_name:<40} : {count:>6,} occurrence(s)\n")
                    f.write("\n")
                    
                    # Error Counts by File
                    f.write("ERROR COUNTS BY FILE\n")
                    f.write("-" * 100 + "\n")
                    
                    # Build error counts per file
                    file_error_counts = defaultdict(lambda: defaultdict(int))
                    for error_type, errors in self.results.items():
                        for error in errors:
                            file_path = error['file']
                            file_error_counts[file_path][error_type] += 1
                    
                    # Write error counts by file
                    for idx, file_path in enumerate(sorted(file_error_counts.keys()), start=1):
                        error_counts = file_error_counts[file_path]
                        total_errors = sum(error_counts.values())
                        
                        # Get filename only for display
                        filename = file_path.split('\\')[-1] if '\\' in file_path else file_path.split('/')[-1]
                        f.write(f"\n  {idx}. {filename}\n")
                        f.write(f"     Path: {file_path}\n")
                        
                        # List error types for this file
                        for error_type in sorted(error_counts.keys(), key=lambda x: error_counts[x], reverse=True):
                            count = error_counts[error_type]
                            error_name = error_type.upper().replace('_', ' ')
                            f.write(f"     ├─ {error_name}: {count} occurrence(s)\n")
                        
                        f.write(f"     └─ Total Errors: {total_errors}\n")
                    
                    f.write("\n")
                    
                    # Detailed Error Listings
                    f.write("=" * 100 + "\n")
                    f.write("DETAILED ERROR LISTINGS\n")
                    f.write("=" * 100 + "\n\n")
                    
                    for error_type in sorted(self.results.keys()):
                        errors = self.results[error_type]
                        error_name = error_type.upper().replace('_', ' ')
                        
                        f.write(f"[{error_name}] - {len(errors):,} occurrence(s)\n")
                        f.write("-" * 100 + "\n")
                        
                        for idx, error in enumerate(errors, start=1):
                            f.write(f"\n  Error #{idx}\n")
                            f.write(f"  ├─ File    : {error['file']}\n")
                            f.write(f"  ├─ Line    : {error['line_num']}\n")
                            f.write(f"  └─ Content : {error['content']}\n")
                        
                        f.write("\n" + "=" * 100 + "\n\n")
                
                # Footer
                f.write("\n" + "=" * 100 + "\n")
                f.write("END OF REPORT\n")
                f.write("=" * 100 + "\n")
            print(f"\n✓ Text report saved to: {output_file}")
        except Exception as e:
            print(f"\n✗ Error generating text report: {e}")
    
    def export_to_html_report(self, output_file):
        """
        Export results to a professional HTML report file with clickable hyperlinks to source log files.
        
        Args:
            output_file: Path to the output HTML file
        """
        try:
            # Use the separated module for HTML report generation
            generate_html_report(self, output_file)
        except Exception as e:
            print(f"\n✗ Error generating HTML report: {e}")


def create_results_folder(base_name="results"):
    """
    Create a unique timestamped results folder.
    
    Args:
        base_name: Base name for the results folder (default: "results")
        
    Returns:
        Path to the created results folder
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_name = f"{base_name}_{timestamp}"
    folder_path = Path(folder_name)
    
    # If folder exists (unlikely but possible), add an incrementing suffix
    counter = 1
    while folder_path.exists():
        folder_name = f"{base_name}_{timestamp}_{counter}"
        folder_path = Path(folder_name)
        counter += 1
    
    # Create the folder
    try:
        folder_path.mkdir(parents=True, exist_ok=True)
        print(f"\n✓ Created results folder: {folder_path.absolute()}\n")
        return folder_path
    except Exception as e:
        print(f"\n✗ Error creating results folder: {e}")
        print("Using current directory for output files.\n")
        return Path('.')


def main():
    """
    Main entry point for ErrorHawk.
    """
    parser = argparse.ArgumentParser(
        description='ErrorHawk - Advanced Error Detection System for Log File Analysis',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Scan current directory (default behavior with keyword-based detection)
  python error_hawk.py
  
  # Scan with general heuristic detection (no keyword file needed)
  python error_hawk.py --detection-mode general
  
  # Scan with both keyword and general detection
  python error_hawk.py --detection-mode both
  
  # Scan a specific directory
  python error_hawk.py C:\\Path\\To\\Logs
  python error_hawk.py -d C:\\Path\\To\\Logs
  
  # Scan a single log file with general detection
  python error_hawk.py app.log --detection-mode general
  python error_hawk.py -f path/to/logfile.log
  
  # Scan directory non-recursively
  python error_hawk.py C:\\Path\\To\\Logs --no-recursive
  
  # Export results with custom name
  python error_hawk.py C:\\Path\\To\\Logs -o custom_report.txt
  
  # Scan specific file extensions with combined detection
  python error_hawk.py C:\\Path\\To\\Logs -e .log .txt .err --detection-mode both
        """
    )
    
    # Positional path argument (optional - defaults to current directory)
    parser.add_argument('path', nargs='?', default='.',
                        help='Path to a log file or directory (default: current directory)')
    
    # Optional explicit input options (for backward compatibility)
    parser.add_argument('-f', '--file', help='Path to a single log file (alternative to positional argument)')
    parser.add_argument('-d', '--directory', help='Path to a directory containing log files (alternative to positional argument)')
      # Scanning options
    parser.add_argument('--no-recursive', action='store_true',
                        help='Disable recursive directory scanning (default: recursive)')
    parser.add_argument('-e', '--extensions', nargs='+', default=['.log', '.txt'],
                        help='File extensions to scan (default: .log .txt)')
    
    # Detection mode options
    parser.add_argument('--detection-mode', choices=['keywords', 'general', 'both'], default='keywords',
                        help='Error detection mode: keywords (use input_keywords.txt), general (heuristic patterns), or both (default: keywords)')
    
    # Output options
    parser.add_argument('-o', '--output', help='Export results to text report file (will be placed in timestamped results folder)')
    parser.add_argument('--no-detailed', action='store_true',
                        help='Disable detailed error listings in console output')
    parser.add_argument('--max-lines', type=int, default=100,
                        help='Maximum error lines to display per error type (default: 100)')
    parser.add_argument('--no-results-folder', action='store_true',
                        help='Disable automatic creation of timestamped results folder (use current directory)')
    parser.add_argument('--results-base-name', default='results',
                        help='Base name for the results folder (default: results)')
    
    args = parser.parse_args()
      # Create timestamped results folder by default (unless disabled)
    results_folder = Path('.')
    if not args.no_results_folder:
        results_folder = create_results_folder(args.results_base_name)
    
    # Initialize analyzer with selected detection mode
    analyzer = LogAnalyzer(
        extensions=args.extensions,
        case_sensitive=False,
        detection_mode=args.detection_mode
    )    # Scan files
    print("\n" + "=" * 80)
    print("ERRORHAWK - ADVANCED ERROR DETECTION SYSTEM")
    print("=" * 80 + "\n")
    
    # Display detection mode information
    mode_descriptions = {
        'keywords': 'Keyword-based (using input_keywords.txt)',
        'general': 'General heuristic pattern matching',
        'both': 'Combined (keywords + general patterns)'
    }
    print(f"Detection Mode: {mode_descriptions[args.detection_mode]}")
    print(f"File Extensions: {', '.join(args.extensions)}")
    print(f"Recursive Scan: {'No' if args.no_recursive else 'Yes'}")
    print()
    
    # Determine what to scan - priority: explicit flags > positional argument
    target_path = None
    is_file_scan = False
    
    if args.file:
        # Explicit file flag takes priority
        target_path = args.file
        is_file_scan = True
    elif args.directory:
        # Explicit directory flag takes priority
        target_path = args.directory
        is_file_scan = False
    else:
        # Use positional argument (defaults to '.' if not provided)
        target_path = args.path
        # Auto-detect if it's a file or directory
        path_obj = Path(target_path)
        if path_obj.exists():
            is_file_scan = path_obj.is_file()
        else:
            # If path doesn't exist, assume directory and let error handling deal with it
            is_file_scan = False
    
    # Perform the scan
    if is_file_scan:
        analyzer.scan_file(target_path)
    else:
        analyzer.scan_directory(target_path, recursive=not args.no_recursive)
    
    # Print results
    analyzer.print_results(detailed=not args.no_detailed, max_lines_per_error=args.max_lines)
    
    # Export results to the timestamped folder by default
    if not args.no_results_folder:
        # Auto-save text summary report
        default_report = results_folder / "analysis_summary.txt"
        analyzer.export_to_text_report(str(default_report))
        
        # Auto-save HTML report
        default_html = results_folder / "analysis_report.html"
        analyzer.export_to_html_report(str(default_html))
    
    # Export to custom path if requested
    if args.output:
        output_path = results_folder / args.output
        analyzer.export_to_text_report(str(output_path))


if __name__ == '__main__':
    main()

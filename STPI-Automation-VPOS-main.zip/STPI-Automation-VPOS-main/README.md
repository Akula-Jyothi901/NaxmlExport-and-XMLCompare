# STPI-Automation-VPOS
This repository will contain automation framework for Storepoint International's projects.

Follow the document for setup & running Automation test scripts 
https://confluence.ncr.com/display/STOR/VPOS+Automation+Setup?preview=/518736620/518736625/StorePoint_Automation_Framework_setup_guide.doc

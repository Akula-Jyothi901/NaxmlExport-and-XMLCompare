import configparser
import os
from configparser import ConfigParser
from features.utils.PumpOperations import PumpOperations
from features.utils.vposOperations import getAuthToken

config = configparser.ConfigParser()
def before_feature(context,feature):

    thisfolder = os.path.dirname(os.path.abspath(__file__))
    my_file = (os.path.join(thisfolder + '\configFiles\config.ini'))
    config.read(my_file)
    context.VPOSServer = config.get('paths', 'VPOSServer')
    context.GET_PUMP_TRANSACTION_URL = config.get('paths', 'GET_PUMP_TRANSACTION_URL')
    context.GET_TRANSACTION_URL = config.get('paths', 'GET_TRANSACTION_URL')
    context.AUTHORIZE_PUMP_URL = config.get('paths', 'AUTHORIZE_PUMP_URL')
    context.CANCEL_AUTHORIZE_PUMP_URL = config.get('paths', 'CANCEL_AUTHORIZE_PUMP_URL')
    context.LOCK_TRANSACTION_URL = config.get('paths', 'LOCK_TRANSACTION_URL')
    context.SAVE_TRANSACTION_URL = config.get('paths', 'SAVE_TRANSACTION_URL')
    context.VOIDALL_TRANSACTION_URL = config.get('paths', 'VOIDALL_TRANSACTION_URL')
    context.PAY_TRANSACTION_URL = config.get('paths', 'PAY_TRANSACTION_URL')
    context.AUTHORIZE_TRANSACTION_URL = config.get('paths', 'AUTHORIZE_TRANSACTION_URL')
    context.SITEINFO_URL = config.get('paths', 'SITEINFO_URL')
    context.AUTH_URL = config.get('paths', 'AUTH_URL')
    context.GET_PUMP_TRANSACTION_ByFilter_URL = config.get('paths', 'GET_PUMP_TRANSACTION_ByFilter_URL')
    context.ADD_LPE_LOYALTY_URL= config.get('paths', 'ADD_LPE_LOYALTY_URL')

    #..Load JsonElements
    context.PumpNumber = config.get('JsonElements','PumpNumber')
    context.LimitType = config.get('JsonElements', 'LimitType')
    context.PresetAmount = config.get('JsonElements', 'PresetAmount')
    context.GradeId = config.get('JsonElements', 'GradeId')
    context.NozzlePosition = config.get('JsonElements', 'NozzlePosition')
    context.externalTransID = int(config.get('JsonElements', 'externalTransID'))
    context.externalTransID = context.externalTransID + 5
    context.executeFlag = False

    context.barcode = int(config.get('JsonElements', 'barcode'))
    context.price = config.get('JsonElements', 'price')
    context.quantity = int(config.get('JsonElements', 'quantity'))
    #ITem has negative stock --- bar code : 400206


    #PumpTransactionElements
    context.OutDoorPosition = config.get('PumpTransactionElements', 'outdoorpostion')
    context.Amount = config.get('PumpTransactionElements', 'Amount')
    context.pumpId = config.get('PumpTransactionElements', 'pumpId')
    context.PumpTrsId = config.get('PumpTransactionElements', 'PumpTrsId')
    context.PumpSrvRef = config.get('PumpTransactionElements', 'PumpSrvRef')
    context.PumpTrsId1 = config.get('PumpTransactionElements', 'PumpTrsId1')
    context.PumpTrsId2 = config.get('PumpTransactionElements', 'PumpTrsId2')



    # ..Load CreditPayment
    context.AmountZero = config.get('CreditPayment', 'AmountZero')
    context.AmountNegative = config.get('CreditPayment', 'AmountNegative')
    context.AmountLarge = config.get('CreditPayment', 'AmountLarge')



    if not os.path.isfile(my_file):
        # Create the configuration file as it doesn't exist yet
        cfgfile = open(my_file, "w")
        # Add content to the file
        Config = ConfigParser.ConfigParser()
        Config.set("JsonElements", "externalTransID",context.externalTransID)
        Config.write(cfgfile)
        cfgfile.close()

    context.access_token = getAuthToken(context)
    print("Valid access_token : ", context.access_token)



def after_scenario(context,scenario):
    print("Scenario executed : " + str(scenario))
    # if (context.executeFlag == True):
    #     print("-------inside if ")
    #     #voidtransaction(context)

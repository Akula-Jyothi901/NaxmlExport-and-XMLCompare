from features.steps.VPOSPumpTransactionsAPISteps import global_general_variables, headers, logger
import requests
import json
import os
import time
from features.utils.PumpOperations import PumpOperations



def  getAuthToken(context):
    print("Execute Authentication Req : ")
    url_temp = context.VPOSServer + context.AUTH_URL
    jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthenticationAPI.json')
    logger.info(url_temp)
    with open(jsonFile) as f:
        data1 = json.load(f)
    logger.info("Request Json:")
    logger.info(data1)
    payload = json.dumps(data1, indent=4)
    response = requests.request("POST", url_temp, headers=headers, data=payload)
    logger.info("Response  Data :")
    logger.info(response.text)
    current_json = response.json()
    global_general_variables['access_token'] = current_json['token']
    access_token = current_json['token']
    return access_token

def  performAuthorizeWithDryItems(context):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL
    jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
    logger.info(url_temp)
    with open(jsonFile) as f:
        data1 = json.load(f)
    logger.info("Request Json:")
    logger.info(data1)
    payload = json.dumps(data1, indent=4)
    response = requests.request("POST", url_temp, headers=headers, data=payload)
    logger.info("Authorize with Dry  items Response  Data :")
    logger.info(response.text)
    current_json = response.json()
    return current_json

def  addLPELoyaltyToTransaction(context,lpe_url,addlpejsonfile, sessionId):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    #update sessionId in Addloyaltyjson file
    with open(addlpejsonfile, "r") as jsonFile:
        data = json.load(jsonFile)
    data['sessionId'] = sessionId
    with open(addlpejsonfile, "w") as jsonFile:
        json.dump(data, jsonFile)

    with open(addlpejsonfile) as f:
        data1 = json.load(f)
    logger.info("Request Json: " +str(data1))
    payload = json.dumps(data1, indent=4)
    response = requests.request("POST", lpe_url, headers=headers, data=payload)
    logger.info("Add LPE Promotions data to the transaction :" +response.text)
    current_json = response.json()
    return current_json

def  performGetTransaction(context,sessionId):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.GET_TRANSACTION_URL
    params = {'SessionId': sessionId}
    response = requests.request("GET", url_temp, headers=headers,params=params)
    current_json = response.json()
    logger.info("Get transaction executed successfuly with response : ",current_json)
    return current_json

def  performAuthorizeWithFuelItems(context):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL
    jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
    logger.info(url_temp)
    with open(jsonFile) as f:
        data1 = json.load(f)
    logger.info("Request Json:")
    logger.info(data1)
    payload = json.dumps(data1, indent=4)
    response = requests.request("POST", url_temp, headers=headers, data=payload)
    logger.info("Authorize with Fuel item Response  Data :")
    logger.info(response.text)
    current_json = response.json()
    return current_json

def  performPayTransaction(context, jsonFile, posTrandId, amount, self=None):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.PAY_TRANSACTION_URL
    payloadFile = 'features\configFiles\\'+ jsonFile
    payTransactionJsonFile = os.path.join(os.getcwd(), payloadFile)
    PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,posTrandId,amount )
    with open(payTransactionJsonFile) as f:
        data1 = json.load(f)
    logger.info("payload Json:")
    logger.info(data1)
    payload = json.dumps(data1, indent=4)

    response = requests.request("POST", url_temp, headers=headers, data=payload)
    time.sleep(10)
    global_general_variables['response_full'] = response
    global_general_variables['expected_response_code'] = response.status_code
    logger.info("Pay transaction executed successfuly with response : ")
    logger.info(response.text)
    current_json = response.json()
    return current_json

def voidtransaction(context,sessionId):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.VOIDALL_TRANSACTION_URL + sessionId
    logger.info(url_temp)
    response = requests.request("POST", url_temp, headers=headers)
    logger.info("Void all Transactions Response : "  +response.text)
    res_json = response.json()
    return res_json

def  performAuthorizeWithQuantity(context):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL
    jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithQuantity.json')
    logger.info(url_temp)
    with open(jsonFile) as f:
        data1 = json.load(f)
    logger.info("Request Json:")
    logger.info(data1)
    payload = json.dumps(data1, indent=4)
    response = requests.request("POST", url_temp, headers=headers, data=payload)
    logger.info("Authorize with Dry  items Response  Data :")
    logger.info(response.text)
    current_json = response.json()
    return current_json

def updateFuelItemDetailsInJson(context, fileName, itemId, pumpId, pumpTrsId):
    # update pumpId,pumpTrsId in AuthorizeTransactionWith Fuel Json file
    with open(fileName, "r") as jsonFile:
        data = json.load(jsonFile)

    data['transaction']['itemLines'][itemId]['pumpId'] = pumpId
    data['transaction']['itemLines'][itemId]['PumpTrsId'] = pumpTrsId
    with open(fileName, "w") as jsonFile:
        json.dump(data, jsonFile)
    return fileName

def updateQuantityValueInJson(context, fileName, quantityvalue):
    # update Quantity in AuthorizeTransactionWith Fuel Json file
    with open(fileName, "r") as jsonFile:
        data = json.load(jsonFile)
    data['transaction']['itemLines'][0]['quantity'] = quantityvalue
    with open(fileName, "w") as jsonFile:
        json.dump(data, jsonFile)
    return fileName

def  performAuthorizeTransaction(context,FileName):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL
    logger.info(url_temp)
    with open(FileName) as f:
        data1 = json.load(f)
    logger.info("Request Json:" + str(data1))
    payload = json.dumps(data1, indent=4)
    response = requests.request("POST", url_temp, headers=headers, data=payload)
    logger.info("Authorize Transaction Response Data :"+ response.text)
    current_json = response.json()
    return current_json

def  performAuthorizeUpdateTransaction(context,FileName):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL
    logger.info(url_temp)
    with open(FileName) as f:
        data1 = json.load(f)
    logger.info("Request Json:" + str(data1))
    payload = json.dumps(data1, indent=4)
    response = requests.request("PUT", url_temp, headers=headers, data=payload)
    logger.info("Update Authorize Transaction Response Data :"+ response.text)
    current_json = response.json()
    return current_json

def updateTransactionIDInJson(FileName, posTransId):
    with open(FileName, "r") as jsonFile:
        data = json.load(jsonFile)
    data['transaction']['posTransId'] = posTransId

    with open(FileName, "w") as jsonFile:
        json.dump(data, jsonFile)

def validateAmount(fileName):
    with open(fileName, "r") as jsonFile:
        data = json.load(jsonFile)
    #print(data)
    itemsList = data['transaction']['itemLines']
    totalAmt=0
    for item in itemsList:
        try:
            #print("item['price']: ", item['price'])
            amt= item['price']*item['quantity']
            totalAmt=amt+totalAmt
        except Exception as e:
            print("")
    #print(totalAmt)
    return totalAmt


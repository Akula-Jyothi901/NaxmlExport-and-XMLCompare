import autoit
import time
import json
import requests
import os
#from features import data


pumpSrvRef = []
#GetPumpTrasanctionsUrl = data._getPumpTrasanctionsUrl
#AuthorizePumpUrl = data._authorizePumpUrl

# def getPumpTransactions(title=None):
#     print("******************* Get Pump Transactions  ************************* :", GetPumpTrasanctionsUrl)
#     headers = {
#         'Content-Type': 'application/json'
#     }
#     response = requests.request("GET", GetPumpTrasanctionsUrl, headers=headers)
#     jsonResponse = response.json()
#     print(response.text)
#     for i in range(len(jsonResponse['pumpTransactions'])):
#         pumpSrvRefId = jsonResponse["pumpTransactions"][i]['pumpSrvRef']
#         pumpSrvRef.append(pumpSrvRefId)
#         print('-----------------------------pumpSrvRef: ', pumpSrvRef)
#     return pumpSrvRef

def AuthorizePump(AuthorizePumpUrl,pumpSrvRefId=None):
    print(" Authorize Pump Trasnactions starts .... ")
    _fileDir = os.getcwd() + '\GSimulator\configFiles'
    jsonFile = _fileDir + '\AuthorizePump.json'
    with open(jsonFile) as f:
        data1= json.load(f)
    print(data1)
    payload  = json.dumps(data1,indent=4)
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", AuthorizePumpUrl, headers=headers, data=payload)
    r = response.json()
    pumpSrvRefId = r.get("pumpSrvRef")
    print("Authorize Pump Transaction response : ",response.text)
    print(response.status_code)
    return pumpSrvRefId


class PumpOperations:

    title = "GSim Configuration Screen";

    def __init__(self):
        print( "   ")

    def LiftNozzle(title=None):
        autoit.control_focus("Pump #1", "F3 Server 6000000061")
        #autoit.control_click("[Class:#F3 Server 6000000061]", "slider2")
        autoit.mouse_click("left", 223, 497, 1, 2)
        print("Nozzle lifted.. :")
        time.sleep(10)

    def DownNozzle(title=None):
        autoit.control_focus("Pump #1", "F3 Server 6000000061")
        time.sleep(35)
        autoit.mouse_click("left", 221, 493, 1, 2)
        print("Nozzle Down . ")

    def DoFueling(title=None):
        autoit.control_focus("Pump #1", "msctls_trackbar321")
        time.sleep(5)
        autoit.mouse_click("left", 292, 651, 1, 2)
        print("Fueling starts... ")

    def PeformFueling(self):
        print("****** Pump operation start *******************")
        time.sleep(10)
        PumpOperations.LiftNozzle()
        PumpOperations.DoFueling()
        PumpOperations.DownNozzle()
        print("Dispensing Done ")

    def updateJsonFile(self, FileName, AttriName, AttriValue):
        with open(FileName, "r") as f:
            data = json.load(f)
        data[AttriName] = str(AttriValue)
        ## Save our changes to JSON file
        with open(FileName, "w") as f:
            json.dump(data, f)
        with open(FileName) as f:
            data = json.load(f)

    def externalTransID(self, FileName, AttriName, AttriValue):
        with open(FileName, "r") as jsonFile:
            data = json.load(jsonFile)
        data['Transaction'][AttriName] = str(AttriValue)

        ## Save our changes to JSON file
        with open(FileName, "w") as jsonFile1:
            json.dump(data, jsonFile1)
        with open(FileName) as f:
            data = json.load(f)

    def updateNestedJson(self, FileName, PumpTrsId ):
        with open(FileName, "r") as jsonFile:
            data = json.load(jsonFile)
        k = 0
        for i in data['Transaction']['itemLines']:
            for j in data['Transaction']['itemLines'][k]:
                if data['Transaction']['itemLines'][k]['PumpTrsId'] != -1:
                    data['Transaction']['itemLines'][k]['PumpTrsId'] = PumpTrsId
                    break
            k = k + 1
        with open(FileName, "w") as jsonFile:
            json.dump(data, jsonFile)


    def updatePayTransactionJson(self, FileName,sessionID, posTransId,externalTransId, balanceDue):
        with open(FileName, "r") as jsonFile:
            data = json.load(jsonFile)
        data['Transaction']['sessionId'] = sessionID
        data['Transaction']['posTransId'] = posTransId
        data['Transaction']['externalTransId'] = externalTransId
        data['Transaction']['paymentLines'][0]['amount'] = balanceDue
        with open(FileName, "w") as jsonFile:
            json.dump(data, jsonFile)

    def updateTransactionIDAndAmountInJson(self, FileName, posTransId,balanceDue):
        with open(FileName, "r") as jsonFile:
            data = json.load(jsonFile)
        data['Transaction']['posTransId'] = posTransId
        data['Transaction']['paymentLines'][0]['amount'] = balanceDue

        with open(FileName, "w") as jsonFile:
            json.dump(data, jsonFile)


    def createResponseJsonFile(self, FileName,responseText ):
        with open(FileName, "w") as jsonFile:
            json.dump(responseText, jsonFile)

    def verifyResponse(self,FileName):
        with open(FileName, "r") as jsonFile:
            data = json.load(jsonFile)
        print("__________________________________________________")
        print(data["errorcode"] , data["pumpSrvRef"], data["errorMessage"] )
        return data["pumpSrvRef"]
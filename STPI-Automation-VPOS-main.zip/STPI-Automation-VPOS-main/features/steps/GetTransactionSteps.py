
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random
#from random import random

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger()
#logger.setLevel(logging.INFO) #set log level
# define file handler and set formatter
file_handler = logging.FileHandler('logfile.log')
formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(formatter)
# add file handler to logger
#logger.addHandler(file_handler)

@when(u'Raise "{http_request_type}" HTTP request with parameters')
def step_impl(context, http_request_type, self=None):
    if 'GET' == http_request_type:

        if 'pump-transaction' in context.GET_PUMP_TRANSACTION_URL:
            url_temp = context.VPOSServer + context.GET_PUMP_TRANSACTION_URL
            response = requests.request("GET", url_temp,headers=headers)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Get Pump Transactions Response : ")
            logger.info(response.text)

    elif 'POST' == http_request_type:
        print("____1111111111111111111111111_______" )
        if '/authorizeTransaction' in context.AUTHORIZE_TRANSACTION_URL:
            print("_____22222222222222222222______")
            logger.info("Running Authorize transaction API : ")
            scenarioName = context.scenario
            url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL

            if str(scenarioName) == "<Scenario \"Authorize Transaction with Dry Items\">":
                print("Entered into Authorize with dry items ")
                authorizeTransactionJson = os.path.join(os.getcwd(),
                                                        'features\configFiles\AuthorizeTransactionWithDryItems.json')
                #externalTransId = random.randint(4,3999)
                externalTransId  = random.randrange(2, 12999, 7)
                print("_____3333333333333333______", externalTransId)
                PumpOperations.externalTransID(self, authorizeTransactionJson, 'exteralTransId', externalTransId)
                with open(authorizeTransactionJson) as f:
                    data = json.load(f)
                logger.info("Inside ...........payload Json:")
                logger.info(data)
                payload = json.dumps(data, indent=4)
                response = requests.request("POST", url_temp, headers=headers, data=payload)
                global_general_variables['response_full'] = response
                global_general_variables['expected_response_code'] = response.status_code
                logger.info(scenarioName)
                #logger.info(response.text)
                #print("_____3333333333333333______", response.text)
                print("5555555555 ",response.json() )



@then(u'Response BODY validating for "{body_parsing_for}" should be successful')
def step_impl(context, body_parsing_for,self=None):
    #current_json = response.json()
    current_json = global_general_variables['response_full'].json()
       # .json()
    if 'Authorize-transaction' == body_parsing_for:
        logger.info("Response Data  parsing :" + body_parsing_for)
        actualErrorMessage = current_json['transaction']['errorMessage']
        expectedErrorMessage = 'Transaction was processed successfully with errors.'
        logger.info(
            "ErrorCode: " + current_json['transaction']["errorCode"] + "With Error  message: " + actualErrorMessage)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        if (current_json['transaction']['errorCode'] == "0") or (
                current_json['transaction']['errorCode'] == "8017" and expectedErrorMessage == actualErrorMessage):
            assert True, 'Valid error code received with message : ' + expectedErrorMessage
        else:
            context.executeFlag = True
            assert False, 'Invalid error code received with message : ' + actualErrorMessage
        logger.info("Authorize transaction successful with Pos Transaction ID  : ")
        global_general_variables['posTransId'] = current_json['transaction']["posTransId"]
        global_general_variables['externalTransID'] = current_json['transaction']['externalTransID']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
        global_general_variables['Total'] = current_json['transaction']['balanceDue']
        logger.info(global_general_variables['posTransId'])
        logger.info(global_general_variables['externalTransId'])






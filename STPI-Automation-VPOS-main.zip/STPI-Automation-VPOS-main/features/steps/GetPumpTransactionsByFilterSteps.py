
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random
import requests
import logging
from behave import given, when, then

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }
logger  = logging.getLogger("")


@when(u'Raise "{http_request_type}" HTTP request with OutdoorPosition & Amount parameters')
def step_impl(context, http_request_type, self=None, scenarioName=None):
    params = {}
    scenarioName = context.scenario
    global_general_variables['basic_application_URL'] = context.VPOSServer
    url_temp = global_general_variables['basic_application_URL']
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    if 'GET' == http_request_type:
        if 'pump-transactions-by-filter' in  context.GET_PUMP_TRANSACTION_ByFilter_URL:
            url_temp = context.VPOSServer + context.GET_PUMP_TRANSACTION_ByFilter_URL
            if str(scenarioName) == "<Scenario \"Get pump transaction by filter with no configured parameters\">":
                params = {}
            elif str(scenarioName) == "<Scenario \"Get pump transaction by filter with one configured parameters\">":
                params = {'OutdoorPosition':1}
            elif str(scenarioName) == "<Scenario \"Get pump transaction by filter with invalid OutdoorPosition & valid Amount parameters\">":
                params = {'OutdoorPosition': '0', 'Amount':'2.50'}
            elif str(scenarioName) == "<Scenario \"Get pump transaction by filter with valid OutdoorPosition & Invalid Amount parameters\">":
                params = {'OutdoorPosition':1, 'Amount':-2.50}
            elif str(scenarioName) == "<Scenario \"Get pump transaction by filter with valid OutdoorPosition & Amount parameters\">":
                params = {'OutdoorPosition':context.OutDoorPosition, 'Amount':context.Amount}

            response = requests.request("GET", url_temp, headers=headers,params=params)
            logger.info(response.text)
            global_general_variables['response_full'] = response
            logger.info("Get  Pump Transactions by filter Response : ")
            global_general_variables['expected_response_code'] = response.status_code


@then(u'should get Valid HTTP response And Response BODY validating for "{body_parsing_for}" should be successful')
def step_impl(context,body_parsing_for, scenarioName=None):
    current_json = global_general_variables['response_full'].json()
    scenarioName = context.scenario
    if 'GET-Pump-transactions-by-filter' == body_parsing_for:
        logger.info("Response Data  parsing :"+ body_parsing_for)
        if str(scenarioName) == "<Scenario \"Get pump transaction by filter with no configured parameters\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if  str(current_json['errorCode']) == "8037" and current_json['errorMessage'] == "Required parameter/s missing in the Request.":
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        if str(scenarioName) == "<Scenario \"Get pump transaction by filter with one configured parameters\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if  str(current_json['errorCode']) == "8037" and current_json['errorMessage'] == "Required parameter/s missing in the Request.":
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        if str(scenarioName) == "<Scenario \"Get pump transaction by filter with invalid OutdoorPosition & valid Amount parameters\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json[
                'errorMessage'])
            if str(current_json['errorCode']) == "8038" and current_json[ 'errorMessage'] == "Invalid Value passed for Parameter/s in the Request. - OutdoorPosition ":
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        if str(scenarioName) == "<Scenario \"Get pump transaction by filter with valid OutdoorPosition & Invalid Amount parameters\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json[
                'errorMessage'])
            if str(current_json['errorCode']) == "8038" and current_json['errorMessage'] == "Invalid Value passed for Parameter/s in the Request. - Amount ":
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        if str(scenarioName) == "<Scenario \"Get pump transaction by filter with valid OutdoorPosition & Amount parameters\">":
            logger.info("ErrorCode: " + str(current_json['transaction']['errorCode']) + " With Error  message: " + current_json['transaction']['errorMessage'])
            if str(current_json['transaction']['errorCode']) == "0" and current_json['transaction']['errorMessage'] == "OK":
                assert True, 'Valid error code received with message : ' + current_json['transaction']['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']


#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random
import requests
import logging
from behave import given, when, then

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }
logger  = logging.getLogger("")


@when(u'Raise "{http_request_type}" HTTP request with pump parameters')
def step_impl(context, http_request_type, self=None, scenarioName=None):
    params = {}
    scenarioName = context.scenario
    global_general_variables['basic_application_URL'] = context.VPOSServer
    url_temp = global_general_variables['basic_application_URL']
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    if 'GET' == http_request_type:
        if 'pump-transactions' in  context.GET_PUMP_TRANSACTION_URL:
            url_temp = context.VPOSServer + context.GET_PUMP_TRANSACTION_URL
            if str(scenarioName) == "<Scenario \"Get pump transactions to check API disabled without parameters\">":
                params = {}
            elif str(scenarioName) == "<Scenario \"Get pump transactions to check API disabled with pumpid parameters\">":
                params = {'PumpId':1}
            elif str(scenarioName) == "<Scenario \"Get pump transactions to check API disabled with pumpSrvRef parameters\">":
                params = {'PumpSrvRef': '927'}
            elif str(scenarioName) == "<Scenario \"Get pump transactions to check API disabled with  pump id & pumpsrvref parameters\">":
                params = {'PumpId':1, 'PumpSrvRef': 2.50}


            response = requests.request("GET", url_temp, headers=headers,params=params)
            logger.info(response.text)
            global_general_variables['response_full'] = response
            logger.info("Get  Pump Transactions by filter Response : ")
            global_general_variables['expected_response_code'] = response.status_code


@then(u'Valid HTTP response And Response BODY validating for "{body_parsing_for}" should be disabled')
def step_impl(context,body_parsing_for, scenarioName=None):
    errorMessage =  global_general_variables['response_full'].text
    scenarioName = context.scenario
    if 'GET-Pump-transactions' == body_parsing_for:
        logger.info("Response Data  parsing :"+ body_parsing_for)
        if str(scenarioName) == "<Scenario \"Get pump transactions to check API disabled without parameters\">":
            logger.info(" Test executed with Error  message: " + errorMessage)
            if errorMessage == "Access is Forbidden":
                assert True, 'Valid error code received with message : ' + errorMessage
            else:
                assert False, 'Invalid error code received with message : ' + errorMessage
        elif str(scenarioName) == "<Scenario \"Get pump transactions to check API disabled with pumpid parameters\">":
                logger.info(" Test executed with Error  message: " + errorMessage)
                if errorMessage == "Access is Forbidden":
                    assert True, 'Valid error code received with message : ' + errorMessage
                else:
                    assert False, 'Invalid error code received with message : ' + errorMessage
        elif str(scenarioName) == "<Scenario \"Get pump transactions to check API disabled with  pump id & pumpsrvref parameters\">":
            logger.info(" Test executed with Error  message: " + errorMessage)
            if errorMessage == "Access is Forbidden":
                assert True, 'Valid error code received with message : ' + errorMessage
            else:
                assert False, 'Invalid error code received with message : ' + errorMessage
        elif str(scenarioName) == "<Scenario \"GGet pump transactions to check API disabled with pumpSrvRef parameters\">":
            logger.info(" Test executed with Error  message: " + errorMessage)
            if errorMessage == "Access is Forbidden":
                assert True, 'Valid error code received with message : ' + errorMessage
            else:
                assert False, 'Invalid error code received with message : ' + errorMessage



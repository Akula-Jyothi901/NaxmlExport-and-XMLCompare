#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations
from features.utils.vposOperations import performAuthorizeWithDryItems, addLPELoyaltyToTransaction, \
    performGetTransaction, performPayTransaction, performAuthorizeWithQuantity, voidtransaction, \
    updateFuelItemDetailsInJson, performAuthorizeTransaction, updateQuantityValueInJson, validateAmount

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("")
addlpedata = 'features\configFiles\\' + "AddLPEData.json"
addlpejsonfile = os.path.join(os.getcwd(), addlpedata)


@when(u'Execute "{http_request_type}" HTTP request')
def step_impl(context, http_request_type, self=None):
    scenarioName = context.scenario
    if str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item not found and void transaction\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionNotFoundItems.json')

        current_json = performAuthorizeTransaction(context, jsonFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue']= current_json['transaction']['balanceDue']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Authorize Transaction with Not for Sale Item\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTrsNotForSaleItem.json')

        current_json = performAuthorizeTransaction(context, jsonFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue']= current_json['transaction']['balanceDue']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item amount X,Qty1 , Fuel Item and void transaction\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
        itemId = 1
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)

        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue']= current_json['transaction']['balanceDue']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item amount X,Qty1 , Fuel Item Partial Payment and void transaction\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
        itemId = 1
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)

        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        partialAmount = 0.10  # For Partial Payment
        performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'],partialAmount , self=None)

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with Fuel Item and void transaction\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
        itemId = 0
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)
        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with Fuel Item, Partial Payment and void transaction\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
        itemId = 0
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)
        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        partialAmount = 0.10  # For Partial Payment
        performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], partialAmount, self=None)

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with Fuel Item - End to End Flow\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
        itemId = 0
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)
        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json=performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], global_general_variables['balanceDue'], self=None)

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item amount X, Qty 1 and Fuel Item - End to End Flow\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
        itemId = 1
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId1)
        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json = performPayTransaction(context, "payTransactionWithCashTender.json",
                                         global_general_variables['posTransId'], global_general_variables['balanceDue'],
                                         self=None)

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item amount X, Qty 5 and Fuel Item - End to End Flow\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithQuantity.json')
        itemId = 1
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId2)
        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json = performPayTransaction(context, "payTransactionWithCashTender.json",
                                         global_general_variables['posTransId'], global_general_variables['balanceDue'],
                                         self=None)


@then(u'Validate response data for "{body_parsing_for}" transaction')
def step_impl(context, body_parsing_for):
    current_json = global_general_variables['voidTrs_res']
    scenarioName = context.scenario

    logger.info("Validating   : " + str(scenarioName))
    if str(current_json['errorCode']) == "0":
        assert True, 'Valid Response & ErrorCode received..., Pass'
    else:
        assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

    current_json = global_general_variables['authorizeTrs_res']
    totalAmount = validateAmount(global_general_variables['jsonFile'])

    if (current_json['transaction']['balanceDue'] == totalAmount):
        logger.info("Authorize Transaction Amount Validated ....")
    else:
        logger.error("Authorize Transaction Amount Validated ....")
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations
from features.utils.vposOperations import performAuthorizeWithDryItems, performPayTransaction, \
    updateFuelItemDetailsInJson, validateAmount
from features.utils.vposOperations import performAuthorizeWithQuantity, performAuthorizeWithFuelItems,performAuthorizeTransaction
from features.utils.vposOperations import voidtransaction
from features.utils.vposOperations import getAuthToken

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("")
file_handler = logging.FileHandler('logfile.log')
formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(formatter)
# add file handler to logger
logger.addHandler(file_handler)





@when(u'"{http_request_type}" HTTP request with Void API')
def step_impl(context, http_request_type, self=None, scenarioName=None):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}

    if 'POST' == http_request_type:
        scenarioName = context.scenario
        logger.info("Executing  : " + str(scenarioName))

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Qty 1\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Qty 5\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithQuantity.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Cash Payment Partial\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCashTender.json",global_general_variables['posTransId'],partialAmount,self = None )

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Credit Payment Partial\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCreditTender.json",global_general_variables['posTransId'],partialAmount,self = None )

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Coupon Payment Partial\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(),'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCouponTender.json",global_general_variables['posTransId'],partialAmount,self = None )

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Cash+Credit Payment Partial\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCashTender.json",global_general_variables['posTransId'],partialAmount,self = None )
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCreditTender.json", global_general_variables['posTransId'], partialAmount, self=None)

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Credit+Coupon Payment Partial\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(),'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCouponTender.json",global_general_variables['posTransId'],partialAmount,self = None )
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCreditTender.json", global_general_variables['posTransId'], partialAmount, self=None)

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Cash+Coupon Payment Partial\">":
            print("Executing  : " + str(scenarioName))
            global_general_variables['jsonFile'] = os.path.join(os.getcwd(),'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, global_general_variables['jsonFile'])
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCouponTender.json",global_general_variables['posTransId'],partialAmount,self = None )
            partialAmount = 1.00
            performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], partialAmount, self=None)

        if str(scenarioName) == "<Scenario \"Void All Transaction with Fuel Item\">":
            print("Executing  : " + str(scenarioName))
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
            itemId = 0
            payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)
            current_json = performAuthorizeTransaction(context,payloadFile)
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['jsonFile'] = jsonFile

        if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Qty 1 and Fuel Item\">":
            print("Executing  : " + str(scenarioName))
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
            itemId = 1
            payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)
            current_json = performAuthorizeTransaction(context, payloadFile)
            global_general_variables['authorizeTrs_res'] = current_json
            global_general_variables['jsonFile'] = jsonFile

        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        response = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['response_full'] = response


@then(u'Response parsing for "{body_parsing_for}" should be successful')
def step_impl(context, body_parsing_for, scenarioName=None):
    current_json = global_general_variables['response_full']
    scenarioName = context.scenario
    if str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Qty 1\">" or str(scenarioName) == "<Scenario \"Void All Transaction with dry item amount X and Qty 5\">" :
        logger.info("ErrorCode: " + str(current_json['errorCode']) )
        if str(current_json['errorCode']) == "0":
            logger.info(" Executed :" + str(scenarioName))
            assert True, 'Valid error code received, Pass'
        else:
            context.executeFlag = True
            assert False, 'Invalid error code received with message : ' + current_json['errorMessage']
    else:
        logger.info("ErrorCode: " + str(current_json['errorCode']) )
        if str(current_json['errorCode']) == "0":
            logger.info(" Executed :" + str(scenarioName))
            assert True, 'Valid error code received, Pass'
        else:
            context.executeFlag = True
            assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

    # Validation Authorize transaction amounts
    current_json = global_general_variables['authorizeTrs_res']
    totalAmount = validateAmount(global_general_variables['jsonFile'])

    if (current_json['transaction']['balanceDue'] == totalAmount):
        logger.info("Authorize Transaction Amount Validated ....")
    else:
        logger.error("Authorize Transaction Amount Validated ....")

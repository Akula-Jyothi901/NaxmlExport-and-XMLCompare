
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations
from features.utils.vposOperations import performAuthorizeTransaction, performPayTransaction, validateAmount
from features.utils.vposOperations import voidtransaction
from features.utils.vposOperations import getAuthToken

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}
executPayTransAPI = True

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("")
file_handler = logging.FileHandler('logfile.log')
formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(formatter)
# add file handler to logger
logger.addHandler(file_handler)


@when(u'"{http_request_type}" HTTP request sent')
def step_impl(context, http_request_type, self=None, scenarioName=None):
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    if 'POST' == http_request_type:
        if 'pay-transaction' in context.PAY_TRANSACTION_URL:
            scenarioName = context.scenario
            logger.info("Executing  : " + str(scenarioName))
            print("Executing  : " + str(scenarioName))
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json= performAuthorizeTransaction(context,jsonFile)
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
            global_general_variables['jsonFile'] = jsonFile
            global_general_variables['authorizeTrs_res'] = current_json

            url_temp = context.VPOSServer + context.PAY_TRANSACTION_URL
            global executPayTransAPI
            executPayTransAPI = True

            if str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Cash and Amount 0\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCashTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], context.AmountZero)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Cash and Correct Amount\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCashTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], global_general_variables['balanceDue'])
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Cash and Amount greater than balance due\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCashTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'],context.AmountLarge)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Cash and InCorrect Amount in Negative\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCashTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'],context.AmountNegative)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Credit and Amount 0\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCreditTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], context.AmountZero)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Credit and Correct Amount\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCreditTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], global_general_variables['balanceDue'])
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)


            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Credit and Amount greater than balance due\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCreditTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'],context.AmountLarge)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Credit and InCorrect Amount in Negative\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCreditTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'],context.AmountNegative)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and Amount 0\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCouponTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], context.AmountZero)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and Correct Amount\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCouponTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], global_general_variables['balanceDue'])
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and Amount greater than balance due\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCouponTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], context.AmountLarge)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and InCorrect Amount in Negative\">":
                payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransactionWithCouponTender.json')
                PumpOperations.updateTransactionIDAndAmountInJson(self, payTransactionJsonFile,global_general_variables['posTransId'], context.AmountZero)
                with open(payTransactionJsonFile) as f:
                    data1 = json.load(f)
                logger.info("payload Json:")
                logger.info(data1)
                payload = json.dumps(data1, indent=4)

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and Cash Correct Amount\">":
                partialAmount = 1.00
                response_json = performPayTransaction(context, "payTransactionWithCouponTender.json", global_general_variables['posTransId'], partialAmount, self=None)
                global_general_variables['balanceDue'] = response_json['transaction']['balanceDue']
                response_json = performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], global_general_variables['balanceDue'], self=None)
                executPayTransAPI = False

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and Credit Correct Amount\">":
                partialAmount = 2.00
                response_json = performPayTransaction(context, "payTransactionWithCouponTender.json", global_general_variables['posTransId'], partialAmount, self=None)
                global_general_variables['balanceDue'] = response_json['transaction']['balanceDue']
                response_json = performPayTransaction(context, "payTransactionWithCreditTender.json", global_general_variables['posTransId'], global_general_variables['balanceDue'], self=None)
                executPayTransAPI = False

            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon, Cash & Credit Correct Amount\">":
                partialAmount = 2.00
                performPayTransaction(context, "payTransactionWithCouponTender.json", global_general_variables['posTransId'], partialAmount, self=None)
                partialAmount = 3.00
                response_json = performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], partialAmount, self=None)
                global_general_variables['balanceDue'] = response_json['transaction']['balanceDue']
                response_json = performPayTransaction(context, "payTransactionWithCreditTender.json", global_general_variables['posTransId'], global_general_variables['balanceDue'], self=None)
                executPayTransAPI = False

            if(executPayTransAPI == True):
                headers = {'Authorization': "Bearer {}".format(context.access_token)}
                response = requests.request("POST", url_temp, headers=headers, data=payload)
                time.sleep(20)
                global_general_variables['response_full'] = response
                global_general_variables['expected_response_code'] = response.status_code
                logger.info("Pay transaction executed successfuly with response : ")
                logger.info(response.text)
                global_general_variables['response_full'] = response
                current_json = response.json()
                voidtransaction(context, global_general_variables['sessionId'])
            else:
                global_general_variables['response_full'] = response_json


@then(u'Response data parsing for "{body_parsing_for}" should be successful')
def step_impl(context, body_parsing_for, scenarioName=None):

    if executPayTransAPI == True:
        current_json = global_general_variables['response_full'].json()
    else:
        current_json = global_general_variables['response_full']

    scenarioName = context.scenario
    if 'Pay-transaction' == body_parsing_for:
        logger.info("Response Data  parsing :"+ body_parsing_for)
        if str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and InCorrect Amount in Negative\">" or str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Cash and InCorrect Amount in Negative\">"or str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Credit and InCorrect Amount in Negative\">" or str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Credit and Amount 0\">" or  str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Cash and Amount 0\">" or  str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and Amount 0\">"  :
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if  str(current_json['errorCode']) == "8038" :
                logger.info(" Executed :"+ str(scenarioName))
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                context.executeFlag = True
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Credit and Amount greater than balance due\">" or str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Coupon and Amount greater than balance due\">" or str(scenarioName) == "<Scenario \"Pay Transaction with Payment using Cash and Amount greater than balance due\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if  str(current_json['errorCode']) == "8035" and current_json['errorMessage'] == "Tender Amount is more than Transaction Balance Due Amount.":
                logger.info(" Executed :"+ str(scenarioName))
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                context.executeFlag = True
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']


        else:
            logger.info("ErrorCode: "+ current_json['transaction']['errorCode'] )
            if  current_json['transaction']["errorCode"] == "0" or current_json['transaction']["errorCode"] == "8017":
                assert True, 'Valid error code received with message : ' + current_json["errorMessage"]
            else:
                context.executeFlag = True
                assert False, 'Invalid error code received with message : ' + current_json["errorMessage"]
            #logger.info(current_json['transaction']['transactionSlip'])
            logger.info("PayTransaction done")

        # Validation Authorize transaction amounts
        current_json = global_general_variables['authorizeTrs_res']
        totalAmount = validateAmount(global_general_variables['jsonFile'])

        if (current_json['transaction']['balanceDue'] == totalAmount):
            logger.info("Authorize Transaction Amount Validated ....")
        else:
            logger.error("Authorize Transaction Amount Validated ....")

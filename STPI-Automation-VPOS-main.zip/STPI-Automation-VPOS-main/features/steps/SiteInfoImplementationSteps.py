
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time

from behave import given, when, then
import requests
import logging
from AuthenticationSteps import access_token
from features.utils.PumpOperations import PumpOperations

from features.utils.vposOperations import *

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("")
#logger.setLevel(logging.INFO) #set log level
# define file handler and set formatter
file_handler = logging.FileHandler('logfile.log')
#formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
#file_handler.setFormatter(formatter)
# add file handler to logger
#logger.addHandler(file_handler)





@when(u'Raise Site info "{http_request_type}" HTTP request')
def step_impl(context, http_request_type, self=None):
    scenarioName = context.scenario
    params = {}

    if 'GET' == http_request_type:
        if 'site-info' in context.SITEINFO_URL:
            logger.info("Executing  : " + str(context.scenario))
            url_temp = context.VPOSServer + context.SITEINFO_URL
            if str(scenarioName) == "<Scenario \"Site Info request without any parameters\">":
                params = {}
            elif  str(scenarioName) == "<Scenario \"Site Info request with gradeid parameter\">":
                params = {'gradeId': '137'}
            elif str(scenarioName) == "<Scenario \"Site Info request with productCode parameter\">":
                params = {'productCode': '10010101'}
            elif str(scenarioName) == "<Scenario \"Site Info request with gradeid and productcode parameters\">":
                params = {'gradeId': '137','productCode': '10010101'}
            elif str(scenarioName) == "<Scenario \"Site Info request with invalid gradeid parameters\">":
                params = {'gradeId': '002233'} #invalid Graade as 002233
            elif str(scenarioName) == "<Scenario \"Site Info request with invalid productcode parameter\">":
                params = {'productCode': '1001010165658'}
            elif str(scenarioName) == "<Scenario \"Site Info request with invalid gradeid and productcode parameters\">":
                params = {'gradeId': '002233', 'productCode': '1001010165658'}
            elif str(scenarioName) == "<Scenario \"Site Info request with valid parameters but there is problem in procesing it VPOS internal error\">":
                print("Unable to execute the scenario ")
            elif str(scenarioName) == "<Scenario \"Site Info request with gradeid and productcode parameters but fuel server is not available\">":
                print("Unable to execute the scenario ")

            headers = {'Authorization': "Bearer {}".format(context.access_token)}
            response = requests.request("GET", url_temp, headers=headers,params=params)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Site Info API Response : ")
            logger.info(response.text)

@then(u'Site info Response BODY parsing for "{body_parsing_for}" should be successful')
def step_impl(context, body_parsing_for,self=None):
    scenarioName = context.scenario
    current_json = global_general_variables['response_full'].json()
    gradesIdList = current_json["gradesIdList"]
    if 'Site info' == body_parsing_for:
        global_general_variables['pumpsIdList'] = current_json["pumpsIdList"]
        global_general_variables['gradesIdList'] = current_json["gradesIdList"]
        isFuelActive = current_json["isFuelActive"]
        logger.info("Response Data  parsing :" + body_parsing_for)
        logger.info("ErrorCode: " + current_json["errorCode"]+ "With Error  message: " + current_json["errorMessage"])

        if str(scenarioName) == "<Scenario \"Site Info request without any parameters\">":
            if current_json["errorCode"] == "0" and bool(isFuelActive) == True:
                assert True, str(scenarioName) + "Executed successfully" + "And Fuel status is " +  isFuelActive
            else:
                assert False, str(scenarioName) +' is failed : ' +  "And Fuel status is " +  str(isFuelActive)
            logger.info(str(scenarioName) + " is failed : ")
            logger.info(current_json["errorMessage"])

        elif str(scenarioName) == "<Scenario \"Site Info request with gradeid parameter\">":
            if current_json["errorCode"] == "0" and gradesIdList == "137":
                assert True, str(scenarioName) + "Executed successfully" + "And gradesIdList  is " +  gradesIdList
            else:
                assert False, str(scenarioName) +' is failed : ' +  "And gradesIdList  is " +  str(gradesIdList)
            logger.info(str(scenarioName) + " is failed : ")
            logger.info(current_json["errorMessage"])

        elif str(scenarioName) == "<Scenario \"Site Info request with productCode parameter\">":
            productCode = current_json['pumps'][0]['grades'][0]['productCode']
            if current_json["errorCode"] == "0" and productCode == "10010101":
                assert True, str(scenarioName) + "Executed successfully" + "And gradesIdList  is " + productCode
            else:
                assert False, str(scenarioName) + ' is failed : ' + "And gradesIdList  is " + str(productCode)
            logger.info(str(scenarioName) + " is failed : ")
            logger.info(current_json["errorMessage"])

        elif str(scenarioName) == "<Scenario \"Site Info request with gradeid and productcode parameters\">":
            productCode = current_json['pumps'][0]['grades'][0]['productCode']
            if current_json["errorCode"] == "0" and productCode == "10010101" and gradesIdList == "137":
                assert True, str(scenarioName) + "Executed successfully" + "And gradesIdList  is " + productCode
            else:
                assert False, str(scenarioName) + ' is failed : ' + "And gradesIdList  is " + str(productCode)
            logger.info(str(scenarioName) + " is failed : ")
            logger.info(current_json["errorMessage"])
        elif str(scenarioName) == "<Scenario \"Site Info request with invalid gradeid parameters\">":
            if current_json["errorCode"] == "8001":
                assert True, str(scenarioName) + "Executed successfully"+ " with message " + current_json['errorMessage']
            else:
                assert False, str(scenarioName) + ' is failed : ' + " with message " + current_json['errorMessage']
            logger.info(str(scenarioName) + " is failed : ")
            logger.info(current_json["errorMessage"])

        elif str(scenarioName) == "<Scenario \"Site Info request with invalid productcode parameter\">":
            if current_json["errorCode"] == "8002":
                assert True, str(scenarioName) + "Executed successfully"+ " with message " + current_json['errorMessage']
            else:
                assert False, str(scenarioName) + ' is failed : ' + " with message " + current_json['errorMessage']
            logger.info(str(scenarioName) + " is failed : ")
            logger.info(current_json["errorMessage"])

        elif str(scenarioName) == "<Scenario \"Site Info request with invalid gradeid and productcode parameters\">":
            if current_json["errorCode"] == "8003":
                assert True, str(scenarioName) + "Executed successfully" + " with message " + current_json[
                    'errorMessage']
            else:
                assert False, str(scenarioName) + ' is failed : ' + " with message " + current_json['errorMessage']
            logger.info(str(scenarioName) + " is failed : ")
            logger.info(current_json["errorMessage"])

        elif str(scenarioName) == "<Scenario \"Site Info request with valid parameters but there is problem in procesing it VPOS internal error\">":
            print("Unable to execute the scenario ")

        elif str(scenarioName) == "<Scenario \"Site Info request with gradeid and productcode parameters but fuel server is not available\">":
            print("Unable to execute the scenario ")
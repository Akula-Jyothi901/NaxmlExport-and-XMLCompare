
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random
import requests
import logging
from behave import given, when, then

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }
logger  = logging.getLogger("")


@when(u'Raise "{http_request_type}" HTTP request for pump transactions')
def step_impl(context, http_request_type, self=None, scenarioName=None):
    params = {}
    scenarioName = context.scenario
    global_general_variables['basic_application_URL'] = context.VPOSServer
    url_temp = global_general_variables['basic_application_URL']
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    if 'GET' == http_request_type:
        if 'pump-transactions' in  context.GET_PUMP_TRANSACTION_URL:
            url_temp = context.VPOSServer + context.GET_PUMP_TRANSACTION_URL
            if str(scenarioName) == "<Scenario \"Get pump transactions without parameters\">":
                params = {}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with pumpid parameters\">":
                params = {'pumpId': context.pumpId}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with pumpSrvRef parameters\">":
                params = {'PumpSrvRef': context.PumpSrvRef}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with pump id & pumpsrvref parameters\">":
                params = {'pumpId':context.pumpId, 'PumpSrvRef':context.PumpSrvRef}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with Negative Pump Id\">":
                params = {'pumpId': -1, 'PumpSrvRef':context.PumpSrvRef}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with PumpSrvTrsId 0\">":
                params = {'PumpSrvRef':0}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with Invalid PumpSrvTrsId > 0\">":
                params = {'PumpSrvRef': 8857}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with Negative PumpSrvTrsId\">":
                params = {'PumpSrvRef': -8857}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with PumpId and PumpSrvTrsId = 0\">":
                params = {'pumpId':context.pumpId, 'PumpSrvRef':0}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with Valid Pump Id and Invalid PumpSrvTrsId > 0\">":
                params = {'pumpId':context.pumpId, 'PumpSrvRef':9965868}
            elif str(scenarioName) == "<Scenario \"Get pump transactions with Invalid PumpId > 0 and Valid PumpSrvTrs Id\">":
                params = {'pumpId':469694657, 'PumpSrvRef':context.PumpSrvRef}


            response = requests.request("GET", url_temp, headers=headers,params=params)
            logger.info("Get  Pump Transactions Response : "+ response.text)
            global_general_variables['response_full'] = response


@then(u'Validate HTTP response for "{body_parsing_for}"')
def step_impl(context,body_parsing_for, scenarioName=None):
    current_json = global_general_variables['response_full'].json()
    scenarioName = context.scenario
    if 'GET-Pump-transactions' == body_parsing_for:
        logger.info("Response Data  validating for :"+ str(context.scenario))
        if str(scenarioName) == "<Scenario \"Get pump transactions without parameters\">":

            if  str(current_json['errorCode']) == "0" and current_json['errorMessage'] == "OK":
                logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        if str(scenarioName) == "<Scenario \"Get pump transactions with pumpid parameters\">":
            if  str(current_json['errorCode']) == "0" and current_json['errorMessage'] == "OK":
                logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        if str(scenarioName) == "<Scenario \"Get pump transactions with pumpSrvRef parameters\">":
            if str(current_json['errorCode']) == "0" and current_json[ 'errorMessage'] == "OK":
                logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        if str(scenarioName) == "<Scenario \"Get pump transactions with pump id & pumpsrvref parameters\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if str(current_json['errorCode']) == "0" and current_json['errorMessage'] == "OK":
                assert True, 'Valid error code received with message : ' + current_json['errorMessage']
            else:
                assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']

@then(u'Valid error message should be displayed for "{body_parsing_for}"')
def step_impl(context,body_parsing_for, scenarioName=None):
    current_json = global_general_variables['response_full'].json()
    scenarioName = context.scenario

    if str(scenarioName) == "<Scenario \"Get pump transactions with Negative Pump Id\">" or str(scenarioName) == "<Scenario \"Get pump transactions with Invalid PumpId > 0 and Valid PumpSrvTrs Id\">":
        logger.info( "ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
        if str(current_json['errorCode']) == "8004" and current_json['errorMessage'] == "8004: Invalid Pump Number":
            assert True, 'Valid error code received with message : ' + current_json['errorMessage']
        else:
            assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']
    elif str(scenarioName) == "<Scenario \"Get pump transactions with Invalid PumpSrvTrsId > 0\">" or  str(scenarioName) == "<Scenario \"Get pump transactions with Negative PumpSrvTrsId\">" or str(scenarioName) == "<Scenario \"Get pump transactions with Valid Pump Id and Invalid PumpSrvTrsId > 0\">":
        logger.info( "ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
        if str(current_json['errorCode']) == "8009" and current_json['errorMessage'] == "8009: Invalid PumpSrvRef number":
            assert True, 'Valid error code received with message : ' + current_json['errorMessage']
        else:
            assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']
    else:
        if str(current_json['errorCode']) == "0" and current_json['errorMessage'] == "OK":
            assert True, 'Valid error code received with message : ' + current_json['errorMessage']
        else:
            assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']


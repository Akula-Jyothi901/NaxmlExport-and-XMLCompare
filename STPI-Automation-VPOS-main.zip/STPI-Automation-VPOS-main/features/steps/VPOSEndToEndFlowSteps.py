
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random
from behave import given, when, then
import requests
import logging
from features.utils.vposOperations import performAuthorizeWithDryItems, addLPELoyaltyToTransaction, \
    performGetTransaction, performPayTransaction, performAuthorizeWithQuantity, voidtransaction

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }

logger  = logging.getLogger("")
addlpedata = 'features\configFiles\\' + "AddLPEData.json"
addlpejsonfile = os.path.join(os.getcwd(), addlpedata)



@when(u'Raise "{http_request_type}" HTTP request for End To End Transaction')
def step_impl(context, http_request_type, self=None, scenarioName=None):
    url_temp = context.VPOSServer
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    scenarioName = context.scenario


    logger.info("Executing..."+ str(scenarioName))
    if str(scenarioName) == "<Scenario \"Test VPOS APIs End to End Functionality\">":
        # ***** Perform Authorize Transaction *****
        current_json = performAuthorizeWithDryItems(context)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']

        # ***** Add LPE loyatly  to the above Authorize Transaction *****
        lpe_url = context.VPOSServer +context.ADD_LPE_LOYALTY_URL
        response = addLPELoyaltyToTransaction(context,lpe_url,addlpejsonfile, global_general_variables['sessionId'])
        global_general_variables['response_full'] = response
        logger.info("Add loyalty response  : " , response)

        # ***** Perfrom Get Transaction  to get the Balance Due amount *****
        get_response = performGetTransaction(context,global_general_variables['sessionId'] )
        global_general_variables['balanceDue'] = get_response['transaction']['balanceDue']

        # ***** Perfrom Pay Transaction with cash Tender and complete the transaction *****
        PayTransRes= performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], global_general_variables['balanceDue'], self=None)
        global_general_variables['PayTransRes'] = PayTransRes
        logger.info("Test VPOS APIs End to End Functionality ")


@then(u'Valid HTTP response should be received and Response BODY parsing for "{body_parsing_for}" should be successful')
def step_impl(context, body_parsing_for, scenarioName=None):

    current_json = global_general_variables['response_full']
    scenarioName = context.scenario
    if str(scenarioName) == "<Scenario \"Test VPOS APIs End to End Functionality\">":
        logger.info("Validating   : " + str(scenarioName))
        if str(current_json['errorCode']) == "0":
            assert True, 'Valid Response & ErrorCode received..., Pass'
        else:
            assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

        current_json = global_general_variables['PayTransRes']
        if str(current_json['transaction']['balanceDue']) == "0":
            assert True, 'Valid Response received and Transaction completed ..., Pass'
        else:
            assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']

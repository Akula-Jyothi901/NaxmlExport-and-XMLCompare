
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time
import random

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("")
file_handler = logging.FileHandler('logfile.log')
formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(formatter)
# add file handler to logger
logger.addHandler(file_handler)

@given(u'Set basic url is "{basic_url}"')
def basic_url(context, basic_url):
    global_general_variables['basic_application_URL'] = context.VPOSServer
    context.externalTransID = int(context.externalTransID)+ 1
    global_general_variables['externalTransId'] = context.externalTransID
    global_general_variables['scenarioName'] = context.scenario

@given(u'Set GET api endpoint as "{get_api_endpoint}"')
def step_impl(context, get_api_endpoint):
    global_general_variables['api_endpoint'] = get_api_endpoint

@given(u'Set POST api endpoint as "{api_endpoint}"')
def step_impl(context,api_endpoint):
    global_general_variables['api_endpoint'] = api_endpoint

@when(u'Set HEADER param request content type as "{header_content_type}"')
def step_impl(context, header_content_type):
    http_request_header['content-type'] = header_content_type

@when(u'Set HEADER param response accept type as "{header_accept_type}"')
def step_impl(context, header_accept_type):
    http_request_header['Accept'] = header_accept_type

@when(u'Raise "{http_request_type}" HTTP request')
def step_impl(context, http_request_type, self=None, scenarioName=None):
    url_temp = global_general_variables['basic_application_URL']
    headers = {'Authorization': "Bearer {}".format(context.access_token)}
    if 'GET' == http_request_type:
        if 'lock-transaction' in global_general_variables['api_endpoint']:
            url_temp = context.VPOSServer + context.LOCK_TRANSACTION_URL
            response = requests.request("GET", url_temp, headers=headers, )
            logger.info(response.text)
            global_general_variables['response_full'] = response
            logger.info("Lock Pump Transaction Response : ")
            global_general_variables['expected_response_code'] = response.status_code

        elif 'pump-transaction' in global_general_variables['api_endpoint']:
            url_temp = context.VPOSServer + context.GET_PUMP_TRANSACTION_URL
            response = requests.request("GET", url_temp,headers=headers)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Get Pump Transactions Response : ")
            logger.info(response.text)

        elif '/vpos-api/transaction' in global_general_variables['api_endpoint']:
            logger.info("Running Get transaction API : ")
            #pumpSrvTrsID =  str(global_general_variables['pumpSrvRef'] )
            pumpSrvTrsID = str(global_general_variables['posTransId'] )
            getTransactionEndPoint = "?SessionId=" + global_general_variables['sessionId']  + "&TransactionId=" +  global_general_variables['posTransId'] + "&PumpSrvTrs=" + pumpSrvTrsID
            params = {'SessionId': str(global_general_variables['sessionId']), 'TransactionId' : str(global_general_variables['posTransId']), 'PumpSrvTrs':pumpSrvTrsID}
            url_temp = context.VPOSServer + context.GET_TRANSACTION_URL + getTransactionEndPoint
            response = requests.request("GET", url_temp, headers=headers)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Get Transactions Response : ")
            logger.info(response.text)

    elif 'POST' == http_request_type:
        if 'pay-transaction' in global_general_variables['api_endpoint']:
            logger.info("Running Pay transaction API : ")
            url_temp = context.VPOSServer + context.PAY_TRANSACTION_URL
            scenarioName =context.scenario
            print("Executing the scenario :....... ", scenarioName)
            print("----------:", global_general_variables['balanceDue'])
            balanceDueAmount = global_general_variables['balanceDue']
            if str(scenarioName) == "<Scenario \"Pay Transaction with Payment Amount Less than Total Amount\">":
                print("Executing the scenario :....... " , scenarioName)
                print ("----------:",global_general_variables['balanceDue'])
                global_general_variables['balanceDue'] = global_general_variables['balanceDue']- 2
                print("----------:", type(global_general_variables['balanceDue']))
            elif str(scenarioName) == "<Scenario \"Pay Transaction with Payment Amount More than Total Amount\">":
                print("Executing the scenario :....... " , scenarioName)
                print ("------balanceDue----:",global_general_variables['balanceDue'])
                print("-----type-----:", type(global_general_variables['balanceDue']))
                global_general_variables['balanceDue'] = global_general_variables['balanceDue'] + 100
                print("----------:", global_general_variables['balanceDue'])
            elif str(global_general_variables['scenarioName']) == "<Scenario \"Pay Transaction for Transaction already saved in SR\">":
                print("______SR DB  ---------",global_general_variables['Total'])
               # global_general_variables['balanceDue'] = global_general_variables['Total']
            payTransactionJsonFile = os.path.join(os.getcwd(), 'features\configFiles\payTransaction.json')
            PumpOperations.updatePayTransactionJson(self, payTransactionJsonFile,global_general_variables['sessionId'],global_general_variables['posTransId'],global_general_variables['externalTransId'], global_general_variables['balanceDue'])
            with open(payTransactionJsonFile) as f:
                data1 = json.load(f)
            logger.info("payload Json:")
            logger.info(data1)
            payload = json.dumps(data1, indent=4)
            response = requests.request("POST", url_temp, headers=headers, data=payload)
            time.sleep(20)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Pay transaction executed successfuly with response : ")
            logger.info(response.text)
            if str(global_general_variables['scenarioName']) == "<Scenario \"Pay Transaction for Transaction already completed  and moved to BOS\">":
                response = requests.request("POST", url_temp, headers=headers, data=payload)
                global_general_variables['response_full'] = response
                global_general_variables['expected_response_code'] = response.status_code
                logger.info("Pay transaction already completed  and moved to BOS : ")
                logger.info(response.text)
        elif 'authorize-pump-transaction' in global_general_variables['api_endpoint']:
            logger.info("Running Authorize Pump transaction API : ")
            scenarioName = context.scenario
            ExpectedValue = "<Scenario \"Authorize Pump Transaction with invalid Preset Amount\">"
            if  str(scenarioName) == ExpectedValue:
                context.PresetAmount = float(context.PresetAmount) + 999999

            url_temp = context.VPOSServer + context.AUTHORIZE_PUMP_URL
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizePump.json')
            AttriName = "PresetAmount"
            PumpOperations.updateJsonFile(self, jsonFile, AttriName,context.PresetAmount)
            with open(jsonFile) as f:
                data1 = json.load(f)
            logger.info("payload Json:")
            logger.info( data1)
            payload = json.dumps(data1, indent=4)
            response = requests.request("POST", url_temp, headers=headers, data=payload)
            logger.info(response.text)
            global_general_variables['expected_response_code'] = response.status_code
            global_general_variables['response_full'] = response
        elif 'authorizeTransaction' in global_general_variables['api_endpoint']:
            logger.info("Running Authorize transaction API : ")
            scenarioName = context.scenario
            url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL

            if str(scenarioName) == "<Scenario \"Authorize Transaction with Dry Items\">":
                print("Entered into Authorize with dry items ")
                authorizeTransactionJson = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
                externalTransId = 1023 + random.randint(45,2000)
            elif str(scenarioName) == "<Scenario \"Authorize Transaction without Items\">":
                print("Entered into Authorize without items ")

                authorizeTransactionJson = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionNoItems.json')
            elif str(scenarioName) == "<Scenario \"Authorize Transaction with Not for Sale Item\">":
                authorizeTransactionJson = os.path.join(os.getcwd(), 'features\configFiles\\NotForSaleItem.json')
            elif str(scenarioName) == "<Scenario \"Authorize Transaction with Age Restriction Item\">":
                authorizeTransactionJson = os.path.join(os.getcwd(), 'features\configFiles\AgeRestrictedItems.json')
                context.executeFlag = True
            elif str(scenarioName) == "<Scenario \"Authorize Transaction with Time Restriction Item\">":
                authorizeTransactionJson = os.path.join(os.getcwd(), 'features\configFiles\AgeRestrictedItems.json')
                context.executeFlag = True
            else:
                time.sleep(10)
                authorizeTransactionJson = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
                #PumpOperations.externalTransID(self, authorizeTransactionJson, 'externalTransId', '1002')
            with open(authorizeTransactionJson) as f:
                data = json.load(f)

            logger.info("payload Json:")
            logger.info(data)
            payload = json.dumps(data, indent=4)
            response = requests.request("POST", url_temp, headers=headers, data=payload)
            time.sleep(30)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Authorize transaction done successfuly and items are added to POS transaction ")
            logger.info(response.text)
        elif '/vpos-api/transaction/void-all' in global_general_variables['api_endpoint']:
            logger.info("Running Void all transaction API : ")
            url_temp = context.VPOSServer + context.VOIDALL_TRANSACTION_URL + global_general_variables['sessionId']
            logger.info(url_temp)
            response = requests.request("POST", url_temp, headers=headers)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Void all Transactions Response : ")
            logger.info(response.text)
        elif '/vpos-api/transaction/save' in global_general_variables['api_endpoint']:
            logger.info("Running Save transaction API : ")
            url_temp = context.VPOSServer + context.SAVE_TRANSACTION_URL + global_general_variables['sessionId']
            logger.info(url_temp)
            response = requests.request("POST", url_temp, headers=headers)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Save Transactions Response : ")
            logger.info(response.text)

@then(u'Valid HTTP response should be received')
def step_impl(context):
    if None in global_general_variables['response_full']:
        assert False, 'Null response received'

@then(u'Response http code should be {expected_response_code:d}')
def step_impl(context, expected_response_code):
    global_general_variables['expected_response_code'] = expected_response_code
    actual_response_code = global_general_variables['response_full'].status_code
    if str(actual_response_code) not in str(expected_response_code):
        print (str(global_general_variables['response_full'].json()))
        assert False, '***ERROR: Following unexpected error response code received: ' + str(actual_response_code)


@then(u'Response HEADER content type should be "{expected_response_content_type}"')
def step_impl(context, expected_response_content_type):
    global_general_variables['expected_response_content_type'] = expected_response_content_type
    actual_response_content_type = global_general_variables['response_full'].headers['Content-Type']
    if expected_response_content_type not in actual_response_content_type:
        assert False, '***ERROR: Following unexpected error response content type received: ' + actual_response_content_type

@then(u'Response BODY should not be null or empty')
def step_impl(context):
    if None in global_general_variables['response_full']:
        assert False, '***ERROR:  Null or none response body received'

@then(u'Response BODY parsing for "{body_parsing_for}" should be successful')
def step_impl(context, body_parsing_for, scenarioName=None):
    current_json = global_general_variables['response_full'].json()
    if 'Authorize-pump-transaction' == body_parsing_for:
        global_general_variables['pumpSrvRef'] = current_json["pumpSrvRef"]
        logger.info("Response Data  parsing :" + body_parsing_for)
        logger.info("ErrorCode: " + current_json["errorcode"]+ "With Error  message: " + current_json["errorMessage"])
        scenarioName = context.scenario
        ExpectedValue = "<Scenario \"Authorize Pump Transaction with invalid Preset Amount\">"
        if str(scenarioName) == ExpectedValue:
            if current_json["errorcode"] == "8007" and  current_json["errorMessage"] =='8007: Invalid Preset Amount':
                assert True, 'Authorize Pump Transaction with invalid amount is failed : ' + current_json["errorMessage"]
            else:
                context.executeFlag = True
                assert False, 'Authorize Pump Transaction with invalid amount is failed : ' + current_json["errorMessage"]
            logger.info("Authorize Pump Transaction with invalid amount is failed : ")
            logger.info(current_json["errorMessage"])
        else:
            if global_general_variables['pumpSrvRef'] == 0 :
                context.scenario.skip(reason= current_json["errorMessage"])
            if current_json["errorcode"] == "0" and  global_general_variables['pumpSrvRef'] >= -1:
                assert True, 'Valid error code received with message : ' + current_json["errorMessage"]
            else:
                context.executeFlag = True
                assert False, 'Invalid error code received with message : ' + current_json["errorMessage"]
            logger.info("Authorize pump transaction done successfuly with PumpSrvRefID : ")
            logger.info(global_general_variables['pumpSrvRef'])

    elif 'Authorize-transaction' ==  body_parsing_for:
        logger.info("Response Data  parsing :"+ body_parsing_for)
        actualErrorMessage =  current_json['transaction']['errorMessage']
        expectedErrorMessage = 'Transaction was processed successfully with errors.'
        logger.info("ErrorCode: "+ current_json['transaction']["errorCode"]+ "With Error  message: " + actualErrorMessage)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        if (current_json['transaction']['errorCode']  == "0") or (current_json['transaction']['errorCode']  == "8017" and expectedErrorMessage == actualErrorMessage):
            assert True, 'Valid error code received with message : ' + expectedErrorMessage
        else:
            context.executeFlag = True
            assert False, 'Invalid error code received with message : ' + actualErrorMessage
        logger.info("Authorize transaction successful with Pos Transaction ID  : ")
        global_general_variables['posTransId'] = current_json['transaction']["posTransId"]
        global_general_variables['externalTransID'] = current_json['transaction']['externalTransID']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
        global_general_variables['Total'] = current_json['transaction']['balanceDue']
        logger.info(global_general_variables['posTransId'])
        logger.info(global_general_variables['externalTransId'])
    elif 'GET-transaction' == body_parsing_for:
        logger.info("Response Data  parsing :"+ body_parsing_for)
        logger.info("ErrorCode: "+ current_json['transaction']['errorCode']+ " With Error  message: "+ current_json['transaction']['errorMessage'])
        if current_json['transaction']['errorCode'] == "0":
            assert True, 'Valid error code received with message : ' + current_json['transaction']['errorCode']
        else:
            context.executeFlag = True
            assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
        logger.info("Get transaction done successfuly with balanceDue : " + str(global_general_variables['balanceDue']))
    elif 'Pay-transaction' == body_parsing_for:
        logger.info("Response Data  parsing :"+ body_parsing_for)
        if str(global_general_variables['scenarioName']) == "<Scenario \"Pay Transaction with Payment Amount Less than Total Amount\">":
            print("-------------", type(current_json['transaction']['errorCode']))
            logger.info("ErrorCode: " + str(current_json['transaction']['errorCode']) + " With Error  message: " + current_json['transaction']['errorMessage'])
            if  str(current_json['transaction']['errorCode']) == "0":
                assert True, 'Valid error code received with message : ' + current_json['transaction']['errorMessage']
            else:
                context.executeFlag = True
                assert False, 'Invalid error code received with message : ' + current_json['transaction']['errorMessage']
        elif str(global_general_variables['scenarioName']) == "<Scenario \"Pay Transaction with Payment Amount More than Total Amount\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if  current_json["errorCode"] == 8035:
                assert True, 'Valid error code received with message : ' + current_json["errorMessage"]
            else:
                context.executeFlag = True
                assert False, 'Invalid error code received with message : ' + current_json["errorMessage"]
        elif str(global_general_variables['scenarioName']) == "<Scenario \"Pay Transaction for Transaction already saved in SR\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if  current_json["errorCode"] == 8027:
                assert True, 'Valid error code received with message : ' + current_json["errorMessage"]
            else:
                assert False, 'Invalid error code received with message : ' + current_json["errorMessage"]

        elif str(global_general_variables['scenarioName']) == "<Scenario \"Pay Transaction for Transaction already completed  and moved to BOS\">":
            logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " + current_json['errorMessage'])
            if  current_json["errorCode"] == 8028:
                assert True, 'Valid error code received with message : ' + current_json["errorMessage"]
            else:
                assert False, 'Invalid error code received with message : ' + current_json["errorMessage"]

        else:
            logger.info("ErrorCode: "+ current_json['transaction']['errorCode'] + " With Error  message: "+ current_json['transaction']['errorMessage'])
            if  current_json['transaction']["errorCode"] == "0":
                assert True, 'Valid error code received with message : ' + current_json["errorMessage"]
            else:
                context.executeFlag = True
                assert False, 'Invalid error code received with message : ' + current_json["errorMessage"]
            logger.info(current_json['transaction']['transactionSlip'])
            logger.info("PayTransaction done & Receipt Printed : ")


    elif 'Save-transaction' == body_parsing_for:
        logger.info("Response Data  parsing :" + body_parsing_for)
        logger.info("ErrorCode: " + str(current_json['errorCode']) + " With Error  message: " +
                    current_json['errorMessage'])
        if current_json["errorCode"] == "0":
            assert True, 'Valid error code received with message : ' + current_json["errorMessage"]
        else:
            context.executeFlag = True
            assert False, 'Invalid error code received with message : ' + current_json["errorMessage"]
        logger.info("Transaction saved successfully : ")
        logger.info(current_json['posTransId'])
    elif 'Void all transaction' == body_parsing_for:
        logger.info("Response Data  parsing :" + body_parsing_for)
        logger.info("ErrorCode: " + current_json['errorCode'])
        if current_json["errorCode"] == "0":
            assert True, 'Transaction voided successfully '
        else:
            assert False, 'Transaction void is failed with error code  : ' + current_json["errorCode"]
        logger.info("Transaction voided successfully , ")
        logger.info(global_general_variables['posTransId'])

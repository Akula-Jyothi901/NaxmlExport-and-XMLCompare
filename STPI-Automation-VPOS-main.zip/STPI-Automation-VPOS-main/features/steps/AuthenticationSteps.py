
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}
access_token = 0

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("API-logger")
#logger.setLevel(logging.INFO) #set log level
# define file handler and set formatter
file_handler = logging.FileHandler('logfile.log')
formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(formatter)
# add file handler to logger
logger.addHandler(file_handler)

@when(u'Raise "{http_request_type}" request with Authentication details')
def step_impl(context, http_request_type, self=None):
   if 'POST' == http_request_type:
        if '/vpos-api/auth' in context.AUTH_URL:
            logger.info("Executing API : ")
            scenarioName = context.scenario
            url_temp = context.VPOSServer + context.AUTH_URL
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthenticationAPI.json')
            if  str(scenarioName) == "<Scenario \"Auth request with invalid API\">":
                print("**************************************")
                url_temp = context.VPOSServer + context.AUTH_URL + "Test"
                jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthenticationAPI.json')
            if  str(scenarioName) == "<Scenario \"Auth request with invalid values\">":
                print("**************************************")
                jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthenticationAPIWithInvalidData.json')
            if  str(scenarioName) == "<Scenario \"Auth request with valid values\">":
                print("**************************************")
                jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthenticationAPI.json')
            with open(jsonFile) as f:
                data1 = json.load(f)
            logger.info("Request Json:")
            logger.info( data1)
            payload = json.dumps(data1, indent=4)
            response = requests.request("POST", url_temp, headers=headers, data=payload)
            logger.info("Response  Data :" )
            logger.info(response.text)
            global_general_variables['expected_response_code'] = response.status_code
            global_general_variables['response_full'] = response
            if str(scenarioName) == "<Scenario \"Auth request with valid values\">":
                current_json = response.json()
                global_general_variables['access_token'] = current_json['token']
                print("**************************************", global_general_variables['access_token'])
                access_token = current_json['token']
                print("**************************************", access_token)
        elif 'authorizeTransaction' in global_general_variables['api_endpoint']:
            logger.info("Running Authorize transaction API : ")
            scenarioName = context.scenario
            url_temp = context.VPOSServer + context.AUTHORIZE_TRANSACTION_URL
            authorizeTransactionJson = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
            PumpOperations.externalTransID(self, authorizeTransactionJson, 'externalTransId', '1002')
            PumpOperations.updateNestedJson(self, authorizeTransactionJson, global_general_variables['pumpSrvRef'])
            with open(authorizeTransactionJson) as f:
                data = json.load(f)
            logger.info("payload Json:")
            logger.info(data)
            payload = json.dumps(data, indent=4)
            response = requests.request("POST", url_temp, headers=headers, data=payload)
            time.sleep(30)
            global_general_variables['response_full'] = response
            global_general_variables['expected_response_code'] = response.status_code
            logger.info("Authorize transaction done successfuly and items are added to POS transaction ")
            logger.info(response.text)






@then(u'Authentication Token Response BODY parsing for "{body_parsing_for}" should be successful')
def step_impl(context, body_parsing_for,self=None):
    current_json = global_general_variables['response_full'].json()
    if 'Auth Token' == body_parsing_for:
        logger.info("Response Data  parsing :" + body_parsing_for)
        scenarioName = context.scenario
        if str(scenarioName) == "<Scenario \"Auth request with invalid API\">":
            if current_json["description"] =='NCR Broker Server':
                logger.info("Authentication scenario  : " + str(scenarioName) + "Passed ")
                assert True, 'Authorize Pump Transaction with invalid amount is failed : ' + current_json["description"]
            else:
                logger.info("Authentication scenario  : " +  str(scenarioName)  + "failed ")
                assert False, 'Authorize Pump Transaction with invalid amount is failed : ' + current_json["description"]
        if str(scenarioName) == "<Scenario \"Auth request with invalid values\">":
            if current_json["description"] == 'NCR Broker Server':
                logger.info("Authentication scenario  : " +  str(scenarioName) + "Passed ")
                assert True, 'Authorize Pump Transaction with invalid amount is failed : ' + current_json[
                        "description"]
            else:
                logger.info("Authentication scenario  : " +  str(scenarioName) + "failed ")
                assert False, 'Authorize Pump Transaction with invalid amount is failed : ' + current_json["description"]

        if str(scenarioName) == "<Scenario \"Auth request with valid values\">":
            print("-------------------------------------------",current_json["token"])
            if current_json["token"] != '':
                logger.info("Authentication scenario  : " + str(scenarioName) + "Passed ")
                print("********************Test******************", access_token)
                assert True, 'Authentication is successful and logged int at :  : ' + current_json[
                    "loggedInAt"]
            else:
                logger.info("Authentication scenario  : " + str(scenarioName) + "failed ")
                assert False, 'Authentication is failed : ' + current_json[
                    "loggedInAt"]

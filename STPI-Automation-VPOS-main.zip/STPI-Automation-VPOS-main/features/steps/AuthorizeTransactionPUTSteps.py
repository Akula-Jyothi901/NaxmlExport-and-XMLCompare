#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations
from features.utils.vposOperations import performAuthorizeWithDryItems, addLPELoyaltyToTransaction, \
    performGetTransaction, performPayTransaction, performAuthorizeWithQuantity, voidtransaction, \
    updateFuelItemDetailsInJson, performAuthorizeTransaction, updateQuantityValueInJson, \
    performAuthorizeUpdateTransaction, updateTransactionIDInJson, validateAmount

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("")
addlpedata = 'features\configFiles\\' + "AddLPEData.json"
addlpejsonfile = os.path.join(os.getcwd(), addlpedata)


@when(u'Execute "{http_request_type}" HTTP request API')
def step_impl(context, http_request_type, self=None):
    scenarioName = context.scenario

    if str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item and  update with another dry item amount X and VoidTrs\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')

        current_json = performAuthorizeTransaction(context, jsonFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionUpdate.json')
        updateTransactionIDInJson(jsonFile, global_general_variables['posTransId'])
        current_json = performAuthorizeUpdateTransaction(context, jsonFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['balanceDue'] = current_json['transaction']['balanceDue']

        totalAmount = validateAmount(jsonFile)
        if (global_general_variables['balanceDue'] == totalAmount):
            logger.info("Update Authorize Transaction Amount Validated ....")
        else:
            logger.error("Update Authorize Transaction Amount Validated ....")

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with Fuel update with dry item amount X and Qty5 + add LPE, VoidTrs\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')

        current_json = performAuthorizeTransaction(context, jsonFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionUpdate.json')
        current_json = performAuthorizeTransaction(context, jsonFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']


        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item amount X and Qty1, update with Fuel + add LPE and Partial PayTrs, Void Transaction\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
        itemId = 1
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)

        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['posTransId'] = current_json['transaction']['posTransId']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        partialAmount = 0.10  # For Partial Payment
        performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'],partialAmount , self=None)

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json

    elif str(scenarioName) == "<Scenario \"Perform AuthorizeTrs with dry item amount X and Qty1, update with Fuel + add LPE and complete with Payment\">":
        jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
        itemId = 0
        payloadFile = updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId, context.PumpTrsId)
        current_json = performAuthorizeTransaction(context, payloadFile)
        global_general_variables['sessionId'] = current_json['transaction']['sessionId']
        global_general_variables['jsonFile'] = jsonFile
        global_general_variables['authorizeTrs_res'] = current_json

        res_json = voidtransaction(context, global_general_variables['sessionId'])
        global_general_variables['voidTrs_res'] = res_json



@then(u'Validate response data for "{body_parsing_for}" update')
def step_impl(context, body_parsing_for):
    current_json = global_general_variables['voidTrs_res']
    scenarioName = context.scenario


    logger.info("Validating   : " + str(scenarioName))
    if str(current_json['errorCode']) == "0":
        assert True, 'Valid Response & ErrorCode received..., Pass'
    else:
        assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

    #Validation Authorize transaction amounts
    current_json = global_general_variables['authorizeTrs_res']
    totalAmount = validateAmount(global_general_variables['jsonFile'])

    if (current_json['transaction']['balanceDue'] == totalAmount):
        logger.info("Authorize Transaction Amount Validated ....")
    else:
        logger.error("Authorize Transaction Amount Validated ....")
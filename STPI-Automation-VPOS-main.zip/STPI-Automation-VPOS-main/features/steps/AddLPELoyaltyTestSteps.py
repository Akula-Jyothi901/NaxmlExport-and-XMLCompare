
#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import time

from behave import given, when, then
import requests
import logging

from features.utils.PumpOperations import PumpOperations
from features.utils.vposOperations import performAuthorizeWithDryItems, addLPELoyaltyToTransaction, \
    performGetTransaction, performPayTransaction, performAuthorizeWithQuantity, voidtransaction, \
    updateFuelItemDetailsInJson, performAuthorizeTransaction, updateQuantityValueInJson

global_general_variables = {}
http_request_header = {}
http_request_body = {}
http_request_url_query_param = {}

url_temp = ""
headers = {
            'Content-Type': 'application/json'
        }


logger  = logging.getLogger("")
addlpedata = 'features\configFiles\\' + "AddLPEData.json"
addlpejsonfile = os.path.join(os.getcwd(), addlpedata)


@when(u'Execute "{http_request_type}" HTTP request with LPE')
def step_impl(context, http_request_type, self=None):
    scenarioName = context.scenario
    if 'POST' == http_request_type:
        logger.info("Executing..."+ str(scenarioName))

        if str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Qty1 and complete transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, jsonFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']
            lpe_url = context.VPOSServer +context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context,lpe_url,addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            get_response = performGetTransaction(context,global_general_variables['sessionId'] )
            global_general_variables['balanceDue'] = get_response['transaction']['balanceDue']
            performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], global_general_variables['balanceDue'], self=None)
            logger.info("Authorize Transaction with dry item amount X, Qty1 and Add LPE Loyalty ")

        elif str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Qty5 and void transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithQuantity.json')
            current_json = performAuthorizeTransaction(context, jsonFile)

            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            voidtransaction(context,global_general_variables['sessionId'])

        elif str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Qty1 and void transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, jsonFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']

            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            voidtransaction(context,global_general_variables['sessionId'])

        elif str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Qty1,Partial Payment and void transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithDryItems.json')
            current_json = performAuthorizeTransaction(context, jsonFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']

            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            get_response = performGetTransaction(context, global_general_variables['sessionId'])
            balanceDue = get_response['transaction']['balanceDue']
            partialAmount = balanceDue - 10.00
            performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'], partialAmount, self=None)
            voidtransaction(context, global_general_variables['sessionId'])

        elif str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Fuel Item and void transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
            itemId = 1
            payloadFile= updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId,context.PumpTrsId)

            current_json = performAuthorizeTransaction(context,payloadFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']

            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            res_json = voidtransaction(context, global_general_variables['sessionId'])
            global_general_variables['voidTrs_res'] = res_json

        elif str(scenarioName) == "<Scenario \"Perfrom LPE Loyalty to Transaction with dry item amount X with Qty5, Fuel Item and void transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransaction.json')
            itemId = 1
            #update Fuel Item Details
            payloadFile= updateFuelItemDetailsInJson(context, jsonFile, itemId, context.pumpId,context.PumpTrsId)
            #Updated Quantity to 5
            updateQuantityValueInJson(context, jsonFile, 5)

            current_json = performAuthorizeTransaction(context,payloadFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']

            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            res_json = voidtransaction(context, global_general_variables['sessionId'])
            global_general_variables['voidTrs_res'] = res_json

        elif str(scenarioName) == "<Scenario \"Perform LPE Loyalty to Transaction with Fuel Item only and void transactionn\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
            itemId = 0
            payloadFile= updateFuelItemDetailsInJson(context, jsonFile,itemId, context.pumpId,context.PumpTrsId)

            current_json = performAuthorizeTransaction(context,payloadFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']

            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            res_json = voidtransaction(context, global_general_variables['sessionId'])
            global_general_variables['voidTrs_res'] = res_json

        elif str(scenarioName) == "<Scenario \"Perform LPE Loyalty to Transaction with Fuel Item only, Partial Payment and void transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
            itemId = 0
            payloadFile= updateFuelItemDetailsInJson(context, jsonFile,itemId, context.pumpId,context.PumpTrsId)

            current_json = performAuthorizeTransaction(context,payloadFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']

            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            partialAmount = 0.10 # For Partial Payment
            performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'],partialAmount, self=None)

            res_json = voidtransaction(context, global_general_variables['sessionId'])
            global_general_variables['voidTrs_res'] = res_json

        elif str(scenarioName) == "<Scenario \"Perform LPE Loyalty to Transaction with Fuel Item only and complete transaction\">":
            jsonFile = os.path.join(os.getcwd(), 'features\configFiles\AuthorizeTransactionWithFuel.json')
            itemId = 0
            payloadFile= updateFuelItemDetailsInJson(context, jsonFile,itemId, context.pumpId,context.PumpTrsId)

            current_json = performAuthorizeTransaction(context,payloadFile)
            global_general_variables['sessionId'] = current_json['transaction']['sessionId']
            global_general_variables['posTransId'] = current_json['transaction']['posTransId']

            lpe_url = context.VPOSServer + context.ADD_LPE_LOYALTY_URL
            response = addLPELoyaltyToTransaction(context, lpe_url, addlpejsonfile, global_general_variables['sessionId'])
            global_general_variables['response_full'] = response

            get_response = performGetTransaction(context, global_general_variables['sessionId'])
            balanceDue = get_response['transaction']['balanceDue']
            performPayTransaction(context, "payTransactionWithCashTender.json", global_general_variables['posTransId'],balanceDue, self=None)




@then(u'Validate json response for "{body_parsing_for}" transactions')
def step_impl(context, body_parsing_for):
    current_json = global_general_variables['response_full']
    scenarioName = context.scenario
    #if str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Qty1 and complete transaction\">" or str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Qty1,Partial Payment and void transaction\">" :
    logger.info("Validating   : " + str(scenarioName))
    if str(current_json['errorCode']) == "0":
        assert True, 'Valid Response & ErrorCode received..., Pass'
    else:
        assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

    if str(scenarioName) == "<Scenario \"Add LPE Loyalty to Transaction with dry item amount X, Fuel Item and void transaction\">" :
        current_json = global_general_variables['voidTrs_res']
        if str(current_json['errorCode']) == "0":
            assert True, 'Valid Response & ErrorCode received..., Pass'
        else:
            assert False, 'Invalid error code received with message : ' + current_json['errorMessage']

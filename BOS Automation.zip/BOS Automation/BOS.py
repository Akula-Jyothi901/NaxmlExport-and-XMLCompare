import string
import os
import winreg
import configparser
import logging
from appium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains

class BOS:
    self_driver = None
    actions = None
    setup_functions = None
    config = None
    window_count = None
    logger = None
    desired_caps = {"app": "Root", "platformName": "Windows", "deviceName": "WindowsPC"}

    def __init__(self):
        logging.basicConfig(filename="log.log", format='%(asctime)s %(levelname)-8s %(message)s',filemode='w')
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)
        self.config = configparser.RawConfigParser()
        self.config.read("config.properties")
        self.getsetupvalues()
        os.startfile(self.config.get('Baseconfig', 'BOS_Location'))
        os.startfile(self.config.get('Baseconfig', 'winapp_Location'))
        self.winapp_url = self.config.get('Baseconfig', 'winapp_url')
        self.self_driver = webdriver.Remote(command_executor=self.winapp_url, desired_capabilities=self.desired_caps)
        self.waitforelement(self.self_driver, xpath=self.config.get('Objrepo', 'loginwindow'))
        self.actions = ActionChains(self.self_driver)
        self._login()
        self.open_functionlist()

    def _login(self):
        credentials = self.self_driver.find_elements_by_xpath(self.config.get('Objrepo', 'creds'))
        credentials[0].send_keys(self.config.get('Baseconfig', 'user'))
        credentials[1].send_keys(self.config.get('Baseconfig', 'pwd'))
        self.self_driver.find_element_by_xpath(self.config.get('Objrepo', 'login')).click()
        self.waitforelement(self.self_driver, xpath=self.config.get('Objrepo', 'backoffice'))

    def open_functionlist(self):
        self.actions.key_down(Keys.LEFT_CONTROL).send_keys(Keys.F12).key_up(Keys.LEFT_CONTROL).perform()
        self.actions.reset_actions()
        self.waitforelement(self.self_driver, xpath=self.config.get('Objrepo', 'functionlistwindow'))
        self.window_count = len(self.self_driver.find_elements_by_xpath("//Window"))

    def run_fuction(self, function):
        if len(self.self_driver.find_elements_by_xpath("//Window")) > self.window_count:
            self.actions.key_down(Keys.ALT).send_keys(Keys.F4).key_up(Keys.ALT).perform()
            self.actions.reset_actions()

        window_name = function
        if "Setup" in function:
            window_name = function.split("Setup")[0]

        self.self_driver.find_element_by_xpath(self.config.get('Objrepo', 'functionsearch')).send_keys(function)
        self.self_driver.find_element_by_xpath(self.config.get('Objrepo', 'functionrun')).click()
        window_xpath = f"//Window[contains(@Name,'{window_name}')]"

        try:
            self.waitfordialog(self.self_driver,window_xpath)
            self.logger.info(f"{function} dialog is opened successfully")
            self.actions.key_down(Keys.ALT).send_keys(Keys.F4).key_up(Keys.ALT).perform()
            self.actions.reset_actions()
            if(self.self_driver.find_element_by_xpath(self.config.get('Objrepo', 'windowtitle')).text)=="Confirm":
                self.self_driver.find_element_by_xpath(self.config.get('Objrepo', 'confirm_window_No')).click()

        except TimeoutException:
            if len(self.self_driver.find_elements_by_xpath("//Window")) == self.window_count:
                self.logger.error(f"{function} dialog is not opened")
            else:
                window_title = self.self_driver.find_element_by_xpath(self.config.get('Objrepo', 'windowtitle')).text
                setup_window_title=window_title

                if "Setup" in window_title:
                    window_title = window_title.split("Setup")[0]

                if window_name.rstrip().lower()==window_title.rstrip().lower():
                    self.logger.info(f"{function} dialog is opened successfully")
                    self.actions.key_down(Keys.ALT).send_keys(Keys.F4).key_up(Keys.ALT).perform()
                    self.actions.reset_actions()
                else:
                    self.logger.error(f"Incorrect window {setup_window_title} opened for {function}")
                    self.actions.key_down(Keys.ALT).send_keys(Keys.F4).key_up(Keys.ALT).perform()
                    self.actions.reset_actions()

    def waitforelement(self, driver: webdriver, xpath: string):
        wait = WebDriverWait(driver, 30)
        wait.until(EC.visibility_of_element_located((By.XPATH, xpath)))

    def waitfordialog(self,driver:webdriver,xpath:string):
        wait = WebDriverWait(driver,35)
        wait.until(EC.visibility_of_element_located((By.XPATH, xpath)))

    def getsetupvalues(self):
        i = 0
        self.setup_functions = []
        path = self.config.get('Baseconfig', 'registry_path')
        parentkey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path)

        while True:
            try:
                key = winreg.EnumKey(parentkey, i)
                subkey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, f"{path}\\{key}")
                if winreg.QueryValueEx(subkey, "Typ")[0] == "Setup":
                    self.setup_functions.append(key)
                i = i + 1
            except WindowsError:
                break

    def setupfunctions_test(self):
        for setupfunction in self.setup_functions:
            self.run_fuction(setupfunction)

x = BOS()
x.setupfunctions_test()